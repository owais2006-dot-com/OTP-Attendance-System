import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.*;
import java.awt.event.ItemEvent; // Added for ItemEvent
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
// import java.util.Date; // Removed to avoid collision with java.sql.Date
// Explicitly import java.sql.Date for valueOf(LocalDate)
import java.sql.*;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId; // Added for ZoneId
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoUnit;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;
import java.util.prefs.Preferences;
import javax.imageio.ImageIO;
import java.util.Set;
import java.util.HashSet;
import java.util.Vector;
import java.util.Map;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.io.FileWriter; // Added for CSV export
import java.io.BufferedWriter; // Added for CSV export
import java.text.DecimalFormat; // Added for attendance percentage formatting
import java.nio.file.Files; // For file operations in profile picture
import java.nio.file.StandardCopyOption; // For file operations in profile picture
import java.awt.geom.Point2D; // For geofencing calculations
import java.util.Locale; // For multi-language support
import java.util.ResourceBundle; // For multi-language support
import java.net.URI; // For opening links/files
import java.net.URISyntaxException; // Added for URISyntaxException
import java.math.BigDecimal; // For grades

// Removed password hashing imports as requested.
// This means passwords will be stored and compared in plain text.
// WARNING: This is a severe security risk and is NOT recommended for production.


/*
 * SQL Database Schema Updates:
 *
 * You need to run these SQL commands in your MySQL database (student_portal)
 * to add the necessary tables and columns for the new features.
 *
 * 1. Add 'last_login' to users table (for reminder logic, though not strictly used for reminders yet, good practice):
 * ALTER TABLE users ADD COLUMN last_login TIMESTAMP DEFAULT CURRENT_TIMESTAMP;
 *
 * 2. Create 'course_enrollment_requests' table:
 * CREATE TABLE course_enrollment_requests (
 * id INT AUTO_INCREMENT PRIMARY KEY,
 * student_id INT NOT NULL,
 * course_id INT NOT NULL,
 * request_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 * status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
 * approved_by_user_id INT,
 * approval_date TIMESTAMP,
 * FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
 * FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE,
 * FOREIGN KEY (approved_by_user_id) REFERENCES users(id) ON DELETE SET NULL
 * );
 *
 * 3. Create 'system_settings' table (for automated reminder settings):
 * CREATE TABLE system_settings (
 * setting_key VARCHAR(255) PRIMARY KEY,
 * setting_value VARCHAR(255) NOT NULL
 * );
 *
 * -- Insert default setting for automated reminders
 * INSERT INTO system_settings (setting_key, setting_value) VALUES ('enable_attendance_reminders', 'true');
 * INSERT INTO system_settings (setting_key, setting_value) VALUES ('attendance_reminder_time_hour', '9'); -- 9 AM
 * INSERT INTO system_settings (setting_key, setting_value) VALUES ('attendance_reminder_time_minute', '0'); -- 00 minutes
 *
 * 4. Create 'announcements' table:
 * CREATE TABLE announcements (
 * id INT AUTO_INCREMENT PRIMARY KEY,
 * sender_user_id INT NOT NULL, -- User who sent the announcement (Admin/Teacher)
 * subject VARCHAR(255) NOT NULL,
 * message TEXT NOT NULL,
 * send_to_role ENUM('student', 'teacher', 'admin', 'all', 'specific_course', 'specific_students') NOT NULL,
 * target_course_id INT, -- NULL if not specific to a course
 * sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 * FOREIGN KEY (sender_user_id) REFERENCES users(id) ON DELETE CASCADE,
 * FOREIGN KEY (target_course_id) REFERENCES courses(id) ON DELETE SET NULL
 * );
 *
 * 5. Create 'user_announcements' table (for tracking individual recipient status, especially for students):
 * CREATE TABLE user_announcements (
 * id INT AUTO_INCREMENT PRIMARY KEY,
 * announcement_id INT NOT NULL,
 * recipient_user_id INT NOT NULL,
 * is_read BOOLEAN DEFAULT FALSE,
 * received_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 * UNIQUE KEY (announcement_id, recipient_user_id), -- Ensure a user only gets one entry per announcement
 * FOREIGN KEY (announcement_id) REFERENCES announcements(id) ON DELETE CASCADE,
 * FOREIGN KEY (recipient_user_id) REFERENCES users(id) ON DELETE CASCADE
 * );
 *
 * 6. Add 'profile_picture_path' to students table:
 * ALTER TABLE students ADD COLUMN profile_picture_path VARCHAR(255);
 *
 * -- NEW FEATURE: User Account Status (for disabling accounts)
 * ALTER TABLE users ADD COLUMN is_active BOOLEAN DEFAULT TRUE;
 *
 * -- IMPORTANT: The 'password' column in your 'users' table should be
 * -- adjusted to a suitable length for plain text passwords (e.g., VARCHAR(50) or VARCHAR(100)).
 * -- ALTER TABLE users MODIFY COLUMN password VARCHAR(100) NOT NULL;
 *
 * -- NEW FEATURE: Student Profile Functionality (phone_number, address, interests, bio)
 * ALTER TABLE students ADD COLUMN phone_number VARCHAR(20);
 * ALTER TABLE students ADD COLUMN address TEXT;
 * ALTER TABLE students ADD COLUMN interests TEXT;
 * ALTER TABLE students ADD COLUMN bio TEXT;
 *
 * -- NEW FEATURE: Automated Leave Request System
 * CREATE TABLE leave_requests (
 * id INT AUTO_INCREMENT PRIMARY KEY,
 * student_id INT NOT NULL,
 * course_id INT, -- Optional: if leave is course-specific, otherwise NULL for general leave
 * request_date DATE NOT NULL,
 * start_date DATE NOT NULL,
 * end_date DATE NOT NULL,
 * reason TEXT NOT NULL,
 * status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
 * approved_by_user_id INT, -- Admin or Teacher who approved/rejected
 * approval_date TIMESTAMP,
 * FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
 * FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE SET NULL,
 * FOREIGN KEY (approved_by_user_id) REFERENCES users(id) ON DELETE SET NULL
 * );
 *
 * -- NEW FEATURE: Geofencing for Attendance
 * ALTER TABLE attendance ADD COLUMN latitude DECIMAL(10, 8);
 * ALTER TABLE attendance ADD COLUMN longitude DECIMAL(11, 8);
 * ALTER TABLE courses ADD COLUMN expected_latitude DECIMAL(10, 8);
 * ALTER TABLE courses ADD COLUMN expected_longitude DECIMAL(11, 8);
 * ALTER TABLE courses ADD COLUMN geofence_radius_meters INT DEFAULT 100;
 *
 * -- NEW FEATURE: Real-time Attendance Tracking
 * ALTER TABLE student_courses ADD COLUMN last_marked_attendance_time TIMESTAMP;
 *
 * -- NEW FEATURE: Course Management Enhancements (Assignments, Grades, Course Materials)
 * CREATE TABLE assignments (
 * id INT AUTO_INCREMENT PRIMARY KEY,
 * course_id INT NOT NULL,
 * title VARCHAR(255) NOT NULL,
 * description TEXT,
 * due_date DATE,
 * FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE
 * );
 *
 * CREATE TABLE grades (
 * id INT AUTO_INCREMENT PRIMARY KEY,
 * assignment_id INT NOT NULL,
 * student_id INT NOT NULL,
 * grade DECIMAL(5,2), -- e.g., 95.50
 * feedback TEXT,
 * graded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 * FOREIGN KEY (assignment_id) REFERENCES assignments(id) ON DELETE CASCADE,
 * FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
 * UNIQUE KEY (assignment_id, student_id) -- One grade per student per assignment
 * );
 *
 * CREATE TABLE course_materials (
 * id INT AUTO_INCREMENT PRIMARY KEY,
 * course_id INT NOT NULL,
 * title VARCHAR(255) NOT NULL,
 * file_path VARCHAR(255), -- Path to the uploaded file or link
 * upload_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 * FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE
 * );
 *
 * -- NEW FEATURE: Calendar Integration (Class Schedules)
 * CREATE TABLE class_schedules (
 * id INT AUTO_INCREMENT PRIMARY KEY,
 * course_id INT NOT NULL,
 * day_of_week VARCHAR(10) NOT NULL, -- e.g., 'MONDAY', 'TUESDAY
 * start_time TIME NOT NULL,
 * end_time TIME NOT NULL,
 * FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE
 * );
 *
 * -- NEW FEATURE: Feedback and Rating System
 * CREATE TABLE feedback (
 * id INT AUTO_INCREMENT PRIMARY KEY,
 * student_id INT NOT NULL,
 * course_id INT NOT NULL,
 * rating INT NOT NULL CHECK (rating >= 1 AND rating <= 5),
 * comments TEXT,
 * submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 * FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
 * FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE,
 * UNIQUE KEY (student_id, course_id) -- One feedback per student per course
 * );
 */

public class OTPAttendanceSystem extends JFrame {

    // DB Config
    static final String DB_URL = "jdbc:mysql://localhost:3306/student_portal?useSSL=false&allowPublicKeyRetrieval=true";
    static final String DB_USER = "root";
    static final String DB_PASS = "Owais@12345";

    private static Connection connection;
    private static User loggedInUser; // Store logged-in user details

    // UI Components
    private JPanel mainPanel;
    private CardLayout cardLayout;

    // Login Components
    private JTextField usernameField;
    private JPasswordField passwordField;

    // OTP Generation & Expiry
    private String currentOTP;
    private Timer otpTimer;
    private JLabel otpLabel; // To display OTP to teacher/admin
    private long otpExpiryTime; // Store expiry time in milliseconds
    private static final String PREF_OTP_KEY = "currentOTP";
    private static final String PREF_OTP_EXPIRY_KEY = "otpExpiry";
    private Preferences prefs;

    // Automated Reminder Scheduler
    private ScheduledExecutorService reminderScheduler;

    // Reference to AdminDashboard to update OTP label
    private AdminDashboard adminDashboardInstance;


    // --- UI Utility Class ---
    static class UIUtils {
        public static final Color ACCENT_COLOR = new Color(70, 130, 180); // SteelBlue
        public static final Color BUTTON_BG_COLOR = new Color(70, 130, 180); // SteelBlue
        public static final Color BUTTON_HOVER_COLOR = new Color(90, 150, 200);
        public static final Color BUTTON_TEXT_COLOR = Color.WHITE;
        public static final Color BORDER_COLOR = Color.GRAY;
        public static final Color PANEL_COLOR = Color.WHITE;
        public static final Color BACKGROUND_COLOR = new Color(240, 240, 240);
        public static final Color TEXT_COLOR = Color.BLACK;
        public static final Color DANGER_COLOR = new Color(220, 50, 50);
        public static final Color SUCCESS_COLOR = new Color(46, 204, 113); // Emerald Green
        public static final Color WARNING_COLOR = new Color(241, 196, 15); // Sunflower Yellow
        public static final Color CHART_BAR_COLOR_PRESENT = new Color(60, 179, 113); // MediumSeaGreen
        public static final Color CHART_BAR_COLOR_ABSENT = new Color(255, 99, 71); // Tomato
        public static final Color CHART_BAR_COLOR_LEAVE = new Color(255, 215, 0); // Gold

        public static void applyButtonStyle(JButton button) {
            button.setBackground(BUTTON_BG_COLOR);
            button.setForeground(BUTTON_TEXT_COLOR);
            button.setFont(new Font("Arial", Font.BOLD, 14));
            button.setBorder(BorderFactory.createCompoundBorder(
                    new LineBorder(BUTTON_BG_COLOR, 1),
                    new EmptyBorder(8, 15, 8, 15)
            ));
            button.setFocusPainted(false);
            button.addMouseListener(new java.awt.event.MouseAdapter() {
                public void mouseEntered(java.awt.event.MouseEvent evt) {
                    button.setBackground(BUTTON_HOVER_COLOR);
                }

                public void mouseExited(java.awt.event.MouseEvent evt) {
                    button.setBackground(BUTTON_BG_COLOR);
                }
            });
        }

        public static void styleTable(JTable table) {
            table.setFont(new Font("Arial", Font.PLAIN, 12));
            table.getTableHeader().setFont(new Font("Arial", Font.BOLD, 13));
            table.getTableHeader().setBackground(ACCENT_COLOR);
            table.getTableHeader().setForeground(BUTTON_TEXT_COLOR);
            table.setRowHeight(25);
            table.setGridColor(BORDER_COLOR);
            table.setSelectionBackground(new Color(173, 216, 230)); // Light Blue
            table.setSelectionForeground(TEXT_COLOR);
        }

        public static Border createPanelBorder() {
            return BorderFactory.createCompoundBorder(
                    new LineBorder(BORDER_COLOR, 1),
                    new EmptyBorder(10, 10, 10, 10)
            );
        }
    }

    // --- User Class (to hold logged-in user data) ---
    static class User {
        private int id;
        private String username;
        private String role;
        private String fullName;
        // NEW FEATURE: User Account Status
        private boolean isActive;


        public User(int id, String username, String role, String fullName, boolean isActive) {
            this.id = id;
            this.username = username;
            this.role = role;
            this.fullName = fullName;
            this.isActive = isActive; // NEW
        }

        public int getId() {
            return id;
        }

        public String getUsername() {
            return username;
        }

        public String getRole() {
            return role;
        }

        public String getFullName() {
            return fullName;
        }

        // NEW: Getter for isActive
        public boolean isActive() {
            return isActive;
        }

        @Override
        public String toString() {
            return "User{" +
                   "id=" + id +
                   ", username='" + username + '\'' +
                   ", role='" + role + '\'' +
                   ", fullName='" + fullName + '\'' +
                   ", isActive=" + isActive + // NEW
                   '}';
        }
    }

    public OTPAttendanceSystem() {
        setTitle("OTP Attendance System");
        setSize(1000, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        prefs = Preferences.userNodeForPackage(OTPAttendanceSystem.class);

        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);
        add(mainPanel);

        setupLoginPanel();

        initializeDatabase();

        // Ensure that the 'student_images' directory exists
        File imageDir = new File("student_images");
        if (!imageDir.exists()) {
            if (imageDir.mkdirs()) {
                System.out.println("Created 'student_images' directory.");
            } else {
                System.err.println("Failed to create 'student_images' directory. Profile pictures might not save.");
            }
        }

        // Ensure 'course_materials_files' directory exists for file uploads
        File materialsDir = new File("course_materials_files");
        if (!materialsDir.exists()) {
            if (materialsDir.mkdirs()) {
                System.out.println("Created 'course_materials_files' directory.");
            } else {
                System.err.println("Failed to create 'course_materials_files' directory. Course materials might not save.");
            }
        }


        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            try {
                if (connection != null && !connection.isClosed()) {
                    connection.close();
                    System.out.println("Database connection closed.");
                }
            } catch (SQLException e) {
                System.err.println("Error closing database connection: " + e.getMessage());
                e.printStackTrace();
            }
            if (reminderScheduler != null && !reminderScheduler.isShutdown()) {
                reminderScheduler.shutdownNow();
                System.out.println("Reminder scheduler shut down via shutdown hook.");
            }
        }));

        loadAndRestoreOTP();

        reminderScheduler = Executors.newSingleThreadScheduledExecutor();
        startAutomatedAttendanceReminders();
    }

    public static void main(String[] args) {
        // Ensure Swing components are created and updated on the Event Dispatch Thread (EDT)
        SwingUtilities.invokeLater(() -> {
            new OTPAttendanceSystem().setVisible(true);
        });
    }

    private void initializeDatabase() {
        try {
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
            System.out.println("Database connected successfully!");

            // --- Database Schema Check (for common missing columns) ---
            // This is a proactive check to help the user ensure their database schema is up-to-date.
            // It does not automatically alter the database, but informs the user if columns are missing.
            checkAndWarnMissingColumns("students", "interests", "TEXT");
            checkAndWarnMissingColumns("students", "bio", "TEXT");
            checkAndWarnMissingColumns("students", "phone_number", "VARCHAR(20)");
            checkAndWarnMissingColumns("students", "address", "TEXT");
            checkAndWarnMissingColumns("students", "profile_picture_path", "VARCHAR(255)");
            checkAndWarnMissingColumns("users", "is_active", "BOOLEAN");
            checkAndWarnMissingColumns("attendance", "latitude", "DECIMAL(10,8)");
            checkAndWarnMissingColumns("attendance", "longitude", "DECIMAL(11,8)");
            checkAndWarnMissingColumns("courses", "expected_latitude", "DECIMAL(10,8)");
            checkAndWarnMissingColumns("courses", "expected_longitude", "DECIMAL(11,8)");
            checkAndWarnMissingColumns("courses", "geofence_radius_meters", "INT");
            checkAndWarnMissingColumns("student_courses", "last_marked_attendance_time", "TIMESTAMP");
            // Check for 'send_to_role' in 'announcements' table
            checkAndWarnMissingColumns("announcements", "send_to_role", "ENUM('student', 'teacher', 'admin', 'all', 'specific_course', 'specific_students')");
            checkAndWarnMissingColumns("announcements", "target_course_id", "INT");


            // Check for new tables
            checkAndWarnMissingTable("course_enrollment_requests");
            checkAndWarnMissingTable("system_settings");
            checkAndWarnMissingTable("announcements");
            checkAndWarnMissingTable("user_announcements");
            checkAndWarnMissingTable("leave_requests");
            checkAndWarnMissingTable("assignments");
            checkAndWarnMissingTable("grades");
            checkAndWarnMissingTable("course_materials");
            checkAndWarnMissingTable("class_schedules");
            checkAndWarnMissingTable("feedback");


        } catch (SQLException e) {
            showError("Database connection failed: " + e.getMessage());
            e.printStackTrace();
            System.exit(1);
        }
    }

    /**
     * Checks if a column exists in a table and warns the user if it doesn't.
     * @param tableName The name of the table.
     * @param columnName The name of the column to check.
     * @param columnType The expected SQL type of the column (for informative message).
     */
    private void checkAndWarnMissingColumns(String tableName, String columnName, String columnType) {
        try {
            DatabaseMetaData meta = connection.getMetaData();
            ResultSet rs = meta.getColumns(null, null, tableName, columnName);
            if (!rs.next()) {
                System.err.println("WARNING: Column '" + columnName + "' not found in table '" + tableName + "'.");
                System.err.println("Please run the following SQL command in your MySQL database:");
                System.err.println("ALTER TABLE " + tableName + " ADD COLUMN " + columnName + " " + columnType + ";");
            }
        } catch (SQLException e) {
            System.err.println("Error checking for column '" + columnName + "' in table '" + tableName + "': " + e.getMessage());
        }
    }

    /**
     * Checks if a table exists and warns the user if it doesn't.
     * @param tableName The name of the table to check.
     */
    private void checkAndWarnMissingTable(String tableName) {
        try {
            DatabaseMetaData meta = connection.getMetaData();
            ResultSet rs = meta.getTables(null, null, tableName, null);
            if (!rs.next()) {
                System.err.println("WARNING: Table '" + tableName + "' not found.");
                System.err.println("Please ensure you have run the necessary SQL CREATE TABLE commands for '" + tableName + "'.");
            }
        } catch (SQLException e) {
            System.err.println("Error checking for table '" + tableName + "': " + e.getMessage());
        }
    }


    // --- Password Handling (Plain Text - WARNING: INSECURE) ---
    // This method is now a placeholder as hashing is removed per user request.
    // Passwords will be stored and compared directly.
    private String handlePasswordStorage(String password) {
        // In a real application, this would hash the password.
        // As per user request, returning plain text.
        return password;
    }

    private void setupLoginPanel() {
        JPanel loginPanel = new JPanel(new GridBagLayout());
        loginPanel.setBackground(UIUtils.BACKGROUND_COLOR);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JPanel loginBox = new JPanel(new GridBagLayout());
        loginBox.setBackground(UIUtils.PANEL_COLOR);
        loginBox.setBorder(UIUtils.createPanelBorder());

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        JLabel titleLabel = new JLabel("Login", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 28));
        titleLabel.setForeground(UIUtils.ACCENT_COLOR);
        loginBox.add(titleLabel, gbc);

        gbc.gridwidth = 1;
        gbc.gridy = 1;
        JLabel usernameLabel = new JLabel("Username:");
        usernameLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        usernameLabel.setForeground(UIUtils.TEXT_COLOR);
        loginBox.add(usernameLabel, gbc);

        gbc.gridx = 1;
        usernameField = new JTextField(20);
        usernameField.setFont(new Font("Arial", Font.PLAIN, 16));
        loginBox.add(usernameField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        passwordLabel.setForeground(UIUtils.TEXT_COLOR);
        loginBox.add(passwordLabel, gbc);

        gbc.gridx = 1;
        passwordField = new JPasswordField(20);
        passwordField.setFont(new Font("Arial", Font.PLAIN, 16));
        loginBox.add(passwordField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        JButton loginButton = new JButton("Login");
        UIUtils.applyButtonStyle(loginButton);
        loginButton.addActionListener(e -> authenticateUser());
        loginBox.add(loginButton, gbc);

        passwordField.addActionListener(e -> authenticateUser());

        loginPanel.add(loginBox);
        mainPanel.add(loginPanel, "Login");
    }

    private void authenticateUser() {
        String username = usernameField.getText();
        String password = new String(passwordField.getPassword());

        // NEW FEATURE: User Account Status - Check is_active
        String sql = "SELECT id, username, role, full_name, password, is_active FROM users WHERE username = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, username);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                String storedPassword = rs.getString("password");
                boolean isActive = rs.getBoolean("is_active"); // NEW

                if (!isActive) { // NEW: Check if account is active
                    showError("Your account is currently inactive. Please contact the administrator.");
                    return;
                }

                // Compare plain text password directly
                if (password.equals(storedPassword)) {
                    loggedInUser = new User(rs.getInt("id"), rs.getString("username"), rs.getString("role"), rs.getString("full_name"), isActive); // NEW: Pass isActive
                    showInfo("Login successful! Welcome, " + loggedInUser.getFullName());

                    String updateLoginSql = "UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE id = ?";
                    try (PreparedStatement updatePstmt = connection.prepareStatement(updateLoginSql)) {
                        updatePstmt.setInt(1, loggedInUser.getId());
                        updatePstmt.executeUpdate();
                    }

                    if ("admin".equals(loggedInUser.getRole())) {
                        showAdminDashboard();
                    } else if ("teacher".equals(loggedInUser.getRole())) {
                        showTeacherDashboard();
                    } else if ("student".equals(loggedInUser.getRole())) {
                        showStudentDashboard();
                    }
                } else {
                    showError("Invalid username or password.");
                }
            } else {
                showError("Invalid username or password.");
            }
        } catch (SQLException e) {
            showError("Authentication error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void showAdminDashboard() {
        adminDashboardInstance = new AdminDashboard(this); // Store the instance
        mainPanel.add(adminDashboardInstance, "AdminDashboard");
        cardLayout.show(mainPanel, "AdminDashboard");
        setTitle("Admin Dashboard - OTP Attendance System");
    }

    private void showTeacherDashboard() {
        TeacherDashboard teacherDashboard = new TeacherDashboard(this);
        mainPanel.add(teacherDashboard, "TeacherDashboard");
        cardLayout.show(mainPanel, "TeacherDashboard");
        setTitle("Teacher Dashboard - OTP Attendance System");
    }

    private void showStudentDashboard() {
        StudentDashboard studentDashboard = new StudentDashboard(this);
        mainPanel.add(studentDashboard, "StudentDashboard");
        cardLayout.show(mainPanel, "StudentDashboard");
        setTitle("Student Dashboard - OTP Attendance System");
    }

    // --- OTP Management Methods ---
    private String generateOTP() {
        Random random = new Random();
        int otp = 100000 + random.nextInt(900000); // 6-digit OTP
        return String.valueOf(otp);
    }

    private void startOTPTimer() {
        if (otpTimer != null) {
            otpTimer.cancel();
        }
        otpTimer = new Timer();
        currentOTP = generateOTP(); // Generate new OTP here
        otpExpiryTime = System.currentTimeMillis() + (1 * 60 * 1000); // 1 minute expiry
        prefs.put(PREF_OTP_KEY, currentOTP);
        prefs.putLong(PREF_OTP_EXPIRY_KEY, otpExpiryTime);

        otpTimer.scheduleAtFixedRate(new TimerTask() {
            private int secondsLeft = 60;

            @Override
            public void run() {
                if (secondsLeft > 0) {
                    SwingUtilities.invokeLater(() -> {
                        if (adminDashboardInstance != null) { // Use the stored instance
                            adminDashboardInstance.updateOtpStatus("Current OTP: " + currentOTP + " (Expires in " + secondsLeft + "s)");
                        }
                    });
                    secondsLeft--;
                } else {
                    SwingUtilities.invokeLater(() -> {
                        currentOTP = null;
                        otpExpiryTime = 0;
                        prefs.remove(PREF_OTP_KEY);
                        prefs.remove(PREF_OTP_EXPIRY_KEY);
                        if (adminDashboardInstance != null) { // Use the stored instance
                            adminDashboardInstance.updateOtpStatus("Current OTP: Expired!");
                            showInfo("OTP has expired.");
                        }
                    });
                    otpTimer.cancel();
                }
            }
        }, 0, 1000); // Update every second
    }

    private void loadAndRestoreOTP() {
        currentOTP = prefs.get(PREF_OTP_KEY, null);
        otpExpiryTime = prefs.getLong(PREF_OTP_EXPIRY_KEY, 0);

        if (currentOTP != null && System.currentTimeMillis() < otpExpiryTime) {
            long remainingSeconds = (otpExpiryTime - System.currentTimeMillis()) / 1000;
            if (remainingSeconds > 0) {
                if (otpTimer != null) {
                    otpTimer.cancel();
                }
                otpTimer = new Timer();
                otpTimer.scheduleAtFixedRate(new TimerTask() {
                    private long secondsLeft = remainingSeconds;

                    @Override
                    public void run() {
                        if (secondsLeft > 0) {
                            SwingUtilities.invokeLater(() -> {
                                if (adminDashboardInstance != null) { // Use the stored instance
                                    adminDashboardInstance.updateOtpStatus("Current OTP: " + currentOTP + " (Expires in " + secondsLeft + "s)");
                                }
                            });
                            secondsLeft--;
                        } else {
                            SwingUtilities.invokeLater(() -> {
                                currentOTP = null;
                                otpExpiryTime = 0;
                                prefs.remove(PREF_OTP_KEY);
                                prefs.remove(PREF_OTP_EXPIRY_KEY);
                                if (adminDashboardInstance != null) { // Use the stored instance
                                    adminDashboardInstance.updateOtpStatus("Current OTP: Expired!");
                                    showInfo("OTP has expired.");
                                }
                            });
                            otpTimer.cancel();
                        }
                    }
                }, 0, 1000);
            } else {
                currentOTP = null;
                otpExpiryTime = 0;
                prefs.remove(PREF_OTP_KEY);
                prefs.remove(PREF_OTP_EXPIRY_KEY);
            }
        } else {
            currentOTP = null;
            otpExpiryTime = 0;
            prefs.remove(PREF_OTP_KEY);
            prefs.remove(PREF_OTP_EXPIRY_KEY);
        }
    }


    // --- Common UI Helper Methods ---
    void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Error", JOptionPane.ERROR_MESSAGE);
    }

    void showInfo(String message) {
        JOptionPane.showMessageDialog(this, message, "Information", JOptionPane.INFORMATION_MESSAGE);
    }

    void showSuccess(String message) {
        JOptionPane.showMessageDialog(this, message, "Success", JOptionPane.INFORMATION_MESSAGE);
    }

    // Custom confirmation dialog
    int showConfirmDialogCustom(Component parentComponent, String message, String title, int optionType) {
        JDialog dialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(parentComponent), title, true);
        dialog.setLayout(new BorderLayout(10, 10));
        dialog.setBackground(UIUtils.PANEL_COLOR);
        dialog.setResizable(false);

        JLabel messageLabel = new JLabel(message, SwingConstants.CENTER);
        messageLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        messageLabel.setBorder(new EmptyBorder(15, 15, 5, 15));
        dialog.add(messageLabel, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        buttonPanel.setBackground(UIUtils.PANEL_COLOR);

        JButton yesButton = new JButton("Yes");
        UIUtils.applyButtonStyle(yesButton);
        JButton noButton = new JButton("No");
        UIUtils.applyButtonStyle(noButton);
        noButton.setBackground(UIUtils.DANGER_COLOR); // Style No button differently

        final int[] result = {JOptionPane.CANCEL_OPTION}; // Default to CANCEL

        yesButton.addActionListener(e -> {
            result[0] = JOptionPane.YES_OPTION;
            dialog.dispose();
        });
        noButton.addActionListener(e -> {
            result[0] = JOptionPane.NO_OPTION;
            dialog.dispose();
        });

        buttonPanel.add(yesButton);
        buttonPanel.add(noButton);
        dialog.add(buttonPanel, BorderLayout.SOUTH);

        dialog.pack();
        dialog.setLocationRelativeTo(parentComponent);
        dialog.setVisible(true);

        return result[0];
    }


    void showLoginPanel() {
        loggedInUser = null;
        if (otpTimer != null) {
            otpTimer.cancel();
            otpTimer = null;
        }
        usernameField.setText("");
        passwordField.setText("");
        cardLayout.show(mainPanel, "Login");
        setTitle("OTP Attendance System");
    }

    // Helper for email validation
    private boolean isValidEmail(String email) {
        return email != null && email.matches("^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,6}$");
    }

    // --- Automated Attendance Reminder Logic ---
    private void startAutomatedAttendanceReminders() {
        int reminderHour = getSystemSettingInt("attendance_reminder_time_hour", 9);
        int reminderMinute = getSystemSettingInt("attendance_reminder_time_minute", 0);
        boolean enabled = getSystemSettingBoolean("enable_attendance_reminders", true);

        if (!enabled) {
            System.out.println("Automated attendance reminders are disabled.");
            return;
        }

        java.util.Calendar now = java.util.Calendar.getInstance();
        java.util.Calendar firstRun = (java.util.Calendar) now.clone();
        firstRun.set(java.util.Calendar.HOUR_OF_DAY, reminderHour);
        firstRun.set(java.util.Calendar.MINUTE, reminderMinute);
        firstRun.set(java.util.Calendar.SECOND, 0);

        if (firstRun.before(now)) {
            firstRun.add(java.util.Calendar.DATE, 1);
        }

        long initialDelay = firstRun.getTimeInMillis() - now.getTimeInMillis();
        long dailyInterval = TimeUnit.DAYS.toMillis(1);

        System.out.println("Scheduling daily attendance reminders to run at " + reminderHour + ":" + reminderMinute + ".");
        System.out.println("First run in " + TimeUnit.MILLISECONDS.toMinutes(initialDelay) + " minutes.");

        reminderScheduler.scheduleAtFixedRate(() -> {
            try {
                if (!getSystemSettingBoolean("enable_attendance_reminders", true)) {
                    System.out.println("Automated attendance reminders disabled during runtime. Cancelling task.");
                    reminderScheduler.shutdown();
                    return;
                }
                sendAttendanceReminders();
            } catch (Exception e) {
                System.err.println("Error in automated attendance reminder task: " + e.getMessage());
                e.printStackTrace();
            }
        }, initialDelay, dailyInterval, TimeUnit.MILLISECONDS);
    }

    private void sendAttendanceReminders() {
        System.out.println("Running automated attendance reminder check...");
        List<Integer> studentsToRemind = new ArrayList<>();
        // Select students who are enrolled in at least one course and haven't marked attendance today for any of their courses
        String sql = "SELECT DISTINCT s.id, s.user_id FROM students s " +
                     "JOIN student_courses sc ON s.id = sc.student_id " +
                     "WHERE NOT EXISTS (SELECT 1 FROM attendance a WHERE a.student_id = s.id AND a.date = CURDATE() AND a.course_id = sc.course_id)";

        try (PreparedStatement pstmt = connection.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            while (rs.next()) {
                studentsToRemind.add(rs.getInt("user_id")); // Get the user_id to send announcement
            }
        } catch (SQLException e) {
            System.err.println("Error checking for students to remind: " + e.getMessage());
            e.printStackTrace();
            return;
        }

        if (studentsToRemind.isEmpty()) {
            System.out.println("All students have marked attendance today or no students are enrolled. No reminders sent.");
            return;
        }

        String subject = "Attendance Reminder!";
        String message = "Dear student, this is a friendly reminder to mark your attendance for today. Please do so as soon as possible.";

        try {
            connection.setAutoCommit(false);

            // Insert a single announcement for all students to be reminded
            String insertAnnouncementSql = "INSERT INTO announcements (sender_user_id, subject, message, send_to_role, target_course_id) VALUES (?, ?, ?, ?, ?)";
            int announcementId;
            try (PreparedStatement pstmt = connection.prepareStatement(insertAnnouncementSql, Statement.RETURN_GENERATED_KEYS)) {
                pstmt.setInt(1, 0); // Use 0 for system sender (assuming user ID 0 is reserved for system)
                pstmt.setString(2, subject);
                pstmt.setString(3, message);
                pstmt.setString(4, "specific_students"); // Custom role for targeted reminders
                pstmt.setNull(5, Types.INTEGER); // No specific course target for this general reminder
                pstmt.executeUpdate();
                ResultSet generatedKeys = pstmt.getGeneratedKeys();
                if (generatedKeys.next()) {
                    announcementId = generatedKeys.getInt(1);
                } else {
                    throw new SQLException("Creating reminder announcement failed, no ID obtained.");
                }
            }

            // Insert entries into user_announcements for each student to remind
            String insertUserAnnouncementSql = "INSERT INTO user_announcements (announcement_id, recipient_user_id) VALUES (?, ?)";
            try (PreparedStatement batchPstmt = connection.prepareStatement(insertUserAnnouncementSql)) {
                for (Integer userId : studentsToRemind) {
                    batchPstmt.setInt(1, announcementId);
                    batchPstmt.setInt(2, userId);
                    batchPstmt.addBatch();
                }
                batchPstmt.executeBatch();
            }

            connection.commit();
            System.out.println("Sent attendance reminders to " + studentsToRemind.size() + " students.");
        } catch (SQLException e) {
            try {
                connection.rollback();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            System.err.println("Error sending automated attendance reminders: " + e.getMessage());
            e.printStackTrace();
        } finally {
            try {
                connection.setAutoCommit(true);
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    private String getSystemSetting(String key, String defaultValue) {
        String value = defaultValue;
        String sql = "SELECT setting_value FROM system_settings WHERE setting_key = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, key);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                value = rs.getString("setting_value");
            }
        } catch (SQLException e) {
            System.err.println("Error reading system setting '" + key + "': " + e.getMessage());
        }
        return value;
    }

    private void updateSystemSetting(String key, String value) {
        String sql = "INSERT INTO system_settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, key);
            pstmt.setString(2, value);
            pstmt.setString(3, value);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            showError("Error saving system setting '" + key + "': " + e.getMessage());
            e.printStackTrace();
        }
    }

    private boolean getSystemSettingBoolean(String key, boolean defaultValue) {
        return Boolean.parseBoolean(getSystemSetting(key, String.valueOf(defaultValue)));
    }

    private int getSystemSettingInt(String key, int defaultValue) {
        try {
            return Integer.parseInt(getSystemSetting(key, String.valueOf(defaultValue)));
        } catch (NumberFormatException e) {
            return defaultValue;
        }
    }

    /**
     * Custom JPanel for drawing a simple bar chart.
     */
    static class BarChartPanel extends JPanel {
        private Map<String, Integer> attendanceCounts = new HashMap<>();
        private int totalRecords = 0;

        public BarChartPanel() {
            setBackground(UIUtils.PANEL_COLOR);
        }

        public void updateChartData(int present, int absent, int leave) {
            attendanceCounts.clear();
            attendanceCounts.put("Present", present);
            attendanceCounts.put("Absent", absent);
            attendanceCounts.put("Leave", leave);
            totalRecords = present + absent + leave;
            repaint(); // Redraw the chart
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            // FIX: Changed Graphics2d to Graphics2D (case sensitivity)
            Graphics2D g2d = (Graphics2D) g;
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            int width = getWidth();
            int height = getHeight();
            int barWidth = 60;
            int spacing = 30;
            int startX = (width - (3 * barWidth + 2 * spacing)) / 2;
            int startY = height - 30; // Base of the bars

            g2d.setColor(UIUtils.TEXT_COLOR);
            g2d.setFont(new Font("Arial", Font.BOLD, 12));
            g2d.drawString("Overall Attendance Distribution", width / 2 - 100, 20);

            if (totalRecords == 0) {
                g2d.setColor(UIUtils.TEXT_COLOR);
                g2d.drawString("No attendance data for chart.", width / 2 - 80, height / 2);
                return;
            }

            int maxCount = 0;
            for (int count : attendanceCounts.values()) {
                if (count > maxCount) {
                    maxCount = count;
                }
            }
            if (maxCount == 0) maxCount = 1; // Avoid division by zero

            int i = 0;
            for (Map.Entry<String, Integer> entry : attendanceCounts.entrySet()) {
                String status = entry.getKey();
                int count = entry.getValue();
                double percentage = (double) count / totalRecords;

                int barHeight = (int) ((double) count / maxCount * (height - 80)); // Scale height
                if (barHeight < 0) barHeight = 0; // Ensure non-negative height

                int x = startX + i * (barWidth + spacing);
                int y = startY - barHeight;

                Color barColor = Color.GRAY;
                if ("Present".equals(status)) {
                    barColor = UIUtils.CHART_BAR_COLOR_PRESENT;
                } else if ("Absent".equals(status)) {
                    barColor = UIUtils.CHART_BAR_COLOR_ABSENT;
                } else if ("Leave".equals(status)) {
                    barColor = UIUtils.CHART_BAR_COLOR_LEAVE;
                }

                g2d.setColor(barColor);
                g2d.fillRect(x, y, barWidth, barHeight);
                g2d.setColor(Color.BLACK);
                g2d.drawRect(x, y, barWidth, barHeight); // Border

                // Draw value on top of bar
                g2d.setColor(UIUtils.TEXT_COLOR);
                String valueStr = String.valueOf(count);
                int valueWidth = g2d.getFontMetrics().stringWidth(valueStr);
                g2d.drawString(valueStr, x + (barWidth - valueWidth) / 2, y - 5);

                // Draw label below bar
                int labelWidth = g2d.getFontMetrics().stringWidth(status);
                g2d.drawString(status, x + (barWidth - labelWidth) / 2, startY + 15);

                // Draw percentage
                String percentStr = new DecimalFormat("0.0%").format(percentage);
                int percentWidth = g2d.getFontMetrics().stringWidth(percentStr);
                g2d.drawString(percentStr, x + (barWidth - percentWidth) / 2, startY + 30);

                i++;
            }

            // Draw X-axis line
            g2d.setColor(Color.BLACK);
            g2d.drawLine(startX - 10, startY, startX + 3 * barWidth + 2 * spacing + 10, startY);
        }

        @Override
        public Dimension getPreferredSize() {
            return new Dimension(400, 200); // Fixed size for the chart panel
        }
    }


    // --- Dashboard Classes (Admin, Teacher, Student) ---

    /**
     * A generic collapsible sidebar panel for dashboards.
     */
    class CollapsibleSidebar extends JPanel {
        private JPanel sidebarPanel;
        private JPanel contentPanel;
        private CardLayout contentCardLayout;
        private JButton toggleButton;
        private JSplitPane splitPane;
        private boolean sidebarCollapsed = false;
        private int collapsedWidth = 30; // Width when collapsed (just enough for toggle button)
        private int expandedWidth = 200; // Width when expanded

        public CollapsibleSidebar(String welcomeMessage, Runnable logoutAction) {
            super(new BorderLayout());
            setBackground(UIUtils.BACKGROUND_COLOR);

            // Top Panel with Welcome and Logout
            JPanel topPanel = new JPanel(new BorderLayout());
            topPanel.setBackground(UIUtils.ACCENT_COLOR);
            JLabel welcomeLabel = new JLabel(welcomeMessage, SwingConstants.LEFT);
            welcomeLabel.setForeground(UIUtils.BUTTON_TEXT_COLOR);
            welcomeLabel.setFont(new Font("Arial", Font.BOLD, 16));
            welcomeLabel.setBorder(new EmptyBorder(10, 10, 10, 10));

            JButton logoutButton = new JButton("Logout");
            UIUtils.applyButtonStyle(logoutButton);
            logoutButton.setBackground(UIUtils.DANGER_COLOR);
            logoutButton.addMouseListener(new java.awt.event.MouseAdapter() {
                public void mouseEntered(java.awt.event.MouseEvent evt) {
                    logoutButton.setBackground(new Color(255, 80, 80));
                }
                public void mouseExited(java.awt.event.MouseEvent evt) {
                    logoutButton.setBackground(UIUtils.DANGER_COLOR);
                }
            });
            logoutButton.addActionListener(e -> logoutAction.run());

            topPanel.add(welcomeLabel, BorderLayout.WEST);
            JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
            buttonPanel.setBackground(UIUtils.ACCENT_COLOR);
            buttonPanel.add(logoutButton);
            topPanel.add(buttonPanel, BorderLayout.EAST);
            add(topPanel, BorderLayout.NORTH);

            // Sidebar Panel
            sidebarPanel = new JPanel();
            sidebarPanel.setLayout(new BoxLayout(sidebarPanel, BoxLayout.Y_AXIS));
            sidebarPanel.setBackground(UIUtils.PANEL_COLOR);
            sidebarPanel.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 1, UIUtils.BORDER_COLOR));

            // Content Panel
            contentCardLayout = new CardLayout();
            contentPanel = new JPanel(contentCardLayout);
            contentPanel.setBackground(UIUtils.BACKGROUND_COLOR);

            // Split Pane
            splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, sidebarPanel, contentPanel);
            splitPane.setDividerSize(5);
            splitPane.setDividerLocation(expandedWidth); // Initial expanded state
            splitPane.setEnabled(false); // Disable manual resizing

            add(splitPane, BorderLayout.CENTER);

            // Toggle Button for Sidebar
            toggleButton = new JButton("<"); // Initial text for expanded state
            toggleButton.setFont(new Font("Arial", Font.BOLD, 10));
            toggleButton.setMargin(new Insets(0, 0, 0, 0));
            toggleButton.setPreferredSize(new Dimension(collapsedWidth, 30));
            toggleButton.setMaximumSize(new Dimension(collapsedWidth, 30));
            toggleButton.setBackground(UIUtils.ACCENT_COLOR);
            toggleButton.setForeground(UIUtils.BUTTON_TEXT_COLOR);
            toggleButton.setBorderPainted(false);
            toggleButton.setFocusPainted(false);
            toggleButton.addActionListener(e -> toggleSidebar());

            // Add toggle button to a small panel on the right of the sidebar
            JPanel togglePanel = new JPanel(new BorderLayout());
            togglePanel.setBackground(UIUtils.PANEL_COLOR);
            togglePanel.add(toggleButton, BorderLayout.NORTH);
            sidebarPanel.add(togglePanel, BorderLayout.NORTH); // Add to sidebar, not directly to split pane

            // Add a filler to push buttons to top
            sidebarPanel.add(Box.createVerticalStrut(40)); // Space for toggle button
        }

        public void addMenuItem(String name, JPanel panel) {
            JButton menuItem = new JButton(name);
            UIUtils.applyButtonStyle(menuItem);
            menuItem.setAlignmentX(Component.CENTER_ALIGNMENT);
            menuItem.setMaximumSize(new Dimension(Integer.MAX_VALUE, menuItem.getPreferredSize().height)); // Make button fill width
            menuItem.addActionListener(e -> showContent(name));
            sidebarPanel.add(menuItem);
            sidebarPanel.add(Box.createVerticalStrut(5)); // Spacing between buttons

            contentPanel.add(panel, name);
        }

        public void showContent(String name) {
            contentCardLayout.show(contentPanel, name);
        }

        private void toggleSidebar() {
            if (sidebarCollapsed) {
                // Expand
                splitPane.setDividerLocation(expandedWidth);
                sidebarPanel.setPreferredSize(new Dimension(expandedWidth, sidebarPanel.getHeight()));
                sidebarPanel.setMinimumSize(new Dimension(expandedWidth, sidebarPanel.getHeight()));
                toggleButton.setText("<");
                // Make menu items visible
                for (Component comp : sidebarPanel.getComponents()) {
                    if (comp instanceof JButton && comp != toggleButton) {
                        comp.setVisible(true);
                    }
                }
            } else {
                // Collapse
                splitPane.setDividerLocation(collapsedWidth);
                sidebarPanel.setPreferredSize(new Dimension(collapsedWidth, sidebarPanel.getHeight()));
                sidebarPanel.setMinimumSize(new Dimension(collapsedWidth, sidebarPanel.getHeight()));
                toggleButton.setText(">");
                // Hide menu items
                for (Component comp : sidebarPanel.getComponents()) {
                    if (comp instanceof JButton && comp != toggleButton) {
                        comp.setVisible(false);
                    }
                }
            }
            sidebarCollapsed = !sidebarCollapsed;
            revalidate();
            repaint();
        }

        // Method to select a specific menu item and show its content
        public void selectMenuItem(String name) {
            showContent(name);
            // Optionally highlight the selected button
            for (Component comp : sidebarPanel.getComponents()) {
                if (comp instanceof JButton && comp != toggleButton) {
                    JButton button = (JButton) comp;
                    if (button.getText().equals(name)) {
                        button.setBackground(UIUtils.BUTTON_HOVER_COLOR); // Highlight
                    } else {
                        UIUtils.applyButtonStyle(button); // Reset others
                    }
                }
            }
        }
    }


    // Admin Dashboard
    class AdminDashboard extends JPanel {
        private OTPAttendanceSystem parentFrame;
        private CollapsibleSidebar sidebar; // Replaced JTabbedPane

        // Components for Student Management Tab
        private DefaultTableModel studentTableModel;
        private JTable studentTable;
        // NEW FEATURE: Student Profile Functionality (phone_number, address, interests, bio)
        private JTextField studentNameField, studentRollField, studentFatherNameField, studentEmailField, studentPhoneField;
        private JTextArea studentAddressArea, studentInterestsArea, studentBioArea;
        // NEW FEATURE: User Account Status - Student
        private JCheckBox studentIsActiveCheckbox;
        private JButton addStudentButton, updateStudentButton, deleteStudentButton, viewStudentPictureButton, toggleStudentStatusButton, uploadStudentPictureButton;
        private JLabel studentProfilePictureLabel; // To display student profile picture
        private String currentStudentProfilePicturePath; // Path of the currently displayed picture
        private JTextField studentSearchField; // NEW: Search field for student management
        private JButton searchStudentsButton; // NEW: Search button for student management
        private TableRowSorter<DefaultTableModel> studentSorter; // Sorter for student table

        // Components for Course Management Tab
        private DefaultTableModel courseTableModel;
        private JTable courseTable;
        // NEW FEATURE: Geofencing for Attendance
        private JTextField courseNameField, courseExpectedLatField, courseExpectedLonField, courseGeofenceRadiusField;
        private JComboBox<String> teacherComboBox;
        private JButton addCourseButton, updateCourseButton, deleteCourseButton;

        // Components for Teacher Management Tab
        private DefaultTableModel teacherTableModel;
        private JTable teacherTable;
        private JTextField teacherUsernameField, teacherFullNameField;
        private JPasswordField teacherPasswordField;
        // NEW FEATURE: User Account Status - Teacher
        private JCheckBox teacherIsActiveCheckbox;
        private JButton addTeacherButton, updateTeacherButton, deleteTeacherButton, toggleTeacherStatusButton;

        // Components for Attendance Reporting Tab
        private DefaultTableModel attendanceSummaryTableModel;
        private JTable attendanceSummaryTable;
        private JTextField startDateField, endDateField;
        private JButton generateSummaryButton, exportSummaryButton;
        private JComboBox<String> reportCourseFilterComboBox;
        private JComboBox<String> reportTeacherFilterComboBox;
        private JComboBox<String> reportStatusFilterComboBox;
        private JTextField reportStudentRollFilterField; // NEW: Student Roll filter field
        private JButton searchAttendanceReportButton; // NEW: Search button for attendance report
        private TableRowSorter<DefaultTableModel> attendanceReportSorter; // Sorter for attendance report table
        private JButton generateDetailedReportButton;
        // NEW: Labels for overall attendance summary
        private JLabel overallTotalClassesLabel, overallPresentCountLabel, overallAbsentCountLabel, overallLeaveCountLabel, overallAttendancePercentageLabel;
        private BarChartPanel overallAttendanceChartPanel; // Custom JPanel for chart
        private JTextArea overallAttendanceTrendArea;


        // Components for Announcement Management Tab
        private DefaultTableModel sentAnnouncementsTableModel;
        private JTable sentAnnouncementsTable;
        private JTextField announcementSubjectField;
        private JTextArea announcementMessageArea;
        private JComboBox<String> announcementRecipientRoleComboBox;
        private JComboBox<String> announcementTargetCourseComboBox; // For specific_course
        private JTextField announcementTargetStudentsField; // For specific_students (comma-separated student IDs)
        private JButton sendAnnouncementButton, deleteAnnouncementButton;
        private JCheckBox markAsReadCheckbox; // For new announcement read status

        // Components for Enrollment Request Management Tab
        private DefaultTableModel enrollmentRequestsTableModel;
        private JTable enrollmentRequestsTable;
        private JButton approveEnrollmentButton, rejectEnrollmentButton;

        // Components for Leave Request Management Tab
        private DefaultTableModel leaveRequestsTableModel;
        private JTable leaveRequestsTable;
        private JButton approveLeaveButton, rejectLeaveButton;

        // Components for System Settings Tab
        private JCheckBox enableRemindersCheckbox;
        private JSpinner reminderHourSpinner, reminderMinuteSpinner;
        private JButton saveReminderSettingsButton;
        private JTextField defaultGeofenceRadiusField;
        private JButton saveGeofenceSettingsButton;

        // Components for User Account Management Tab
        private DefaultTableModel userAccountTableModel;
        private JTable userAccountTable;
        private JButton toggleUserAccountStatusButton;
        private JTextField userAccountSearchField;
        private JButton searchUserAccountsButton;
        private TableRowSorter<DefaultTableModel> userAccountSorter;


        public AdminDashboard(OTPAttendanceSystem parent) {
            this.parentFrame = parent;
            setLayout(new BorderLayout());
            setBackground(UIUtils.BACKGROUND_COLOR);

            String welcomeMsg = "Welcome, " + loggedInUser.getFullName() + " (Admin)";
            sidebar = new CollapsibleSidebar(welcomeMsg, () -> parentFrame.showLoginPanel());
            add(sidebar, BorderLayout.CENTER);

            // Initialize and add tabs
            setupStudentManagementTab();
            setupTeacherManagementTab();
            setupCourseManagementTab();
            setupAttendanceReportingTab();
            setupAnnouncementManagementTab();
            setupEnrollmentRequestManagementTab();
            setupLeaveRequestManagementTab();
            setupSystemSettingsTab();
            setupUserAccountManagementTab();

            // Initial selection
            sidebar.selectMenuItem("Student Management");
        }

        // Method to update OTP status label in Admin Dashboard
        public void updateOtpStatus(String status) {
            if (otpLabel != null) {
                SwingUtilities.invokeLater(() -> otpLabel.setText(status));
            }
        }

        private void setupStudentManagementTab() {
            JPanel studentPanel = new JPanel(new BorderLayout(10, 10));
            studentPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
            studentPanel.setBackground(UIUtils.BACKGROUND_COLOR);

            // --- Form Panel ---
            JPanel formPanel = new JPanel(new GridBagLayout());
            formPanel.setBackground(UIUtils.PANEL_COLOR);
            formPanel.setBorder(UIUtils.createPanelBorder());
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.insets = new Insets(5, 5, 5, 5);
            gbc.fill = GridBagConstraints.HORIZONTAL;

            JLabel titleLabel = new JLabel("Manage Students", SwingConstants.CENTER);
            titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
            titleLabel.setForeground(UIUtils.ACCENT_COLOR);
            gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 4;
            formPanel.add(titleLabel, gbc);

            gbc.gridwidth = 1;

            // Row 1: Name, Roll
            gbc.gridx = 0; gbc.gridy = 1; formPanel.add(new JLabel("Name:"), gbc);
            gbc.gridx = 1; studentNameField = new JTextField(15); formPanel.add(studentNameField, gbc);
            gbc.gridx = 2; formPanel.add(new JLabel("Roll No:"), gbc);
            gbc.gridx = 3; studentRollField = new JTextField(15); formPanel.add(studentRollField, gbc);

            // Row 2: Father Name, Email
            gbc.gridx = 0; gbc.gridy = 2; formPanel.add(new JLabel("Father Name:"), gbc);
            gbc.gridx = 1; studentFatherNameField = new JTextField(15); formPanel.add(studentFatherNameField, gbc);
            gbc.gridx = 2; formPanel.add(new JLabel("Email:"), gbc);
            gbc.gridx = 3; studentEmailField = new JTextField(15); formPanel.add(studentEmailField, gbc);

            // Row 3: Phone, Address
            gbc.gridx = 0; gbc.gridy = 3; formPanel.add(new JLabel("Phone:"), gbc);
            gbc.gridx = 1; studentPhoneField = new JTextField(15); formPanel.add(studentPhoneField, gbc);
            gbc.gridx = 2; formPanel.add(new JLabel("Address:"), gbc);
            gbc.gridx = 3; studentAddressArea = new JTextArea(3, 15); studentAddressArea.setLineWrap(true); studentAddressArea.setWrapStyleWord(true);
            JScrollPane addressScrollPane = new JScrollPane(studentAddressArea);
            formPanel.add(addressScrollPane, gbc);

            // Row 4: Interests, Bio
            gbc.gridx = 0; gbc.gridy = 4; formPanel.add(new JLabel("Interests:"), gbc);
            gbc.gridx = 1; studentInterestsArea = new JTextArea(3, 15); studentInterestsArea.setLineWrap(true); studentInterestsArea.setWrapStyleWord(true);
            JScrollPane interestsScrollPane = new JScrollPane(studentInterestsArea);
            formPanel.add(interestsScrollPane, gbc);
            gbc.gridx = 2; formPanel.add(new JLabel("Bio:"), gbc);
            gbc.gridx = 3; studentBioArea = new JTextArea(3, 15); studentBioArea.setLineWrap(true); studentBioArea.setWrapStyleWord(true);
            JScrollPane bioScrollPane = new JScrollPane(studentBioArea);
            formPanel.add(bioScrollPane, gbc);

            // Row 5: Profile Picture & Active Status
            gbc.gridx = 0; gbc.gridy = 5; formPanel.add(new JLabel("Profile Picture:"), gbc);
            gbc.gridx = 1;
            JPanel picPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
            uploadStudentPictureButton = new JButton("Upload");
            UIUtils.applyButtonStyle(uploadStudentPictureButton);
            uploadStudentPictureButton.addActionListener(e -> uploadStudentProfilePicture());
            picPanel.add(uploadStudentPictureButton);
            viewStudentPictureButton = new JButton("View");
            UIUtils.applyButtonStyle(viewStudentPictureButton);
            viewStudentPictureButton.addActionListener(e -> viewStudentProfilePicture());
            picPanel.add(viewStudentPictureButton);
            formPanel.add(picPanel, gbc);

            gbc.gridx = 2; gbc.gridy = 5; formPanel.add(new JLabel("Account Active:"), gbc);
            gbc.gridx = 3; studentIsActiveCheckbox = new JCheckBox(); studentIsActiveCheckbox.setSelected(true); formPanel.add(studentIsActiveCheckbox, gbc);

            // Profile Picture Display Label
            gbc.gridx = 0; gbc.gridy = 6; gbc.gridwidth = 4;
            studentProfilePictureLabel = new JLabel();
            studentProfilePictureLabel.setHorizontalAlignment(SwingConstants.CENTER);
            studentProfilePictureLabel.setPreferredSize(new Dimension(100, 100)); // Placeholder size
            studentProfilePictureLabel.setBorder(BorderFactory.createLineBorder(UIUtils.BORDER_COLOR));
            formPanel.add(studentProfilePictureLabel, gbc);
            gbc.gridwidth = 1; // Reset gridwidth

            // Row 6: Buttons
            JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
            addStudentButton = new JButton("Add Student");
            UIUtils.applyButtonStyle(addStudentButton);
            addStudentButton.addActionListener(e -> addStudent());
            buttonPanel.add(addStudentButton);

            updateStudentButton = new JButton("Update Student");
            UIUtils.applyButtonStyle(updateStudentButton);
            updateStudentButton.addActionListener(e -> updateStudent());
            buttonPanel.add(updateStudentButton);

            deleteStudentButton = new JButton("Delete Student");
            UIUtils.applyButtonStyle(deleteStudentButton);
            deleteStudentButton.setBackground(UIUtils.DANGER_COLOR);
            deleteStudentButton.addActionListener(e -> deleteStudent());
            buttonPanel.add(deleteStudentButton);

            toggleStudentStatusButton = new JButton("Toggle Status");
            UIUtils.applyButtonStyle(toggleStudentStatusButton);
            toggleStudentStatusButton.setBackground(UIUtils.WARNING_COLOR);
            toggleStudentStatusButton.addActionListener(e -> toggleStudentAccountStatus());
            buttonPanel.add(toggleStudentStatusButton);

            gbc.gridx = 0; gbc.gridy = 7; gbc.gridwidth = 4;
            formPanel.add(buttonPanel, gbc);

            studentPanel.add(formPanel, BorderLayout.NORTH);

            // --- Table Panel ---
            String[] studentColumnNames = {"ID", "User ID", "Name", "Roll No", "Father Name", "Email", "Phone", "Address", "Interests", "Bio", "Active"};
            studentTableModel = new DefaultTableModel(studentColumnNames, 0) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false; // Make table non-editable
                }
            };
            studentTable = new JTable(studentTableModel);
            UIUtils.styleTable(studentTable);
            studentSorter = new TableRowSorter<>(studentTableModel);
            studentTable.setRowSorter(studentSorter);

            studentTable.getSelectionModel().addListSelectionListener(e -> {
                if (!e.getValueIsAdjusting() && studentTable.getSelectedRow() != -1) {
                    displayStudentDetails(studentTable.convertRowIndexToModel(studentTable.getSelectedRow()));
                }
            });

            JScrollPane studentTableScrollPane = new JScrollPane(studentTable);
            studentTableScrollPane.setBorder(UIUtils.createPanelBorder());
            studentPanel.add(studentTableScrollPane, BorderLayout.CENTER);

            // --- Search Panel for Student Management ---
            JPanel studentSearchPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 5));
            studentSearchPanel.setBackground(UIUtils.BACKGROUND_COLOR);
            studentSearchPanel.add(new JLabel("Search:"));
            studentSearchField = new JTextField(20);
            studentSearchPanel.add(studentSearchField);
            searchStudentsButton = new JButton("Search Students");
            UIUtils.applyButtonStyle(searchStudentsButton);
            searchStudentsButton.addActionListener(e -> applyStudentSearchFilter(studentSearchField.getText()));
            studentSearchField.addActionListener(e -> applyStudentSearchFilter(studentSearchField.getText())); // Enable search on Enter
            studentSearchPanel.add(searchStudentsButton);


            studentPanel.add(studentSearchPanel, BorderLayout.SOUTH);


            sidebar.addMenuItem("Student Management", studentPanel);
            loadStudents(); // Load students when the tab is set up
        }

        private void loadStudents() {
            studentTableModel.setRowCount(0); // Clear existing data
            String sql = "SELECT s.id, s.roll_no, s.name, s.father_name, s.email, s.phone_number, s.address, s.interests, s.bio, s.profile_picture_path, u.id as user_id, u.is_active " +
                         "FROM students s JOIN users u ON s.user_id = u.id ORDER BY s.name ASC";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                ResultSet rs = pstmt.executeQuery();
                while (rs.next()) {
                    Vector<Object> row = new Vector<>();
                    row.add(rs.getInt("id"));
                    row.add(rs.getInt("user_id"));
                    row.add(rs.getString("name"));
                    row.add(rs.getString("roll_no"));
                    row.add(rs.getString("father_name"));
                    row.add(rs.getString("email"));
                    row.add(rs.getString("phone_number"));
                    row.add(rs.getString("address"));
                    row.add(rs.getString("interests"));
                    row.add(rs.getString("bio"));
                    row.add(rs.getBoolean("is_active"));
                    studentTableModel.addRow(row);
                }
            } catch (SQLException e) {
                parentFrame.showError("Error loading students: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private void displayStudentDetails(int modelRowIndex) {
            // Get data from the model, not the view, to handle sorting/filtering
            int studentId = (int) studentTableModel.getValueAt(modelRowIndex, 0);
            String name = (String) studentTableModel.getValueAt(modelRowIndex, 2);
            String rollNo = (String) studentTableModel.getValueAt(modelRowIndex, 3);
            String fatherName = (String) studentTableModel.getValueAt(modelRowIndex, 4);
            String email = (String) studentTableModel.getValueAt(modelRowIndex, 5);
            String phone = (String) studentTableModel.getValueAt(modelRowIndex, 6);
            String address = (String) studentTableModel.getValueAt(modelRowIndex, 7);
            String interests = (String) studentTableModel.getValueAt(modelRowIndex, 8);
            String bio = (String) studentTableModel.getValueAt(modelRowIndex, 9);
            boolean isActive = (boolean) studentTableModel.getValueAt(modelRowIndex, 10);

            studentNameField.setText(name);
            studentRollField.setText(rollNo);
            studentFatherNameField.setText(fatherName);
            studentEmailField.setText(email);
            studentPhoneField.setText(phone);
            studentAddressArea.setText(address);
            studentInterestsArea.setText(interests);
            studentBioArea.setText(bio);
            studentIsActiveCheckbox.setSelected(isActive);

            // Load profile picture
            currentStudentProfilePicturePath = getStudentProfilePicturePath(studentId);
            if (currentStudentProfilePicturePath != null && !currentStudentProfilePicturePath.isEmpty()) {
                try {
                    BufferedImage img = ImageIO.read(new File(currentStudentProfilePicturePath));
                    if (img != null) {
                        Image scaledImg = img.getScaledInstance(studentProfilePictureLabel.getWidth(), studentProfilePictureLabel.getHeight(), Image.SCALE_SMOOTH);
                        studentProfilePictureLabel.setIcon(new ImageIcon(scaledImg));
                    } else {
                        studentProfilePictureLabel.setIcon(null);
                        studentProfilePictureLabel.setText("No Image");
                    }
                } catch (IOException e) {
                    studentProfilePictureLabel.setIcon(null);
                    studentProfilePictureLabel.setText("Error loading image");
                    e.printStackTrace();
                }
            } else {
                studentProfilePictureLabel.setIcon(null);
                studentProfilePictureLabel.setText("No Picture");
            }
        }

        private void addStudent() {
            String name = studentNameField.getText().trim();
            String rollNo = studentRollField.getText().trim();
            String fatherName = studentFatherNameField.getText().trim();
            String email = studentEmailField.getText().trim();
            String phone = studentPhoneField.getText().trim();
            String address = studentAddressArea.getText().trim();
            String interests = studentInterestsArea.getText().trim();
            String bio = studentBioArea.getText().trim();
            boolean isActive = studentIsActiveCheckbox.isSelected();

            if (name.isEmpty() || rollNo.isEmpty() || fatherName.isEmpty() || email.isEmpty()) {
                parentFrame.showError("Name, Roll No, Father Name, and Email are required.");
                return;
            }
            if (!parentFrame.isValidEmail(email)) {
                parentFrame.showError("Invalid email format.");
                return;
            }

            try {
                connection.setAutoCommit(false); // Start transaction

                // 1. Create a user account for the student
                String userSql = "INSERT INTO users (username, password, role, full_name, is_active) VALUES (?, ?, ?, ?, ?)";
                int userId = -1;
                try (PreparedStatement pstmt = connection.prepareStatement(userSql, Statement.RETURN_GENERATED_KEYS)) {
                    pstmt.setString(1, rollNo); // Use roll number as username
                    pstmt.setString(2, handlePasswordStorage("password123")); // Default password, should be changed by student
                    pstmt.setString(3, "student");
                    pstmt.setString(4, name);
                    pstmt.setBoolean(5, isActive);
                    pstmt.executeUpdate();

                    ResultSet generatedKeys = pstmt.getGeneratedKeys();
                    if (generatedKeys.next()) {
                        userId = generatedKeys.getInt(1);
                    } else {
                        throw new SQLException("Creating user failed, no ID obtained.");
                    }
                }

                // 2. Create the student entry
                String studentSql = "INSERT INTO students (user_id, name, roll_no, father_name, email, phone_number, address, interests, bio, profile_picture_path) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                try (PreparedStatement pstmt = connection.prepareStatement(studentSql)) {
                    pstmt.setInt(1, userId);
                    pstmt.setString(2, name);
                    pstmt.setString(3, rollNo);
                    pstmt.setString(4, fatherName);
                    pstmt.setString(5, email);
                    pstmt.setString(6, phone.isEmpty() ? null : phone);
                    pstmt.setString(7, address.isEmpty() ? null : address);
                    pstmt.setString(8, interests.isEmpty() ? null : interests);
                    pstmt.setString(9, bio.isEmpty() ? null : bio);
                    pstmt.setString(10, currentStudentProfilePicturePath); // Save the path
                    pstmt.executeUpdate();
                }

                connection.commit(); // Commit transaction
                parentFrame.showSuccess("Student added successfully!");
                loadStudents(); // Refresh table
                clearStudentForm();
            } catch (SQLIntegrityConstraintViolationException e) {
                try { connection.rollback(); } catch (SQLException ex) { ex.printStackTrace(); }
                if (e.getMessage().contains("Duplicate entry") && e.getMessage().contains("roll_no")) {
                    parentFrame.showError("A student with this Roll Number already exists.");
                } else if (e.getMessage().contains("Duplicate entry") && e.getMessage().contains("username")) {
                    parentFrame.showError("A user with this Roll Number (username) already exists.");
                } else {
                    parentFrame.showError("Database error: " + e.getMessage());
                }
                e.printStackTrace();
            } catch (SQLException e) {
                try { connection.rollback(); } catch (SQLException ex) { ex.printStackTrace(); }
                parentFrame.showError("Error adding student: " + e.getMessage());
                e.printStackTrace();
            } finally {
                try { connection.setAutoCommit(true); } catch (SQLException ex) { ex.printStackTrace(); }
            }
        }

        private void updateStudent() {
            int selectedRow = studentTable.getSelectedRow();
            if (selectedRow == -1) {
                parentFrame.showError("Please select a student to update.");
                return;
            }

            int modelRow = studentTable.convertRowIndexToModel(selectedRow);
            int studentId = (int) studentTableModel.getValueAt(modelRow, 0);
            int userId = (int) studentTableModel.getValueAt(modelRow, 1); // Get user_id

            String name = studentNameField.getText().trim();
            String rollNo = studentRollField.getText().trim();
            String fatherName = studentFatherNameField.getText().trim();
            String email = studentEmailField.getText().trim();
            String phone = studentPhoneField.getText().trim();
            String address = studentAddressArea.getText().trim();
            String interests = studentInterestsArea.getText().trim();
            String bio = studentBioArea.getText().trim();
            boolean isActive = studentIsActiveCheckbox.isSelected();

            if (name.isEmpty() || rollNo.isEmpty() || fatherName.isEmpty() || email.isEmpty()) {
                parentFrame.showError("Name, Roll No, Father Name, and Email are required.");
                return;
            }
            if (!parentFrame.isValidEmail(email)) {
                parentFrame.showError("Invalid email format.");
                return;
            }

            try {
                connection.setAutoCommit(false); // Start transaction

                // Update user's username (if roll_no changed) and full_name, is_active
                String userUpdateSql = "UPDATE users SET username = ?, full_name = ?, is_active = ? WHERE id = ?";
                try (PreparedStatement pstmt = connection.prepareStatement(userUpdateSql)) {
                    pstmt.setString(1, rollNo); // Update username to match new roll_no
                    pstmt.setString(2, name);
                    pstmt.setBoolean(3, isActive);
                    pstmt.setInt(4, userId);
                    pstmt.executeUpdate();
                }

                // Update student details
                String studentSql = "UPDATE students SET name = ?, roll_no = ?, father_name = ?, email = ?, phone_number = ?, address = ?, interests = ?, bio = ?, profile_picture_path = ? WHERE id = ?";
                try (PreparedStatement pstmt = connection.prepareStatement(studentSql)) {
                    pstmt.setString(1, name);
                    pstmt.setString(2, rollNo);
                    pstmt.setString(3, fatherName);
                    pstmt.setString(4, email);
                    pstmt.setString(5, phone.isEmpty() ? null : phone);
                    pstmt.setString(6, address.isEmpty() ? null : address);
                    pstmt.setString(7, interests.isEmpty() ? null : interests);
                    pstmt.setString(8, bio.isEmpty() ? null : bio);
                    pstmt.setString(9, currentStudentProfilePicturePath); // Save the path
                    pstmt.setInt(10, studentId);
                    pstmt.executeUpdate();
                }

                connection.commit(); // Commit transaction
                parentFrame.showSuccess("Student updated successfully!");
                loadStudents(); // Refresh table
                clearStudentForm();
            } catch (SQLIntegrityConstraintViolationException e) {
                try { connection.rollback(); } catch (SQLException ex) { ex.printStackTrace(); }
                if (e.getMessage().contains("Duplicate entry") && e.getMessage().contains("roll_no")) {
                    parentFrame.showError("A student with this Roll Number already exists.");
                } else if (e.getMessage().contains("Duplicate entry") && e.getMessage().contains("username")) {
                    parentFrame.showError("A user with this Roll Number (username) already exists.");
                } else {
                    parentFrame.showError("Database error: " + e.getMessage());
                }
                e.printStackTrace();
            } catch (SQLException e) {
                try { connection.rollback(); } catch (SQLException ex) { ex.printStackTrace(); }
                parentFrame.showError("Error updating student: " + e.getMessage());
                e.printStackTrace();
            } finally {
                try { connection.setAutoCommit(true); } catch (SQLException ex) { ex.printStackTrace(); }
            }
        }

        private void deleteStudent() {
            int selectedRow = studentTable.getSelectedRow();
            if (selectedRow == -1) {
                parentFrame.showError("Please select a student to delete.");
                return;
            }

            int confirm = parentFrame.showConfirmDialogCustom(this, "Are you sure you want to delete this student? This will also delete their user account and all related data.", "Confirm Deletion", JOptionPane.YES_NO_OPTION);
            if (confirm != JOptionPane.YES_OPTION) {
                return;
            }

            int modelRow = studentTable.convertRowIndexToModel(selectedRow);
            int userId = (int) studentTableModel.getValueAt(modelRow, 1); // Get user_id

            try {
                // Deleting the user account will cascade delete the student record due to foreign key constraint
                String sql = "DELETE FROM users WHERE id = ?";
                try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                    pstmt.setInt(1, userId);
                    int affectedRows = pstmt.executeUpdate();
                    if (affectedRows > 0) {
                        parentFrame.showSuccess("Student and associated user account deleted successfully!");
                        loadStudents(); // Refresh table
                        clearStudentForm();
                    } else {
                        parentFrame.showError("Failed to delete student. User not found.");
                    }
                }
            } catch (SQLException e) {
                parentFrame.showError("Error deleting student: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private void clearStudentForm() {
            studentNameField.setText("");
            studentRollField.setText("");
            studentFatherNameField.setText("");
            studentEmailField.setText("");
            studentPhoneField.setText("");
            studentAddressArea.setText("");
            studentInterestsArea.setText("");
            studentBioArea.setText("");
            studentIsActiveCheckbox.setSelected(true);
            studentProfilePictureLabel.setIcon(null);
            studentProfilePictureLabel.setText("No Picture");
            currentStudentProfilePicturePath = null;
            studentTable.clearSelection();
        }

        private void uploadStudentProfilePicture() {
            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setDialogTitle("Select Profile Picture");
            fileChooser.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter("Image Files", "jpg", "jpeg", "png", "gif"));
            int userSelection = fileChooser.showOpenDialog(this);

            if (userSelection == JFileChooser.APPROVE_OPTION) {
                File sourceFile = fileChooser.getSelectedFile();
                try {
                    // Create a unique file name to avoid conflicts
                    String fileName = System.currentTimeMillis() + "_" + sourceFile.getName();
                    File destinationFile = new File("student_images", fileName);
                    Files.copy(sourceFile.toPath(), destinationFile.toPath(), StandardCopyOption.REPLACE_EXISTING);

                    currentStudentProfilePicturePath = destinationFile.getAbsolutePath();
                    BufferedImage img = ImageIO.read(destinationFile);
                    if (img != null) {
                        Image scaledImg = img.getScaledInstance(studentProfilePictureLabel.getWidth(), studentProfilePictureLabel.getHeight(), Image.SCALE_SMOOTH);
                        studentProfilePictureLabel.setIcon(new ImageIcon(scaledImg));
                    }
                    parentFrame.showInfo("Profile picture uploaded successfully. Remember to click 'Update Student' to save the path to the database.");
                } catch (IOException ex) {
                    parentFrame.showError("Error uploading image: " + ex.getMessage());
                    ex.printStackTrace();
                }
            }
        }

        private String getStudentProfilePicturePath(int studentId) {
            String path = null;
            String sql = "SELECT profile_picture_path FROM students WHERE id = ?";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                pstmt.setInt(1, studentId);
                ResultSet rs = pstmt.executeQuery();
                if (rs.next()) {
                    path = rs.getString("profile_picture_path");
                }
            } catch (SQLException e) {
                parentFrame.showError("Error retrieving profile picture path: " + e.getMessage());
                e.printStackTrace();
            }
            return path;
        }

        private void viewStudentProfilePicture() {
            if (currentStudentProfilePicturePath != null && !currentStudentProfilePicturePath.isEmpty()) {
                File imageFile = new File(currentStudentProfilePicturePath);
                if (imageFile.exists()) {
                    try {
                        // Open the image file using the default desktop application
                        Desktop.getDesktop().open(imageFile);
                    } catch (IOException e) {
                        parentFrame.showError("Could not open image file: " + e.getMessage());
                        e.printStackTrace();
                    }
                } else {
                    parentFrame.showError("Profile picture file not found at: " + currentStudentProfilePicturePath);
                }
            } else {
                parentFrame.showInfo("No profile picture selected or uploaded for this student.");
            }
        }

        private void toggleStudentAccountStatus() {
            int selectedRow = studentTable.getSelectedRow();
            if (selectedRow == -1) {
                parentFrame.showError("Please select a student to toggle their account status.");
                return;
            }

            int modelRow = studentTable.convertRowIndexToModel(selectedRow);
            int userId = (int) studentTableModel.getValueAt(modelRow, 1);
            boolean currentStatus = (boolean) studentTableModel.getValueAt(modelRow, 10);

            String newStatusText = currentStatus ? "deactivate" : "activate";
            int confirm = parentFrame.showConfirmDialogCustom(this, "Are you sure you want to " + newStatusText + " this student's account?", "Confirm Status Change", JOptionPane.YES_NO_OPTION);
            if (confirm != JOptionPane.YES_OPTION) {
                return;
            }

            try {
                String sql = "UPDATE users SET is_active = ? WHERE id = ?";
                try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                    pstmt.setBoolean(1, !currentStatus); // Toggle the status
                    pstmt.setInt(2, userId);
                    int affectedRows = pstmt.executeUpdate();
                    if (affectedRows > 0) {
                        parentFrame.showSuccess("Student account status updated successfully!");
                        loadStudents(); // Refresh table
                        clearStudentForm();
                    } else {
                        parentFrame.showError("Failed to update student account status.");
                    }
                }
            } catch (SQLException e) {
                parentFrame.showError("Error toggling student account status: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private void applyStudentSearchFilter(String searchText) {
            if (searchText.trim().length() == 0) {
                studentSorter.setRowFilter(null); // Clear the filter if search text is empty
            } else {
                // Create a regex filter (case-insensitive) that searches across all columns
                // You can specify specific columns if needed, e.g., RowFilter.regexFilter("(?i)" + searchText, 2, 3) for name and roll_no
                studentSorter.setRowFilter(RowFilter.regexFilter("(?i)" + searchText));
            }
        }


        private void setupCourseManagementTab() {
            JPanel coursePanel = new JPanel(new BorderLayout(10, 10));
            coursePanel.setBorder(new EmptyBorder(10, 10, 10, 10));
            coursePanel.setBackground(UIUtils.BACKGROUND_COLOR);

            // --- Form Panel ---
            JPanel formPanel = new JPanel(new GridBagLayout());
            formPanel.setBackground(UIUtils.PANEL_COLOR);
            formPanel.setBorder(UIUtils.createPanelBorder());
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.insets = new Insets(5, 5, 5, 5);
            gbc.fill = GridBagConstraints.HORIZONTAL;

            JLabel titleLabel = new JLabel("Manage Courses", SwingConstants.CENTER);
            titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
            titleLabel.setForeground(UIUtils.ACCENT_COLOR);
            gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 4;
            formPanel.add(titleLabel, gbc);

            gbc.gridwidth = 1;

            gbc.gridx = 0; gbc.gridy = 1; formPanel.add(new JLabel("Course Name:"), gbc);
            gbc.gridx = 1; courseNameField = new JTextField(15); formPanel.add(courseNameField, gbc);

            gbc.gridx = 2; gbc.gridy = 1; formPanel.add(new JLabel("Assigned Teacher:"), gbc);
            gbc.gridx = 3; teacherComboBox = new JComboBox<>(); formPanel.add(teacherComboBox, gbc);

            // Geofencing fields
            gbc.gridx = 0; gbc.gridy = 2; formPanel.add(new JLabel("Expected Latitude:"), gbc);
            gbc.gridx = 1; courseExpectedLatField = new JTextField(15); formPanel.add(courseExpectedLatField, gbc);
            gbc.gridx = 2; gbc.gridy = 2; formPanel.add(new JLabel("Expected Longitude:"), gbc);
            gbc.gridx = 3; courseExpectedLonField = new JTextField(15); formPanel.add(courseExpectedLonField, gbc);

            gbc.gridx = 0; gbc.gridy = 3; formPanel.add(new JLabel("Geofence Radius (m):"), gbc);
            gbc.gridx = 1; courseGeofenceRadiusField = new JTextField(15); formPanel.add(courseGeofenceRadiusField, gbc);

            JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
            addCourseButton = new JButton("Add Course");
            UIUtils.applyButtonStyle(addCourseButton);
            addCourseButton.addActionListener(e -> addCourse());
            buttonPanel.add(addCourseButton);

            updateCourseButton = new JButton("Update Course");
            UIUtils.applyButtonStyle(updateCourseButton);
            updateCourseButton.addActionListener(e -> updateCourse());
            buttonPanel.add(updateCourseButton);

            deleteCourseButton = new JButton("Delete Course");
            UIUtils.applyButtonStyle(deleteCourseButton);
            deleteCourseButton.setBackground(UIUtils.DANGER_COLOR);
            deleteCourseButton.addActionListener(e -> deleteCourse());
            buttonPanel.add(deleteCourseButton);

            gbc.gridx = 0; gbc.gridy = 4; gbc.gridwidth = 4;
            formPanel.add(buttonPanel, gbc);

            coursePanel.add(formPanel, BorderLayout.NORTH);

            // --- Table Panel ---
            String[] courseColumnNames = {"ID", "Name", "Teacher", "Teacher ID", "Expected Lat", "Expected Lon", "Geofence Radius"};
            courseTableModel = new DefaultTableModel(courseColumnNames, 0) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
            courseTable = new JTable(courseTableModel);
            UIUtils.styleTable(courseTable);

            courseTable.getSelectionModel().addListSelectionListener(e -> {
                if (!e.getValueIsAdjusting() && courseTable.getSelectedRow() != -1) {
                    displayCourseDetails(courseTable.convertRowIndexToModel(courseTable.getSelectedRow()));
                }
            });

            JScrollPane courseTableScrollPane = new JScrollPane(courseTable);
            courseTableScrollPane.setBorder(UIUtils.createPanelBorder());
            coursePanel.add(courseTableScrollPane, BorderLayout.CENTER);

            sidebar.addMenuItem("Course Management", coursePanel);
            loadTeachersIntoComboBox();
            loadCourses();
        }

        private void loadTeachersIntoComboBox() {
            teacherComboBox.removeAllItems();
            teacherComboBox.addItem("Select Teacher"); // Default item
            String sql = "SELECT id, full_name FROM users WHERE role = 'teacher' ORDER BY full_name ASC";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                ResultSet rs = pstmt.executeQuery();
                while (rs.next()) {
                    teacherComboBox.addItem(rs.getString("full_name") + " (ID: " + rs.getInt("id") + ")");
                }
            } catch (SQLException e) {
                parentFrame.showError("Error loading teachers: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private int getTeacherIdFromComboBox(String selectedItem) {
            if (selectedItem == null || selectedItem.equals("Select Teacher")) {
                return -1;
            }
            // Extract ID from "Name (ID: X)" format
            int startIndex = selectedItem.lastIndexOf("(ID: ") + 5;
            int endIndex = selectedItem.lastIndexOf(")");
            if (startIndex > 0 && endIndex > startIndex) {
                try {
                    return Integer.parseInt(selectedItem.substring(startIndex, endIndex));
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                    return -1;
                }
            }
            return -1;
        }

        private String getTeacherNameFromId(int teacherId) {
            String teacherName = "N/A";
            if (teacherId == -1) return teacherName;
            String sql = "SELECT full_name FROM users WHERE id = ?";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                pstmt.setInt(1, teacherId);
                ResultSet rs = pstmt.executeQuery();
                if (rs.next()) {
                    teacherName = rs.getString("full_name");
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
            return teacherName;
        }

        private void loadCourses() {
            courseTableModel.setRowCount(0);
            String sql = "SELECT c.id, c.name, c.teacher_user_id, u.full_name as teacher_name, c.expected_latitude, c.expected_longitude, c.geofence_radius_meters " +
                         "FROM courses c LEFT JOIN users u ON c.teacher_user_id = u.id ORDER BY c.name ASC";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                ResultSet rs = pstmt.executeQuery();
                while (rs.next()) {
                    Vector<Object> row = new Vector<>();
                    row.add(rs.getInt("id"));
                    row.add(rs.getString("name"));
                    String teacherName = rs.getString("teacher_name");
                    row.add(teacherName != null ? teacherName : "Unassigned");
                    row.add(rs.getInt("teacher_user_id")); // Hidden teacher ID
                    row.add(rs.getObject("expected_latitude"));
                    row.add(rs.getObject("expected_longitude"));
                    row.add(rs.getObject("geofence_radius_meters"));
                    courseTableModel.addRow(row);
                }
            } catch (SQLException e) {
                parentFrame.showError("Error loading courses: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private void displayCourseDetails(int modelRowIndex) {
            // Get data from the model, not the view, to handle sorting/filtering
            String name = (String) courseTableModel.getValueAt(modelRowIndex, 1);
            int teacherId = (int) courseTableModel.getValueAt(modelRowIndex, 3);
            Object latObj = courseTableModel.getValueAt(modelRowIndex, 4);
            Object lonObj = courseTableModel.getValueAt(modelRowIndex, 5);
            Object radiusObj = courseTableModel.getValueAt(modelRowIndex, 6);

            courseNameField.setText(name);
            teacherComboBox.setSelectedItem(getTeacherNameFromId(teacherId) + " (ID: " + teacherId + ")");
            courseExpectedLatField.setText(latObj != null ? latObj.toString() : "");
            courseExpectedLonField.setText(lonObj != null ? lonObj.toString() : "");
            courseGeofenceRadiusField.setText(radiusObj != null ? radiusObj.toString() : "");
        }

        private void addCourse() {
            String name = courseNameField.getText().trim();
            int teacherId = getTeacherIdFromComboBox((String) teacherComboBox.getSelectedItem());
            String latStr = courseExpectedLatField.getText().trim();
            String lonStr = courseExpectedLonField.getText().trim();
            String radiusStr = courseGeofenceRadiusField.getText().trim();

            if (name.isEmpty() || teacherId == -1) {
                parentFrame.showError("Course Name and Assigned Teacher are required.");
                return;
            }

            Double latitude = null;
            Double longitude = null;
            Integer radius = null;
            try {
                if (!latStr.isEmpty()) latitude = Double.parseDouble(latStr);
                if (!lonStr.isEmpty()) longitude = Double.parseDouble(lonStr);
                if (!radiusStr.isEmpty()) radius = Integer.parseInt(radiusStr);
            } catch (NumberFormatException e) {
                parentFrame.showError("Invalid number format for Latitude, Longitude, or Radius.");
                return;
            }

            String sql = "INSERT INTO courses (name, teacher_user_id, expected_latitude, expected_longitude, geofence_radius_meters) VALUES (?, ?, ?, ?, ?)";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                pstmt.setString(1, name);
                pstmt.setInt(2, teacherId);
                if (latitude != null) pstmt.setDouble(3, latitude); else pstmt.setNull(3, Types.DECIMAL);
                if (longitude != null) pstmt.setDouble(4, longitude); else pstmt.setNull(4, Types.DECIMAL);
                if (radius != null) pstmt.setInt(5, radius); else pstmt.setNull(5, Types.INTEGER);
                pstmt.executeUpdate();
                parentFrame.showSuccess("Course added successfully!");
                loadCourses();
                clearCourseForm();
            } catch (SQLIntegrityConstraintViolationException e) {
                parentFrame.showError("A course with this name already exists or teacher ID is invalid.");
                e.printStackTrace();
            } catch (SQLException e) {
                parentFrame.showError("Error adding course: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private void updateCourse() {
            int selectedRow = courseTable.getSelectedRow();
            if (selectedRow == -1) {
                parentFrame.showError("Please select a course to update.");
                return;
            }

            int modelRow = courseTable.convertRowIndexToModel(selectedRow);
            int courseId = (int) courseTableModel.getValueAt(modelRow, 0);

            String name = courseNameField.getText().trim();
            int teacherId = getTeacherIdFromComboBox((String) teacherComboBox.getSelectedItem());
            String latStr = courseExpectedLatField.getText().trim();
            String lonStr = courseExpectedLonField.getText().trim();
            String radiusStr = courseGeofenceRadiusField.getText().trim();

            if (name.isEmpty() || teacherId == -1) {
                parentFrame.showError("Course Name and Assigned Teacher are required.");
                return;
            }

            Double latitude = null;
            Double longitude = null;
            Integer radius = null;
            try {
                if (!latStr.isEmpty()) latitude = Double.parseDouble(latStr);
                if (!lonStr.isEmpty()) longitude = Double.parseDouble(lonStr);
                if (!radiusStr.isEmpty()) radius = Integer.parseInt(radiusStr);
            } catch (NumberFormatException e) {
                parentFrame.showError("Invalid number format for Latitude, Longitude, or Radius.");
                return;
            }

            String sql = "UPDATE courses SET name = ?, teacher_user_id = ?, expected_latitude = ?, expected_longitude = ?, geofence_radius_meters = ? WHERE id = ?";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                pstmt.setString(1, name);
                pstmt.setInt(2, teacherId);
                if (latitude != null) pstmt.setDouble(3, latitude); else pstmt.setNull(3, Types.DECIMAL);
                if (longitude != null) pstmt.setDouble(4, longitude); else pstmt.setNull(4, Types.DECIMAL);
                if (radius != null) pstmt.setInt(5, radius); else pstmt.setNull(5, Types.INTEGER);
                pstmt.setInt(6, courseId);
                int affectedRows = pstmt.executeUpdate();
                if (affectedRows > 0) {
                    parentFrame.showSuccess("Course updated successfully!");
                    loadCourses();
                    clearCourseForm();
                } else {
                    parentFrame.showError("Failed to update course. Course not found.");
                }
            } catch (SQLIntegrityConstraintViolationException e) {
                parentFrame.showError("A course with this name already exists or teacher ID is invalid.");
                e.printStackTrace();
            } catch (SQLException e) {
                parentFrame.showError("Error updating course: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private void deleteCourse() {
            int selectedRow = courseTable.getSelectedRow();
            if (selectedRow == -1) {
                parentFrame.showError("Please select a course to delete.");
                return;
            }

            int confirm = parentFrame.showConfirmDialogCustom(this, "Are you sure you want to delete this course? This will also delete associated assignments, grades, materials, and schedules.", "Confirm Deletion", JOptionPane.YES_NO_OPTION);
            if (confirm != JOptionPane.YES_OPTION) {
                return;
            }

            int modelRow = courseTable.convertRowIndexToModel(selectedRow);
            int courseId = (int) courseTableModel.getValueAt(modelRow, 0);

            try {
                String sql = "DELETE FROM courses WHERE id = ?";
                try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                    pstmt.setInt(1, courseId);
                    int affectedRows = pstmt.executeUpdate();
                    if (affectedRows > 0) {
                        parentFrame.showSuccess("Course deleted successfully!");
                        loadCourses();
                        clearCourseForm();
                    } else {
                        parentFrame.showError("Failed to delete course. Course not found.");
                    }
                }
            } catch (SQLException e) {
                parentFrame.showError("Error deleting course: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private void clearCourseForm() {
            courseNameField.setText("");
            teacherComboBox.setSelectedItem("Select Teacher");
            courseExpectedLatField.setText("");
            courseExpectedLonField.setText("");
            courseGeofenceRadiusField.setText("");
            courseTable.clearSelection();
        }


        private void setupTeacherManagementTab() {
            JPanel teacherPanel = new JPanel(new BorderLayout(10, 10));
            teacherPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
            teacherPanel.setBackground(UIUtils.BACKGROUND_COLOR);

            // --- Form Panel ---
            JPanel formPanel = new JPanel(new GridBagLayout());
            formPanel.setBackground(UIUtils.PANEL_COLOR);
            formPanel.setBorder(UIUtils.createPanelBorder());
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.insets = new Insets(5, 5, 5, 5);
            gbc.fill = GridBagConstraints.HORIZONTAL;

            JLabel titleLabel = new JLabel("Manage Teachers", SwingConstants.CENTER);
            titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
            titleLabel.setForeground(UIUtils.ACCENT_COLOR);
            gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
            formPanel.add(titleLabel, gbc);

            gbc.gridwidth = 1;

            gbc.gridx = 0; gbc.gridy = 1; formPanel.add(new JLabel("Username:"), gbc);
            gbc.gridx = 1; teacherUsernameField = new JTextField(20); formPanel.add(teacherUsernameField, gbc);

            gbc.gridx = 0; gbc.gridy = 2; formPanel.add(new JLabel("Full Name:"), gbc);
            gbc.gridx = 1; teacherFullNameField = new JTextField(20); formPanel.add(teacherFullNameField, gbc);

            gbc.gridx = 0; gbc.gridy = 3; formPanel.add(new JLabel("Password:"), gbc);
            gbc.gridx = 1; teacherPasswordField = new JPasswordField(20); formPanel.add(teacherPasswordField, gbc);

            gbc.gridx = 0; gbc.gridy = 4; formPanel.add(new JLabel("Account Active:"), gbc);
            gbc.gridx = 1; teacherIsActiveCheckbox = new JCheckBox(); teacherIsActiveCheckbox.setSelected(true); formPanel.add(teacherIsActiveCheckbox, gbc);

            JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
            addTeacherButton = new JButton("Add Teacher");
            UIUtils.applyButtonStyle(addTeacherButton);
            addTeacherButton.addActionListener(e -> addTeacher());
            buttonPanel.add(addTeacherButton);

            updateTeacherButton = new JButton("Update Teacher");
            UIUtils.applyButtonStyle(updateTeacherButton);
            updateTeacherButton.addActionListener(e -> updateTeacher());
            buttonPanel.add(updateTeacherButton);

            deleteTeacherButton = new JButton("Delete Teacher");
            UIUtils.applyButtonStyle(deleteTeacherButton);
            deleteTeacherButton.setBackground(UIUtils.DANGER_COLOR);
            deleteTeacherButton.addActionListener(e -> deleteTeacher());
            buttonPanel.add(deleteTeacherButton);

            toggleTeacherStatusButton = new JButton("Toggle Status");
            UIUtils.applyButtonStyle(toggleTeacherStatusButton);
            toggleTeacherStatusButton.setBackground(UIUtils.WARNING_COLOR);
            toggleTeacherStatusButton.addActionListener(e -> toggleTeacherAccountStatus());
            buttonPanel.add(toggleTeacherStatusButton);

            gbc.gridx = 0; gbc.gridy = 5; gbc.gridwidth = 2;
            formPanel.add(buttonPanel, gbc);

            teacherPanel.add(formPanel, BorderLayout.NORTH);

            // --- Table Panel ---
            String[] teacherColumnNames = {"ID", "Username", "Full Name", "Active"};
            teacherTableModel = new DefaultTableModel(teacherColumnNames, 0) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
            teacherTable = new JTable(teacherTableModel);
            UIUtils.styleTable(teacherTable);

            teacherTable.getSelectionModel().addListSelectionListener(e -> {
                if (!e.getValueIsAdjusting() && teacherTable.getSelectedRow() != -1) {
                    displayTeacherDetails(teacherTable.convertRowIndexToModel(teacherTable.getSelectedRow()));
                }
            });

            JScrollPane teacherTableScrollPane = new JScrollPane(teacherTable);
            teacherTableScrollPane.setBorder(UIUtils.createPanelBorder());
            teacherPanel.add(teacherTableScrollPane, BorderLayout.CENTER);

            sidebar.addMenuItem("Teacher Management", teacherPanel);
            loadTeachers();
        }

        private void loadTeachers() {
            teacherTableModel.setRowCount(0);
            String sql = "SELECT id, username, full_name, is_active FROM users WHERE role = 'teacher' ORDER BY full_name ASC";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                ResultSet rs = pstmt.executeQuery();
                while (rs.next()) {
                    Vector<Object> row = new Vector<>();
                    row.add(rs.getInt("id"));
                    row.add(rs.getString("username"));
                    row.add(rs.getString("full_name"));
                    row.add(rs.getBoolean("is_active"));
                    teacherTableModel.addRow(row);
                }
            } catch (SQLException e) {
                parentFrame.showError("Error loading teachers: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private void displayTeacherDetails(int modelRowIndex) {
            String username = (String) teacherTableModel.getValueAt(modelRowIndex, 1);
            String fullName = (String) teacherTableModel.getValueAt(modelRowIndex, 2);
            boolean isActive = (boolean) teacherTableModel.getValueAt(modelRowIndex, 3);

            teacherUsernameField.setText(username);
            teacherFullNameField.setText(fullName);
            teacherPasswordField.setText(""); // Clear password field for security
            teacherIsActiveCheckbox.setSelected(isActive);
        }

        private void addTeacher() {
            String username = teacherUsernameField.getText().trim();
            String fullName = teacherFullNameField.getText().trim();
            String password = new String(teacherPasswordField.getPassword());
            boolean isActive = teacherIsActiveCheckbox.isSelected();

            if (username.isEmpty() || fullName.isEmpty() || password.isEmpty()) {
                parentFrame.showError("Username, Full Name, and Password are required.");
                return;
            }

            String sql = "INSERT INTO users (username, password, role, full_name, is_active) VALUES (?, ?, ?, ?, ?)";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                pstmt.setString(1, username);
                pstmt.setString(2, handlePasswordStorage(password)); // Store plain text password
                pstmt.setString(3, "teacher");
                pstmt.setString(4, fullName);
                pstmt.setBoolean(5, isActive);
                pstmt.executeUpdate();
                parentFrame.showSuccess("Teacher added successfully!");
                loadTeachers();
                clearTeacherForm();
            } catch (SQLIntegrityConstraintViolationException e) {
                parentFrame.showError("A user with this username already exists.");
                e.printStackTrace();
            } catch (SQLException e) {
                parentFrame.showError("Error adding teacher: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private void updateTeacher() {
            int selectedRow = teacherTable.getSelectedRow();
            if (selectedRow == -1) {
                parentFrame.showError("Please select a teacher to update.");
                return;
            }

            int modelRow = teacherTable.convertRowIndexToModel(selectedRow);
            int teacherId = (int) teacherTableModel.getValueAt(modelRow, 0);

            String username = teacherUsernameField.getText().trim();
            String fullName = teacherFullNameField.getText().trim();
            String password = new String(teacherPasswordField.getPassword()); // Get new password if entered
            boolean isActive = teacherIsActiveCheckbox.isSelected();

            if (username.isEmpty() || fullName.isEmpty()) {
                parentFrame.showError("Username and Full Name are required.");
                return;
            }

            String sql;
            PreparedStatement pstmt;
            try {
                if (password.isEmpty()) {
                    // Update without changing password
                    sql = "UPDATE users SET username = ?, full_name = ?, is_active = ? WHERE id = ?";
                    pstmt = connection.prepareStatement(sql);
                    pstmt.setString(1, username);
                    pstmt.setString(2, fullName);
                    pstmt.setBoolean(3, isActive);
                    pstmt.setInt(4, teacherId);
                } else {
                    // Update with new password
                    sql = "UPDATE users SET username = ?, password = ?, full_name = ?, is_active = ? WHERE id = ?";
                    pstmt = connection.prepareStatement(sql);
                    pstmt.setString(1, username);
                    pstmt.setString(2, handlePasswordStorage(password)); // Store plain text password
                    pstmt.setString(3, fullName);
                    pstmt.setBoolean(4, isActive);
                    pstmt.setInt(5, teacherId);
                }

                int affectedRows = pstmt.executeUpdate();
                if (affectedRows > 0) {
                    parentFrame.showSuccess("Teacher updated successfully!");
                    loadTeachers();
                    loadCoursesIntoComboBox(); // Refresh course teacher dropdowns
                    clearTeacherForm();
                } else {
                    parentFrame.showError("Failed to update teacher. Teacher not found.");
                }
                pstmt.close();
            } catch (SQLIntegrityConstraintViolationException e) {
                parentFrame.showError("A user with this username already exists.");
                e.printStackTrace();
            } catch (SQLException e) {
                parentFrame.showError("Error updating teacher: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private void deleteTeacher() {
            int selectedRow = teacherTable.getSelectedRow();
            if (selectedRow == -1) {
                parentFrame.showError("Please select a teacher to delete.");
                return;
            }

            int confirm = parentFrame.showConfirmDialogCustom(this, "Are you sure you want to delete this teacher? This will also unassign them from courses.", "Confirm Deletion", JOptionPane.YES_NO_OPTION);
            if (confirm != JOptionPane.YES_OPTION) {
                return;
            }

            int modelRow = teacherTable.convertRowIndexToModel(selectedRow);
            int teacherId = (int) teacherTableModel.getValueAt(modelRow, 0);

            try {
                connection.setAutoCommit(false); // Start transaction

                // Unassign teacher from courses
                String unassignSql = "UPDATE courses SET teacher_user_id = NULL WHERE teacher_user_id = ?";
                try (PreparedStatement pstmt = connection.prepareStatement(unassignSql)) {
                    pstmt.setInt(1, teacherId);
                    pstmt.executeUpdate();
                }

                // Delete the teacher's user account
                String deleteSql = "DELETE FROM users WHERE id = ?";
                try (PreparedStatement pstmt = connection.prepareStatement(deleteSql)) {
                    pstmt.setInt(1, teacherId);
                    int affectedRows = pstmt.executeUpdate();
                    if (affectedRows > 0) {
                        connection.commit(); // Commit transaction
                        parentFrame.showSuccess("Teacher and associated user account deleted successfully!");
                        loadTeachers();
                        loadCoursesIntoComboBox(); // Refresh course teacher dropdowns
                        clearTeacherForm();
                    } else {
                        connection.rollback();
                        parentFrame.showError("Failed to delete teacher. User not found.");
                    }
                }
            } catch (SQLException e) {
                try { connection.rollback(); } catch (SQLException ex) { ex.printStackTrace(); }
                parentFrame.showError("Error deleting teacher: " + e.getMessage());
                e.printStackTrace();
            } finally {
                try { connection.setAutoCommit(true); } catch (SQLException ex) { ex.printStackTrace(); }
            }
        }

        private void clearTeacherForm() {
            teacherUsernameField.setText("");
            teacherFullNameField.setText("");
            teacherPasswordField.setText("");
            teacherIsActiveCheckbox.setSelected(true);
            teacherTable.clearSelection();
        }

        private void toggleTeacherAccountStatus() {
            int selectedRow = teacherTable.getSelectedRow();
            if (selectedRow == -1) {
                parentFrame.showError("Please select a teacher to toggle their account status.");
                return;
            }

            int modelRow = teacherTable.convertRowIndexToModel(selectedRow);
            int userId = (int) teacherTableModel.getValueAt(modelRow, 0);
            boolean currentStatus = (boolean) teacherTableModel.getValueAt(modelRow, 3);

            String newStatusText = currentStatus ? "deactivate" : "activate";
            int confirm = parentFrame.showConfirmDialogCustom(this, "Are you sure you want to " + newStatusText + " this teacher's account?", "Confirm Status Change", JOptionPane.YES_NO_OPTION);
            if (confirm != JOptionPane.YES_OPTION) {
                return;
            }

            try {
                String sql = "UPDATE users SET is_active = ? WHERE id = ?";
                try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                    pstmt.setBoolean(1, !currentStatus); // Toggle the status
                    pstmt.setInt(2, userId);
                    int affectedRows = pstmt.executeUpdate();
                    if (affectedRows > 0) {
                        parentFrame.showSuccess("Teacher account status updated successfully!");
                        loadTeachers(); // Refresh table
                        clearTeacherForm();
                    } else {
                        parentFrame.showError("Failed to update teacher account status.");
                    }
                }
            } catch (SQLException e) {
                parentFrame.showError("Error toggling teacher account status: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private void setupAttendanceReportingTab() {
            JPanel reportPanel = new JPanel(new BorderLayout(10, 10));
            reportPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
            reportPanel.setBackground(UIUtils.BACKGROUND_COLOR);

            // --- Controls Panel ---
            JPanel controlsPanel = new JPanel(new GridBagLayout());
            controlsPanel.setBackground(UIUtils.PANEL_COLOR);
            controlsPanel.setBorder(UIUtils.createPanelBorder());
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.insets = new Insets(5, 5, 5, 5);
            gbc.fill = GridBagConstraints.HORIZONTAL;

            JLabel titleLabel = new JLabel("Attendance Reporting", SwingConstants.CENTER);
            titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
            titleLabel.setForeground(UIUtils.ACCENT_COLOR);
            gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 4;
            controlsPanel.add(titleLabel, gbc);

            gbc.gridwidth = 1;

            // Row 1: Date Range
            gbc.gridx = 0; gbc.gridy = 1; controlsPanel.add(new JLabel("Start Date (YYYY-MM-DD):"), gbc);
            gbc.gridx = 1; startDateField = new JTextField(10); controlsPanel.add(startDateField, gbc);
            gbc.gridx = 2; controlsPanel.add(new JLabel("End Date (YYYY-MM-DD):"), gbc);
            gbc.gridx = 3; endDateField = new JTextField(10); controlsPanel.add(endDateField, gbc);

            // Row 2: Filters
            gbc.gridx = 0; gbc.gridy = 2; controlsPanel.add(new JLabel("Filter by Course:"), gbc);
            gbc.gridx = 1; reportCourseFilterComboBox = new JComboBox<>(); controlsPanel.add(reportCourseFilterComboBox, gbc);
            gbc.gridx = 2; controlsPanel.add(new JLabel("Filter by Teacher:"), gbc);
            gbc.gridx = 3; reportTeacherFilterComboBox = new JComboBox<>(); controlsPanel.add(reportTeacherFilterComboBox, gbc);

            // Row 3: Status Filter, Student Roll Filter
            gbc.gridx = 0; gbc.gridy = 3; controlsPanel.add(new JLabel("Filter by Status:"), gbc);
            gbc.gridx = 1; reportStatusFilterComboBox = new JComboBox<>(new String[]{"All", "Present", "Absent", "Leave"}); controlsPanel.add(reportStatusFilterComboBox, gbc);
            gbc.gridx = 2; controlsPanel.add(new JLabel("Filter by Student Roll:"), gbc);
            gbc.gridx = 3; reportStudentRollFilterField = new JTextField(10); controlsPanel.add(reportStudentRollFilterField, gbc);


            // Row 4: Buttons
            JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
            generateSummaryButton = new JButton("Generate Summary");
            UIUtils.applyButtonStyle(generateSummaryButton);
            generateSummaryButton.addActionListener(e -> generateAttendanceSummary());
            buttonPanel.add(generateSummaryButton);

            generateDetailedReportButton = new JButton("Generate Detailed Report");
            UIUtils.applyButtonStyle(generateDetailedReportButton);
            generateDetailedReportButton.addActionListener(e -> generateDetailedAttendanceReport());
            buttonPanel.add(generateDetailedReportButton);

            exportSummaryButton = new JButton("Export to CSV");
            UIUtils.applyButtonStyle(exportSummaryButton);
            exportSummaryButton.addActionListener(e -> exportAttendanceSummaryToCSV());
            buttonPanel.add(exportSummaryButton);

            searchAttendanceReportButton = new JButton("Search Report"); // New Search button
            UIUtils.applyButtonStyle(searchAttendanceReportButton);
            searchAttendanceReportButton.addActionListener(e -> applyAttendanceReportSearchFilter(reportStudentRollFilterField.getText()));
            reportStudentRollFilterField.addActionListener(e -> applyAttendanceReportSearchFilter(reportStudentRollFilterField.getText())); // Enable search on Enter
            buttonPanel.add(searchAttendanceReportButton);

            gbc.gridx = 0; gbc.gridy = 4; gbc.gridwidth = 4;
            controlsPanel.add(buttonPanel, gbc);

            reportPanel.add(controlsPanel, BorderLayout.NORTH);

            // --- Overall Summary Panel ---
            JPanel overallSummaryPanel = new JPanel(new GridLayout(1, 2, 10, 10));
            overallSummaryPanel.setBorder(UIUtils.createPanelBorder());
            overallSummaryPanel.setBackground(UIUtils.PANEL_COLOR);

            JPanel statsPanel = new JPanel(new GridLayout(5, 1, 5, 5));
            statsPanel.setBackground(UIUtils.PANEL_COLOR);
            overallTotalClassesLabel = new JLabel("Total Classes: 0");
            overallPresentCountLabel = new JLabel("Present: 0");
            overallAbsentCountLabel = new JLabel("Absent: 0");
            overallLeaveCountLabel = new JLabel("Leave: 0");
            overallAttendancePercentageLabel = new JLabel("Overall Attendance: 0.00%");
            statsPanel.add(overallTotalClassesLabel);
            statsPanel.add(overallPresentCountLabel);
            statsPanel.add(overallAbsentCountLabel);
            statsPanel.add(overallLeaveCountLabel);
            statsPanel.add(overallAttendancePercentageLabel);
            overallSummaryPanel.add(statsPanel);

            overallAttendanceChartPanel = new BarChartPanel();
            overallSummaryPanel.add(overallAttendanceChartPanel);

            reportPanel.add(overallSummaryPanel, BorderLayout.SOUTH);


            // --- Table Panel ---
            String[] attendanceSummaryColumnNames = {"Student Roll", "Student Name", "Course", "Date", "Status", "Marked At", "Latitude", "Longitude"};
            attendanceSummaryTableModel = new DefaultTableModel(attendanceSummaryColumnNames, 0) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
            attendanceSummaryTable = new JTable(attendanceSummaryTableModel);
            UIUtils.styleTable(attendanceSummaryTable);
            attendanceReportSorter = new TableRowSorter<>(attendanceSummaryTableModel);
            attendanceSummaryTable.setRowSorter(attendanceReportSorter); // Apply sorter

            JScrollPane attendanceTableScrollPane = new JScrollPane(attendanceSummaryTable);
            attendanceTableScrollPane.setBorder(UIUtils.createPanelBorder());
            reportPanel.add(attendanceTableScrollPane, BorderLayout.CENTER);

            sidebar.addMenuItem("Attendance Reporting", reportPanel);
            loadCoursesIntoComboBox();
            loadTeachersIntoComboBoxForReport(); // Load teachers for report filter
            // Set default date range to last 30 days
            endDateField.setText(LocalDate.now().toString());
            startDateField.setText(LocalDate.now().minusDays(30).toString());
            generateAttendanceSummary(); // Load initial summary
        }

        private void loadCoursesIntoComboBox() {
            reportCourseFilterComboBox.removeAllItems();
            reportCourseFilterComboBox.addItem("All Courses");
            // Populate with actual courses
            String sql = "SELECT id, name FROM courses ORDER BY name ASC";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                ResultSet rs = pstmt.executeQuery();
                while (rs.next()) {
                    reportCourseFilterComboBox.addItem(rs.getString("name") + " (ID: " + rs.getInt("id") + ")");
                }
            } catch (SQLException e) {
                parentFrame.showError("Error loading courses for filter: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private void loadTeachersIntoComboBoxForReport() {
            reportTeacherFilterComboBox.removeAllItems();
            reportTeacherFilterComboBox.addItem("All Teachers");
            String sql = "SELECT id, full_name FROM users WHERE role = 'teacher' ORDER BY full_name ASC";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                ResultSet rs = pstmt.executeQuery();
                while (rs.next()) {
                    reportTeacherFilterComboBox.addItem(rs.getString("full_name") + " (ID: " + rs.getInt("id") + ")");
                }
            } catch (SQLException e) {
                parentFrame.showError("Error loading teachers for report filter: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private int getCourseIdFromReportComboBox(String selectedItem) {
            if (selectedItem == null || selectedItem.equals("All Courses")) {
                return -1; // Indicates no specific course filter
            }
            int startIndex = selectedItem.lastIndexOf("(ID: ") + 5;
            int endIndex = selectedItem.lastIndexOf(")");
            if (startIndex > 0 && endIndex > startIndex) {
                try {
                    return Integer.parseInt(selectedItem.substring(startIndex, endIndex));
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                    return -1;
                }
            }
            return -1;
        }

        private int getTeacherIdFromReportComboBox(String selectedItem) {
            if (selectedItem == null || selectedItem.equals("All Teachers")) {
                return -1; // Indicates no specific teacher filter
            }
            int startIndex = selectedItem.lastIndexOf("(ID: ") + 5;
            int endIndex = selectedItem.lastIndexOf(")");
            if (startIndex > 0 && endIndex > startIndex) {
                try {
                    return Integer.parseInt(selectedItem.substring(startIndex, endIndex));
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                    return -1;
                }
            }
            return -1;
        }


        private void generateAttendanceSummary() {
            attendanceSummaryTableModel.setRowCount(0);
            LocalDate startDate;
            LocalDate endDate;
            try {
                startDate = LocalDate.parse(startDateField.getText());
                endDate = LocalDate.parse(endDateField.getText());
                if (startDate.isAfter(endDate)) {
                    parentFrame.showError("Start date cannot be after end date.");
                    return;
                }
            } catch (DateTimeParseException e) {
                parentFrame.showError("Invalid date format. Please use YYYY-MM-DD.");
                return;
            }

            int courseFilterId = getCourseIdFromReportComboBox((String) reportCourseFilterComboBox.getSelectedItem());
            int teacherFilterId = getTeacherIdFromReportComboBox((String) reportTeacherFilterComboBox.getSelectedItem());
            String statusFilter = (String) reportStatusFilterComboBox.getSelectedItem();

            StringBuilder sqlBuilder = new StringBuilder();
            // FIX: Ensure s.roll_no is selected if it's the correct column for student roll number
            sqlBuilder.append("SELECT s.roll_no, s.name as student_name, c.name as course_name, a.date, a.status, a.marked_at, a.latitude, a.longitude ");
            sqlBuilder.append("FROM attendance a ");
            sqlBuilder.append("JOIN students s ON a.student_id = s.id ");
            sqlBuilder.append("JOIN courses c ON a.course_id = c.id ");
            sqlBuilder.append("LEFT JOIN users u ON c.teacher_user_id = u.id "); // Join for teacher filter
            sqlBuilder.append("WHERE a.date BETWEEN ? AND ?");

            List<Object> params = new ArrayList<>();
            params.add(Date.valueOf(startDate));
            params.add(Date.valueOf(endDate));

            if (courseFilterId != -1) {
                sqlBuilder.append(" AND c.id = ?");
                params.add(courseFilterId);
            }
            if (teacherFilterId != -1) {
                sqlBuilder.append(" AND u.id = ?");
                params.add(teacherFilterId);
            }
            if (!statusFilter.equals("All")) {
                sqlBuilder.append(" AND a.status = ?");
                params.add(statusFilter);
            }

            sqlBuilder.append(" ORDER BY a.date DESC, s.name ASC");

            int totalPresent = 0;
            int totalAbsent = 0;
            int totalLeave = 0;
            int totalRecords = 0;

            try (PreparedStatement pstmt = connection.prepareStatement(sqlBuilder.toString())) {
                for (int i = 0; i < params.size(); i++) {
                    pstmt.setObject(i + 1, params.get(i));
                }

                ResultSet rs = pstmt.executeQuery();
                while (rs.next()) {
                    Vector<Object> row = new Vector<>();
                    row.add(rs.getString("roll_no"));
                    row.add(rs.getString("student_name"));
                    row.add(rs.getString("course_name"));
                    row.add(rs.getDate("date"));
                    String status = rs.getString("status");
                    row.add(status);
                    row.add(rs.getTimestamp("marked_at"));
                    row.add(rs.getObject("latitude"));
                    row.add(rs.getObject("longitude"));
                    attendanceSummaryTableModel.addRow(row);

                    // Update counts for overall summary
                    totalRecords++;
                    if ("Present".equals(status)) {
                        totalPresent++;
                    } else if ("Absent".equals(status)) {
                        totalAbsent++;
                    } else if ("Leave".equals(status)) {
                        totalLeave++;
                    }
                }

                // Update overall summary labels and chart
                overallTotalClassesLabel.setText("Total Records: " + totalRecords);
                overallPresentCountLabel.setText("Present: " + totalPresent);
                overallAbsentCountLabel.setText("Absent: " + totalAbsent);
                overallLeaveCountLabel.setText("Leave: " + totalLeave);

                double overallPercentage = (totalRecords > 0) ? ((double) totalPresent / totalRecords) * 100 : 0.0;
                overallAttendancePercentageLabel.setText("Overall Attendance: " + new DecimalFormat("0.00").format(overallPercentage) + "%");

                overallAttendanceChartPanel.updateChartData(totalPresent, totalAbsent, totalLeave);


            } catch (SQLException e) {
                parentFrame.showError("Error generating attendance summary: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private void generateDetailedAttendanceReport() {
            // This method can open a new window or dialog with a more detailed report,
            // or simply print to console/file. For simplicity, let's just show an info message.
            parentFrame.showInfo("Detailed report generation is a placeholder. You can implement a new view or export here.");
            // You would typically create a new JDialog or JFrame here and populate it with more granular data
            // (e.g., student-wise attendance for each day in a period).
        }

        private void exportAttendanceSummaryToCSV() {
            if (attendanceSummaryTableModel.getRowCount() == 0) {
                parentFrame.showInfo("No data to export.");
                return;
            }

            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setDialogTitle("Export Attendance Summary to CSV");
            fileChooser.setSelectedFile(new File("attendance_summary.csv"));
            int userSelection = fileChooser.showSaveDialog(this);

            if (userSelection == JFileChooser.APPROVE_OPTION) {
                File fileToSave = fileChooser.getSelectedFile();
                if (!fileToSave.getName().toLowerCase().endsWith(".csv")) {
                    fileToSave = new File(fileToSave.getAbsolutePath() + ".csv");
                }

                try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileToSave))) {
                    // Write header
                    for (int i = 0; i < attendanceSummaryTableModel.getColumnCount(); i++) {
                        writer.write(attendanceSummaryTableModel.getColumnName(i));
                        if (i < attendanceSummaryTableModel.getColumnCount() - 1) {
                            writer.write(",");
                        }
                    }
                    writer.newLine();

                    // Write data rows
                    for (int i = 0; i < attendanceSummaryTableModel.getRowCount(); i++) {
                        for (int j = 0; j < attendanceSummaryTableModel.getColumnCount(); j++) {
                            Object value = attendanceSummaryTableModel.getValueAt(i, j);
                            writer.write(value != null ? escapeCSV(value.toString()) : "");
                            if (j < attendanceSummaryTableModel.getColumnCount() - 1) {
                                writer.write(",");
                            }
                        }
                        writer.newLine();
                    }
                    parentFrame.showSuccess("Attendance summary exported to: " + fileToSave.getAbsolutePath());
                } catch (IOException e) {
                    parentFrame.showError("Error exporting CSV: " + e.getMessage());
                    e.printStackTrace();
                }
            }
        }

        // Helper to escape CSV values (handle commas and quotes within data)
        private String escapeCSV(String value) {
            if (value.contains(",") || value.contains("\"") || value.contains("\n")) {
                return "\"" + value.replace("\"", "\"\"") + "\"";
            }
            return value;
        }

        private void applyAttendanceReportSearchFilter(String searchText) {
            if (searchText.trim().length() == 0) {
                attendanceReportSorter.setRowFilter(null); // Clear the filter if search text is empty
            } else {
                // Create a regex filter (case-insensitive) that searches across all columns
                // For attendance, usually searching by student roll or name is most common
                // If you want to search only by student roll (column 0), use RowFilter.regexFilter("(?i)" + searchText, 0);
                attendanceReportSorter.setRowFilter(RowFilter.regexFilter("(?i)" + searchText));
            }
        }


        private void setupAnnouncementManagementTab() {
            JPanel announcementPanel = new JPanel(new BorderLayout(10, 10));
            announcementPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
            announcementPanel.setBackground(UIUtils.BACKGROUND_COLOR);

            // --- Form Panel ---
            JPanel formPanel = new JPanel(new GridBagLayout());
            formPanel.setBackground(UIUtils.PANEL_COLOR);
            formPanel.setBorder(UIUtils.createPanelBorder());
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.insets = new Insets(5, 5, 5, 5);
            gbc.fill = GridBagConstraints.HORIZONTAL;

            JLabel titleLabel = new JLabel("Manage Announcements", SwingConstants.CENTER);
            titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
            titleLabel.setForeground(UIUtils.ACCENT_COLOR);
            gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 4;
            formPanel.add(titleLabel, gbc);

            gbc.gridwidth = 1;

            gbc.gridx = 0; gbc.gridy = 1; formPanel.add(new JLabel("Subject:"), gbc);
            gbc.gridx = 1; announcementSubjectField = new JTextField(20); formPanel.add(announcementSubjectField, gbc);

            gbc.gridx = 0; gbc.gridy = 2; formPanel.add(new JLabel("Message:"), gbc);
            gbc.gridx = 1; gbc.gridwidth = 3;
            announcementMessageArea = new JTextArea(5, 30);
            announcementMessageArea.setLineWrap(true);
            announcementMessageArea.setWrapStyleWord(true);
            JScrollPane messageScrollPane = new JScrollPane(announcementMessageArea);
            formPanel.add(messageScrollPane, gbc);
            gbc.gridwidth = 1; // Reset gridwidth

            gbc.gridx = 0; gbc.gridy = 3; formPanel.add(new JLabel("Send To Role:"), gbc);
            gbc.gridx = 1;
            announcementRecipientRoleComboBox = new JComboBox<>(new String[]{"all", "student", "teacher", "admin", "specific_course", "specific_students"});
            formPanel.add(announcementRecipientRoleComboBox, gbc);

            gbc.gridx = 2; gbc.gridy = 3; formPanel.add(new JLabel("Target Course:"), gbc);
            gbc.gridx = 3; announcementTargetCourseComboBox = new JComboBox<>(); formPanel.add(announcementTargetCourseComboBox, gbc);

            gbc.gridx = 0; gbc.gridy = 4; formPanel.add(new JLabel("Target Student IDs (comma-separated):"), gbc);
            gbc.gridx = 1; gbc.gridwidth = 3; announcementTargetStudentsField = new JTextField(30); formPanel.add(announcementTargetStudentsField, gbc);
            gbc.gridwidth = 1; // Reset gridwidth

            // Logic to enable/disable target course/students based on recipient role
            announcementRecipientRoleComboBox.addItemListener(e -> {
                if (e.getStateChange() == ItemEvent.SELECTED) {
                    String selectedRole = (String) announcementRecipientRoleComboBox.getSelectedItem();
                    boolean enableCourse = "specific_course".equals(selectedRole);
                    boolean enableStudents = "specific_students".equals(selectedRole);

                    announcementTargetCourseComboBox.setEnabled(enableCourse);
                    announcementTargetStudentsField.setEnabled(enableStudents);
                }
            });
            // Initial state
            announcementTargetCourseComboBox.setEnabled(false);
            announcementTargetStudentsField.setEnabled(false);

            JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
            sendAnnouncementButton = new JButton("Send Announcement");
            UIUtils.applyButtonStyle(sendAnnouncementButton);
            sendAnnouncementButton.addActionListener(e -> sendAnnouncement());
            buttonPanel.add(sendAnnouncementButton);

            deleteAnnouncementButton = new JButton("Delete Selected");
            UIUtils.applyButtonStyle(deleteAnnouncementButton);
            deleteAnnouncementButton.setBackground(UIUtils.DANGER_COLOR);
            deleteAnnouncementButton.addActionListener(e -> deleteAnnouncement());
            buttonPanel.add(deleteAnnouncementButton);

            gbc.gridx = 0; gbc.gridy = 5; gbc.gridwidth = 4;
            formPanel.add(buttonPanel, gbc);

            announcementPanel.add(formPanel, BorderLayout.NORTH);

            // --- Table Panel ---
            // Fix for SQLSyntaxErrorException: Column 'send_to_role' not found.
            // Ensure the SQL query in loadSentAnnouncements selects 'send_to_role' and 'target_course_id'.
            // The table model must also include these columns.
            String[] announcementColumnNames = {"ID", "Subject", "Message", "Sender", "Recipient Role", "Target Course ID", "Sent At"};
            sentAnnouncementsTableModel = new DefaultTableModel(announcementColumnNames, 0) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
            sentAnnouncementsTable = new JTable(sentAnnouncementsTableModel);
            UIUtils.styleTable(sentAnnouncementsTable);

            sentAnnouncementsTable.getSelectionModel().addListSelectionListener(e -> {
                if (!e.getValueIsAdjusting() && sentAnnouncementsTable.getSelectedRow() != -1) {
                    // Optionally display selected announcement details in form for editing (though not implemented for announcements)
                }
            });

            JScrollPane announcementTableScrollPane = new JScrollPane(sentAnnouncementsTable);
            announcementTableScrollPane.setBorder(UIUtils.createPanelBorder());
            announcementPanel.add(announcementTableScrollPane, BorderLayout.CENTER);

            sidebar.addMenuItem("Announcement Management", announcementPanel);
            loadCoursesIntoAnnouncementComboBox();
            loadSentAnnouncements(); // Load announcements when the tab is set up
        }

        private void loadCoursesIntoAnnouncementComboBox() {
            announcementTargetCourseComboBox.removeAllItems();
            announcementTargetCourseComboBox.addItem("N/A"); // Default for non-course specific
            String sql = "SELECT id, name FROM courses ORDER BY name ASC";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                ResultSet rs = pstmt.executeQuery();
                while (rs.next()) {
                    announcementTargetCourseComboBox.addItem(rs.getString("name") + " (ID: " + rs.getInt("id") + ")");
                }
            } catch (SQLException e) {
                parentFrame.showError("Error loading courses for announcements: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private int getCourseIdFromAnnouncementComboBox(String selectedItem) {
            if (selectedItem == null || selectedItem.equals("N/A")) {
                return -1; // Indicates no specific course
            }
            int startIndex = selectedItem.lastIndexOf("(ID: ") + 5;
            int endIndex = selectedItem.lastIndexOf(")");
            if (startIndex > 0 && endIndex > startIndex) {
                try {
                    return Integer.parseInt(selectedItem.substring(startIndex, endIndex));
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                    return -1;
                }
            }
            return -1;
        }

        private void loadSentAnnouncements() {
            sentAnnouncementsTableModel.setRowCount(0);
            // CORRECTED SQL QUERY: Ensure 'send_to_role' and 'target_course_id' are selected
            String sql = "SELECT a.id, a.subject, a.message, u.full_name as sender_name, a.send_to_role, a.target_course_id, a.sent_at " +
                         "FROM announcements a JOIN users u ON a.sender_user_id = u.id ORDER BY a.sent_at DESC";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                ResultSet rs = pstmt.executeQuery();
                while (rs.next()) {
                    Vector<Object> row = new Vector<>();
                    row.add(rs.getInt("id"));
                    row.add(rs.getString("subject"));
                    row.add(rs.getString("message"));
                    row.add(rs.getString("sender_name"));
                    row.add(rs.getString("send_to_role")); // This was the missing column
                    row.add(rs.getObject("target_course_id")); // This was potentially missing
                    row.add(rs.getTimestamp("sent_at"));
                    sentAnnouncementsTableModel.addRow(row);
                }
            } catch (SQLException e) {
                parentFrame.showError("Error loading sent announcements: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private void sendAnnouncement() {
            String subject = announcementSubjectField.getText().trim();
            String message = announcementMessageArea.getText().trim();
            String recipientRole = (String) announcementRecipientRoleComboBox.getSelectedItem();
            int targetCourseId = getCourseIdFromAnnouncementComboBox((String) announcementTargetCourseComboBox.getSelectedItem());
            String targetStudentIdsStr = announcementTargetStudentsField.getText().trim();

            if (subject.isEmpty() || message.isEmpty()) {
                parentFrame.showError("Subject and Message cannot be empty.");
                return;
            }

            if ("specific_course".equals(recipientRole) && targetCourseId == -1) {
                parentFrame.showError("Please select a target course for 'specific_course' announcements.");
                return;
            }
            if ("specific_students".equals(recipientRole) && targetStudentIdsStr.isEmpty()) {
                parentFrame.showError("Please enter target student IDs for 'specific_students' announcements.");
                return;
            }

            try {
                connection.setAutoCommit(false); // Start transaction

                // 1. Insert the main announcement
                String insertAnnouncementSql = "INSERT INTO announcements (sender_user_id, subject, message, send_to_role, target_course_id) VALUES (?, ?, ?, ?, ?)";
                int announcementId;
                try (PreparedStatement pstmt = connection.prepareStatement(insertAnnouncementSql, Statement.RETURN_GENERATED_KEYS)) {
                    pstmt.setInt(1, loggedInUser.getId()); // Sender is the logged-in admin
                    pstmt.setString(2, subject);
                    pstmt.setString(3, message);
                    pstmt.setString(4, recipientRole);
                    if (targetCourseId != -1) {
                        pstmt.setInt(5, targetCourseId);
                    } else {
                        pstmt.setNull(5, Types.INTEGER);
                    }
                    pstmt.executeUpdate();
                    ResultSet generatedKeys = pstmt.getGeneratedKeys();
                    if (generatedKeys.next()) {
                        announcementId = generatedKeys.getInt(1);
                    } else {
                        throw new SQLException("Creating announcement failed, no ID obtained.");
                    }
                }

                // 2. Distribute to specific users if applicable
                List<Integer> recipientUserIds = new ArrayList<>();
                if ("all".equals(recipientRole)) {
                    // Get all user IDs
                    String userSql = "SELECT id FROM users";
                    try (PreparedStatement pstmt = connection.prepareStatement(userSql);
                         ResultSet rs = pstmt.executeQuery()) {
                        while (rs.next()) {
                            recipientUserIds.add(rs.getInt("id"));
                        }
                    }
                } else if ("student".equals(recipientRole) || "teacher".equals(recipientRole) || "admin".equals(recipientRole)) {
                    // Get users by role
                    String userSql = "SELECT id FROM users WHERE role = ?";
                    try (PreparedStatement pstmt = connection.prepareStatement(userSql)) {
                        pstmt.setString(1, recipientRole);
                        ResultSet rs = pstmt.executeQuery();
                        while (rs.next()) {
                            recipientUserIds.add(rs.getInt("id"));
                        }
                    }
                } else if ("specific_course".equals(recipientRole)) {
                    // Get students and teacher of a specific course
                    String userSql = "SELECT u.id FROM users u " +
                                     "JOIN students s ON u.id = s.user_id " +
                                     "JOIN student_courses sc ON s.id = sc.student_id " +
                                     "WHERE sc.course_id = ? " +
                                     "UNION SELECT u.id FROM users u JOIN courses c ON u.id = c.teacher_user_id WHERE c.id = ?";
                    try (PreparedStatement pstmt = connection.prepareStatement(userSql)) {
                        pstmt.setInt(1, targetCourseId);
                        pstmt.setInt(2, targetCourseId);
                        ResultSet rs = pstmt.executeQuery();
                        while (rs.next()) {
                            recipientUserIds.add(rs.getInt("id"));
                        }
                    }
                } else if ("specific_students".equals(recipientRole)) {
                    // Parse comma-separated student IDs, then get their user IDs
                    String[] studentRolls = targetStudentIdsStr.split(",");
                    for (String roll : studentRolls) {
                        roll = roll.trim();
                        if (!roll.isEmpty()) {
                            String userIdSql = "SELECT u.id FROM users u JOIN students s ON u.id = s.user_id WHERE s.roll_no = ?";
                            try (PreparedStatement pstmt = connection.prepareStatement(userIdSql)) {
                                pstmt.setString(1, roll);
                                ResultSet rs = pstmt.executeQuery();
                                if (rs.next()) {
                                    recipientUserIds.add(rs.getInt("id"));
                                } else {
                                    parentFrame.showError("Student with Roll No: " + roll + " not found. Skipping.");
                                }
                            }
                        }
                    }
                }

                // Insert into user_announcements
                if (!recipientUserIds.isEmpty()) {
                    String insertUserAnnouncementSql = "INSERT INTO user_announcements (announcement_id, recipient_user_id) VALUES (?, ?)";
                    try (PreparedStatement batchPstmt = connection.prepareStatement(insertUserAnnouncementSql)) {
                        for (Integer userId : recipientUserIds) {
                            batchPstmt.setInt(1, announcementId);
                            batchPstmt.setInt(2, userId);
                            batchPstmt.addBatch();
                        }
                        batchPstmt.executeBatch();
                    }
                }

                connection.commit(); // Commit transaction
                parentFrame.showSuccess("Announcement sent successfully!");
                loadSentAnnouncements(); // Refresh table
                clearAnnouncementForm();
            } catch (SQLException e) {
                try { connection.rollback(); } catch (SQLException ex) { ex.printStackTrace(); }
                parentFrame.showError("Error sending announcement: " + e.getMessage());
                e.printStackTrace();
            } finally {
                try { connection.setAutoCommit(true); } catch (SQLException ex) { ex.printStackTrace(); }
            }
        }

        private void deleteAnnouncement() {
            int selectedRow = sentAnnouncementsTable.getSelectedRow();
            if (selectedRow == -1) {
                parentFrame.showError("Please select an announcement to delete.");
                return;
            }

            int confirm = parentFrame.showConfirmDialogCustom(this, "Are you sure you want to delete this announcement?", "Confirm Deletion", JOptionPane.YES_NO_OPTION);
            if (confirm != JOptionPane.YES_OPTION) {
                return;
            }

            int modelRow = sentAnnouncementsTable.convertRowIndexToModel(selectedRow);
            int announcementId = (int) sentAnnouncementsTableModel.getValueAt(modelRow, 0);

            try {
                String sql = "DELETE FROM announcements WHERE id = ?";
                try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                    pstmt.setInt(1, announcementId);
                    int affectedRows = pstmt.executeUpdate();
                    if (affectedRows > 0) {
                        parentFrame.showSuccess("Announcement deleted successfully!");
                        loadSentAnnouncements();
                    } else {
                        parentFrame.showError("Failed to delete announcement. Announcement not found.");
                    }
                }
            } catch (SQLException e) {
                parentFrame.showError("Error deleting announcement: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private void clearAnnouncementForm() {
            announcementSubjectField.setText("");
            announcementMessageArea.setText("");
            announcementRecipientRoleComboBox.setSelectedItem("all");
            announcementTargetCourseComboBox.setSelectedItem("N/A");
            announcementTargetStudentsField.setText("");
            announcementTargetCourseComboBox.setEnabled(false);
            announcementTargetStudentsField.setEnabled(false);
            sentAnnouncementsTable.clearSelection();
        }

        private void setupEnrollmentRequestManagementTab() {
            JPanel enrollmentPanel = new JPanel(new BorderLayout(10, 10));
            enrollmentPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
            enrollmentPanel.setBackground(UIUtils.BACKGROUND_COLOR);

            JLabel titleLabel = new JLabel("Manage Enrollment Requests", SwingConstants.CENTER);
            titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
            titleLabel.setForeground(UIUtils.ACCENT_COLOR);
            enrollmentPanel.add(titleLabel, BorderLayout.NORTH);

            String[] columnNames = {"Request ID", "Student Name", "Course Name", "Request Date", "Status"};
            enrollmentRequestsTableModel = new DefaultTableModel(columnNames, 0) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
            enrollmentRequestsTable = new JTable(enrollmentRequestsTableModel);
            UIUtils.styleTable(enrollmentRequestsTable);

            JScrollPane scrollPane = new JScrollPane(enrollmentRequestsTable);
            scrollPane.setBorder(UIUtils.createPanelBorder());
            enrollmentPanel.add(scrollPane, BorderLayout.CENTER);

            JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
            approveEnrollmentButton = new JButton("Approve Request");
            UIUtils.applyButtonStyle(approveEnrollmentButton);
            approveEnrollmentButton.addActionListener(e -> updateEnrollmentRequestStatus("approved"));
            buttonPanel.add(approveEnrollmentButton);

            rejectEnrollmentButton = new JButton("Reject Request");
            UIUtils.applyButtonStyle(rejectEnrollmentButton);
            rejectEnrollmentButton.setBackground(UIUtils.DANGER_COLOR);
            rejectEnrollmentButton.addActionListener(e -> updateEnrollmentRequestStatus("rejected"));
            buttonPanel.add(rejectEnrollmentButton);

            enrollmentPanel.add(buttonPanel, BorderLayout.SOUTH);

            sidebar.addMenuItem("Enrollment Requests", enrollmentPanel);
            loadEnrollmentRequests();
        }

        private void loadEnrollmentRequests() {
            enrollmentRequestsTableModel.setRowCount(0);
            String sql = "SELECT er.id, s.name as student_name, c.name as course_name, er.request_date, er.status " +
                         "FROM course_enrollment_requests er " +
                         "JOIN students s ON er.student_id = s.id " +
                         "JOIN courses c ON er.course_id = c.id " +
                         "ORDER BY er.request_date DESC";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                ResultSet rs = pstmt.executeQuery();
                while (rs.next()) {
                    Vector<Object> row = new Vector<>();
                    row.add(rs.getInt("id"));
                    row.add(rs.getString("student_name"));
                    row.add(rs.getString("course_name"));
                    row.add(rs.getTimestamp("request_date"));
                    row.add(rs.getString("status"));
                    enrollmentRequestsTableModel.addRow(row);
                }
            } catch (SQLException e) {
                parentFrame.showError("Error loading enrollment requests: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private void updateEnrollmentRequestStatus(String status) {
            int selectedRow = enrollmentRequestsTable.getSelectedRow();
            if (selectedRow == -1) {
                parentFrame.showError("Please select an enrollment request.");
                return;
            }

            int modelRow = enrollmentRequestsTable.convertRowIndexToModel(selectedRow);
            int requestId = (int) enrollmentRequestsTableModel.getValueAt(modelRow, 0);
            String currentStatus = (String) enrollmentRequestsTableModel.getValueAt(modelRow, 4);

            if (!currentStatus.equals("pending")) {
                parentFrame.showInfo("This request has already been " + currentStatus + ".");
                return;
            }

            int confirm = parentFrame.showConfirmDialogCustom(this, "Are you sure you want to " + status + " this enrollment request?", "Confirm Action", JOptionPane.YES_NO_OPTION);
            if (confirm != JOptionPane.YES_OPTION) {
                return;
            }

            try {
                connection.setAutoCommit(false);

                // Update request status
                String updateRequestSql = "UPDATE course_enrollment_requests SET status = ?, approved_by_user_id = ?, approval_date = CURRENT_TIMESTAMP WHERE id = ?";
                try (PreparedStatement pstmt = connection.prepareStatement(updateRequestSql)) {
                    pstmt.setString(1, status);
                    pstmt.setInt(2, loggedInUser.getId());
                    pstmt.setInt(3, requestId);
                    pstmt.executeUpdate();
                }

                if (status.equals("approved")) {
                    // Get student_id and course_id from the request
                    String getIdsSql = "SELECT student_id, course_id FROM course_enrollment_requests WHERE id = ?";
                    int studentId = -1;
                    int courseId = -1;
                    try (PreparedStatement pstmt = connection.prepareStatement(getIdsSql)) {
                        pstmt.setInt(1, requestId);
                        ResultSet rs = pstmt.executeQuery();
                        if (rs.next()) {
                            studentId = rs.getInt("student_id");
                            courseId = rs.getInt("course_id");
                        }
                    }

                    if (studentId != -1 && courseId != -1) {
                        // Enroll student in the course (add to student_courses)
                        String enrollSql = "INSERT INTO student_courses (student_id, course_id) VALUES (?, ?)";
                        try (PreparedStatement pstmt = connection.prepareStatement(enrollSql)) {
                            pstmt.setInt(1, studentId);
                            pstmt.setInt(2, courseId);
                            pstmt.executeUpdate();
                        }
                    } else {
                        throw new SQLException("Could not retrieve student or course ID for enrollment.");
                    }
                }

                connection.commit();
                parentFrame.showSuccess("Enrollment request " + status + " successfully!");
                loadEnrollmentRequests();
            } catch (SQLIntegrityConstraintViolationException e) {
                try { connection.rollback(); } catch (SQLException ex) { ex.printStackTrace(); }
                parentFrame.showError("Student is already enrolled in this course.");
                e.printStackTrace();
            } catch (SQLException e) {
                try { connection.rollback(); } catch (SQLException ex) { ex.printStackTrace(); }
                parentFrame.showError("Error updating enrollment request: " + e.getMessage());
                e.printStackTrace();
            } finally {
                try { connection.setAutoCommit(true); } catch (SQLException ex) { ex.printStackTrace(); }
            }
        }

        private void setupLeaveRequestManagementTab() {
            JPanel leavePanel = new JPanel(new BorderLayout(10, 10));
            leavePanel.setBorder(new EmptyBorder(10, 10, 10, 10));
            leavePanel.setBackground(UIUtils.BACKGROUND_COLOR);

            JLabel titleLabel = new JLabel("Manage Leave Requests", SwingConstants.CENTER);
            titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
            titleLabel.setForeground(UIUtils.ACCENT_COLOR);
            leavePanel.add(titleLabel, BorderLayout.NORTH);

            String[] columnNames = {"Request ID", "Student Name", "Course", "Start Date", "End Date", "Reason", "Status", "Requested On"};
            leaveRequestsTableModel = new DefaultTableModel(columnNames, 0) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
            leaveRequestsTable = new JTable(leaveRequestsTableModel);
            UIUtils.styleTable(leaveRequestsTable);

            JScrollPane scrollPane = new JScrollPane(leaveRequestsTable);
            scrollPane.setBorder(UIUtils.createPanelBorder());
            leavePanel.add(scrollPane, BorderLayout.CENTER);

            JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
            approveLeaveButton = new JButton("Approve Leave");
            UIUtils.applyButtonStyle(approveLeaveButton);
            approveLeaveButton.addActionListener(e -> updateLeaveRequestStatus("approved"));
            buttonPanel.add(approveLeaveButton);

            rejectLeaveButton = new JButton("Reject Leave");
            UIUtils.applyButtonStyle(rejectLeaveButton);
            rejectLeaveButton.setBackground(UIUtils.DANGER_COLOR);
            rejectLeaveButton.addActionListener(e -> updateLeaveRequestStatus("rejected"));
            buttonPanel.add(rejectLeaveButton);

            leavePanel.add(buttonPanel, BorderLayout.SOUTH);

            sidebar.addMenuItem("Leave Requests", leavePanel);
            loadLeaveRequests();
        }

        private void loadLeaveRequests() {
            leaveRequestsTableModel.setRowCount(0);
            String sql = "SELECT lr.id, s.name as student_name, c.name as course_name, lr.start_date, lr.end_date, lr.reason, lr.status, lr.request_date " +
                         "FROM leave_requests lr " +
                         "JOIN students s ON lr.student_id = s.id " +
                         "LEFT JOIN courses c ON lr.course_id = c.id " + // LEFT JOIN as course_id can be NULL
                         "ORDER BY lr.request_date DESC";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                ResultSet rs = pstmt.executeQuery();
                while (rs.next()) {
                    Vector<Object> row = new Vector<>();
                    row.add(rs.getInt("id"));
                    row.add(rs.getString("student_name"));
                    row.add(rs.getString("course_name") != null ? rs.getString("course_name") : "General Leave");
                    row.add(rs.getDate("start_date"));
                    row.add(rs.getDate("end_date"));
                    row.add(rs.getString("reason"));
                    row.add(rs.getString("status"));
                    row.add(rs.getTimestamp("request_date"));
                    leaveRequestsTableModel.addRow(row);
                }
            } catch (SQLException e) {
                parentFrame.showError("Error loading leave requests: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private void updateLeaveRequestStatus(String status) {
            int selectedRow = leaveRequestsTable.getSelectedRow();
            if (selectedRow == -1) {
                parentFrame.showError("Please select a leave request.");
                return;
            }

            int modelRow = leaveRequestsTable.convertRowIndexToModel(selectedRow);
            int requestId = (int) leaveRequestsTableModel.getValueAt(modelRow, 0);
            String currentStatus = (String) leaveRequestsTableModel.getValueAt(modelRow, 6);

            if (!currentStatus.equals("pending")) {
                parentFrame.showInfo("This request has already been " + currentStatus + ".");
                return;
            }

            int confirm = parentFrame.showConfirmDialogCustom(this, "Are you sure you want to " + status + " this leave request?", "Confirm Action", JOptionPane.YES_NO_OPTION);
            if (confirm != JOptionPane.YES_OPTION) {
                return;
            }

            try {
                String sql = "UPDATE leave_requests SET status = ?, approved_by_user_id = ?, approval_date = CURRENT_TIMESTAMP WHERE id = ?";
                try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                    pstmt.setString(1, status);
                    pstmt.setInt(2, loggedInUser.getId());
                    pstmt.setInt(3, requestId);
                    int affectedRows = pstmt.executeUpdate();
                    if (affectedRows > 0) {
                        parentFrame.showSuccess("Leave request " + status + " successfully!");
                        loadLeaveRequests();
                    } else {
                        parentFrame.showError("Failed to update leave request. Request not found.");
                    }
                }
            } catch (SQLException e) {
                parentFrame.showError("Error updating leave request: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private void setupSystemSettingsTab() {
            JPanel settingsPanel = new JPanel(new GridBagLayout());
            settingsPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
            settingsPanel.setBackground(UIUtils.BACKGROUND_COLOR);

            GridBagConstraints gbc = new GridBagConstraints();
            gbc.insets = new Insets(10, 10, 10, 10);
            gbc.fill = GridBagConstraints.HORIZONTAL;

            JLabel titleLabel = new JLabel("System Settings", SwingConstants.CENTER);
            titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
            titleLabel.setForeground(UIUtils.ACCENT_COLOR);
            gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 3;
            settingsPanel.add(titleLabel, gbc);

            // Attendance Reminder Settings
            JPanel reminderPanel = new JPanel(new GridBagLayout());
            reminderPanel.setBackground(UIUtils.PANEL_COLOR);
            reminderPanel.setBorder(BorderFactory.createTitledBorder(UIUtils.createPanelBorder(), "Automated Attendance Reminders"));
            GridBagConstraints rGbc = new GridBagConstraints();
            rGbc.insets = new Insets(5, 5, 5, 5);
            rGbc.fill = GridBagConstraints.HORIZONTAL;

            rGbc.gridx = 0; rGbc.gridy = 0; reminderPanel.add(new JLabel("Enable Reminders:"), rGbc);
            rGbc.gridx = 1; enableRemindersCheckbox = new JCheckBox(); reminderPanel.add(enableRemindersCheckbox, rGbc);

            rGbc.gridx = 0; rGbc.gridy = 1; reminderPanel.add(new JLabel("Reminder Time (HH:MM):"), rGbc);
            rGbc.gridx = 1; reminderHourSpinner = new JSpinner(new SpinnerNumberModel(9, 0, 23, 1)); reminderPanel.add(reminderHourSpinner, rGbc);
            rGbc.gridx = 2; reminderMinuteSpinner = new JSpinner(new SpinnerNumberModel(0, 0, 59, 1)); reminderPanel.add(reminderMinuteSpinner, rGbc);

            rGbc.gridx = 0; rGbc.gridy = 2; rGbc.gridwidth = 3;
            saveReminderSettingsButton = new JButton("Save Reminder Settings");
            UIUtils.applyButtonStyle(saveReminderSettingsButton);
            saveReminderSettingsButton.addActionListener(e -> saveReminderSettings());
            reminderPanel.add(saveReminderSettingsButton, rGbc);

            gbc.gridx = 0; gbc.gridy = 1; gbc.gridwidth = 3;
            settingsPanel.add(reminderPanel, gbc);

            // Geofencing Settings
            JPanel geofencePanel = new JPanel(new GridBagLayout());
            geofencePanel.setBackground(UIUtils.PANEL_COLOR);
            geofencePanel.setBorder(BorderFactory.createTitledBorder(UIUtils.createPanelBorder(), "Default Geofencing Settings"));
            GridBagConstraints gGbc = new GridBagConstraints();
            gGbc.insets = new Insets(5, 5, 5, 5);
            gGbc.fill = GridBagConstraints.HORIZONTAL;

            gGbc.gridx = 0; gGbc.gridy = 0; geofencePanel.add(new JLabel("Default Geofence Radius (meters):"), gGbc);
            gGbc.gridx = 1; defaultGeofenceRadiusField = new JTextField(10); geofencePanel.add(defaultGeofenceRadiusField, gGbc);

            gGbc.gridx = 0; gGbc.gridy = 1; gGbc.gridwidth = 2;
            saveGeofenceSettingsButton = new JButton("Save Geofence Settings");
            UIUtils.applyButtonStyle(saveGeofenceSettingsButton);
            saveGeofenceSettingsButton.addActionListener(e -> saveGeofenceSettings());
            geofencePanel.add(saveGeofenceSettingsButton, gGbc);

            gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 3;
            settingsPanel.add(geofencePanel, gbc);


            sidebar.addMenuItem("System Settings", settingsPanel);
            loadSystemSettings();
        }

        private void loadSystemSettings() {
            enableRemindersCheckbox.setSelected(parentFrame.getSystemSettingBoolean("enable_attendance_reminders", true));
            reminderHourSpinner.setValue(parentFrame.getSystemSettingInt("attendance_reminder_time_hour", 9));
            reminderMinuteSpinner.setValue(parentFrame.getSystemSettingInt("attendance_reminder_time_minute", 0));
            defaultGeofenceRadiusField.setText(parentFrame.getSystemSetting("default_geofence_radius", "100"));
        }

        private void saveReminderSettings() {
            boolean enable = enableRemindersCheckbox.isSelected();
            int hour = (int) reminderHourSpinner.getValue();
            int minute = (int) reminderMinuteSpinner.getValue();

            parentFrame.updateSystemSetting("enable_attendance_reminders", String.valueOf(enable));
            parentFrame.updateSystemSetting("attendance_reminder_time_hour", String.valueOf(hour));
            parentFrame.updateSystemSetting("attendance_reminder_time_minute", String.valueOf(minute));

            parentFrame.showSuccess("Reminder settings saved. Restart application for full effect on scheduler.");
        }

        private void saveGeofenceSettings() {
            String radiusStr = defaultGeofenceRadiusField.getText().trim();
            try {
                int radius = Integer.parseInt(radiusStr);
                if (radius <= 0) {
                    parentFrame.showError("Geofence radius must be a positive integer.");
                    return;
                }
                parentFrame.updateSystemSetting("default_geofence_radius", radiusStr);
                parentFrame.showSuccess("Default geofence settings saved.");
            } catch (NumberFormatException e) {
                parentFrame.showError("Invalid number format for geofence radius.");
            }
        }

        private void setupUserAccountManagementTab() {
            JPanel userAccountPanel = new JPanel(new BorderLayout(10, 10));
            userAccountPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
            userAccountPanel.setBackground(UIUtils.BACKGROUND_COLOR);

            // --- Controls Panel ---
            JPanel controlsPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 5));
            controlsPanel.setBackground(UIUtils.PANEL_COLOR);
            controlsPanel.setBorder(UIUtils.createPanelBorder());

            JLabel titleLabel = new JLabel("Manage User Accounts", SwingConstants.CENTER);
            titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
            titleLabel.setForeground(UIUtils.ACCENT_COLOR);
            JPanel titleWrapper = new JPanel(new BorderLayout());
            titleWrapper.setBackground(UIUtils.PANEL_COLOR);
            titleWrapper.add(titleLabel, BorderLayout.CENTER);
            userAccountPanel.add(titleWrapper, BorderLayout.NORTH);


            controlsPanel.add(new JLabel("Search Username/Name:"));
            userAccountSearchField = new JTextField(20);
            controlsPanel.add(userAccountSearchField);
            searchUserAccountsButton = new JButton("Search Users");
            UIUtils.applyButtonStyle(searchUserAccountsButton);
            searchUserAccountsButton.addActionListener(e -> applyUserAccountSearchFilter(userAccountSearchField.getText()));
            userAccountSearchField.addActionListener(e -> applyUserAccountSearchFilter(userAccountSearchField.getText()));
            controlsPanel.add(searchUserAccountsButton);

            toggleUserAccountStatusButton = new JButton("Toggle Account Status");
            UIUtils.applyButtonStyle(toggleUserAccountStatusButton);
            toggleUserAccountStatusButton.setBackground(UIUtils.WARNING_COLOR);
            toggleUserAccountStatusButton.addActionListener(e -> toggleUserAccountStatus());
            controlsPanel.add(toggleUserAccountStatusButton);

            userAccountPanel.add(controlsPanel, BorderLayout.SOUTH);

            // --- Table Panel ---
            String[] userColumnNames = {"ID", "Username", "Full Name", "Role", "Active"};
            userAccountTableModel = new DefaultTableModel(userColumnNames, 0) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
            userAccountTable = new JTable(userAccountTableModel);
            UIUtils.styleTable(userAccountTable);
            userAccountSorter = new TableRowSorter<>(userAccountTableModel);
            userAccountTable.setRowSorter(userAccountSorter);

            JScrollPane userAccountTableScrollPane = new JScrollPane(userAccountTable);
            userAccountTableScrollPane.setBorder(UIUtils.createPanelBorder());
            userAccountPanel.add(userAccountTableScrollPane, BorderLayout.CENTER);

            sidebar.addMenuItem("User Accounts", userAccountPanel);
            loadUserAccounts();
        }

        private void loadUserAccounts() {
            userAccountTableModel.setRowCount(0);
            String sql = "SELECT id, username, full_name, role, is_active FROM users ORDER BY username ASC";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                ResultSet rs = pstmt.executeQuery();
                while (rs.next()) {
                    Vector<Object> row = new Vector<>();
                    row.add(rs.getInt("id"));
                    row.add(rs.getString("username"));
                    row.add(rs.getString("full_name"));
                    row.add(rs.getString("role"));
                    row.add(rs.getBoolean("is_active"));
                    userAccountTableModel.addRow(row);
                }
            } catch (SQLException e) {
                parentFrame.showError("Error loading user accounts: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private void toggleUserAccountStatus() {
            int selectedRow = userAccountTable.getSelectedRow();
            if (selectedRow == -1) {
                parentFrame.showError("Please select a user account to toggle its status.");
                return;
            }

            int modelRow = userAccountTable.convertRowIndexToModel(selectedRow);
            int userId = (int) userAccountTableModel.getValueAt(modelRow, 0);
            String username = (String) userAccountTableModel.getValueAt(modelRow, 1);
            boolean currentStatus = (boolean) userAccountTableModel.getValueAt(modelRow, 4);

            if (userId == loggedInUser.getId()) {
                parentFrame.showError("You cannot change the status of your own account.");
                return;
            }

            String newStatusText = currentStatus ? "deactivate" : "activate";
            int confirm = parentFrame.showConfirmDialogCustom(this, "Are you sure you want to " + newStatusText + " account for " + username + "?", "Confirm Status Change", JOptionPane.YES_NO_OPTION);
            if (confirm != JOptionPane.YES_OPTION) {
                return;
            }

            try {
                String sql = "UPDATE users SET is_active = ? WHERE id = ?";
                try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                    pstmt.setBoolean(1, !currentStatus); // Toggle the status
                    pstmt.setInt(2, userId);
                    int affectedRows = pstmt.executeUpdate();
                    if (affectedRows > 0) {
                        parentFrame.showSuccess("User account status updated successfully!");
                        loadUserAccounts(); // Refresh table
                    } else {
                        parentFrame.showError("Failed to update user account status.");
                    }
                }
            } catch (SQLException e) {
                parentFrame.showError("Error toggling user account status: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private void applyUserAccountSearchFilter(String searchText) {
            if (searchText.trim().length() == 0) {
                userAccountSorter.setRowFilter(null); // Clear the filter if search text is empty
            } else {
                // Create a regex filter (case-insensitive) that searches across Username (col 1) and Full Name (col 2)
                userAccountSorter.setRowFilter(RowFilter.regexFilter("(?i)" + searchText, 1, 2));
            }
        }
    }


    // Teacher Dashboard
    class TeacherDashboard extends JPanel {
        private OTPAttendanceSystem parentFrame;
        private CollapsibleSidebar sidebar;

        // Profile Tab
        private JLabel teacherProfilePictureLabel;
        private String currentTeacherProfilePicturePath;
        private JTextField teacherProfileNameField, teacherProfileEmailField, teacherProfilePhoneField;
        private JTextArea teacherProfileAddressArea, teacherProfileInterestsArea, teacherProfileBioArea;
        private JButton uploadTeacherPictureButton, viewTeacherPictureButton, saveTeacherProfileButton;

        // My Courses Tab
        private DefaultTableModel teacherCoursesTableModel;
        private JTable teacherCoursesTable;

        // Mark Attendance Tab
        private JComboBox<String> markAttendanceCourseComboBox;
        private JTextField otpInputField;
        private JLabel otpStatusLabel;
        private JButton markAttendanceButton;
        private JLabel geofenceStatusLabel;
        private JLabel lastMarkedTimeLabel;

        // Attendance Report Tab (Teacher specific)
        private DefaultTableModel teacherAttendanceSummaryTableModel;
        private JTable teacherAttendanceSummaryTable;
        private JTextField teacherReportStartDateField, teacherReportEndDateField;
        private JComboBox<String> teacherReportCourseFilterComboBox;
        private JComboBox<String> teacherReportStatusFilterComboBox;
        private JTextField teacherReportStudentRollFilterField;
        private JButton teacherGenerateSummaryButton, teacherExportSummaryButton, teacherSearchReportButton;
        private TableRowSorter<DefaultTableModel> teacherAttendanceReportSorter;

        // Manage Assignments Tab
        private DefaultTableModel assignmentsTableModel;
        private JTable assignmentsTable;
        private JComboBox<String> assignmentCourseComboBox;
        private JTextField assignmentTitleField;
        private JTextArea assignmentDescriptionArea;
        private JTextField assignmentDueDateField;
        private JButton addAssignmentButton, updateAssignmentButton, deleteAssignmentButton;

        // Manage Grades Tab
        private DefaultTableModel gradesTableModel;
        private JTable gradesTable;
        private JComboBox<String> gradeCourseComboBox, gradeAssignmentComboBox, gradeStudentComboBox;
        private JTextField gradeField;
        private JTextArea gradeFeedbackArea;
        private JButton addGradeButton, updateGradeButton;

        // Upload Course Materials Tab
        private DefaultTableModel courseMaterialsTableModel;
        private JTable courseMaterialsTable;
        private JComboBox<String> materialCourseComboBox;
        private JTextField materialTitleField;
        private JTextField materialFilePathField; // For displaying selected file path
        private JButton browseMaterialButton, uploadMaterialButton, deleteMaterialButton, viewMaterialButton;
        private File selectedMaterialFile; // To hold the file selected by browse

        // Class Schedule Tab
        private DefaultTableModel classScheduleTableModel;
        private JTable classScheduleTable;
        private JComboBox<String> scheduleCourseComboBox;
        private JComboBox<DayOfWeek> scheduleDayOfWeekComboBox;
        private JSpinner scheduleStartTimeSpinner, scheduleEndTimeSpinner;
        private JButton addScheduleButton, updateScheduleButton, deleteScheduleButton;

        // View Announcements Tab
        private DefaultTableModel teacherAnnouncementsTableModel;
        private JTable teacherAnnouncementsTable;
        private JTextArea teacherAnnouncementMessageArea; // For viewing full message
        private JButton markAnnouncementReadButton;

        // Leave Requests Tab (for Teacher Approval)
        private DefaultTableModel teacherLeaveRequestsTableModel;
        private JTable teacherLeaveRequestsTable;
        private JButton teacherApproveLeaveButton, teacherRejectLeaveButton;


        public TeacherDashboard(OTPAttendanceSystem parent) {
            this.parentFrame = parent;
            setLayout(new BorderLayout());
            setBackground(UIUtils.BACKGROUND_COLOR);

            String welcomeMsg = "Welcome, " + loggedInUser.getFullName() + " (Teacher)";
            sidebar = new CollapsibleSidebar(welcomeMsg, () -> parentFrame.showLoginPanel());
            add(sidebar, BorderLayout.CENTER);

            setupTeacherProfileTab();
            setupTeacherMyCoursesTab();
            setupTeacherMarkAttendanceTab();
            setupTeacherAttendanceReportTab();
            setupTeacherManageAssignmentsTab();
            setupTeacherManageGradesTab();
            setupTeacherUploadCourseMaterialsTab();
            setupTeacherClassScheduleTab();
            setupTeacherViewAnnouncementsTab();
            setupTeacherLeaveRequestsTab();

            sidebar.selectMenuItem("My Courses");
        }

        private void setupTeacherProfileTab() {
            JPanel profilePanel = new JPanel(new BorderLayout(10, 10));
            profilePanel.setBorder(new EmptyBorder(10, 10, 10, 10));
            profilePanel.setBackground(UIUtils.BACKGROUND_COLOR);

            // --- Form Panel ---
            JPanel formPanel = new JPanel(new GridBagLayout());
            formPanel.setBackground(UIUtils.PANEL_COLOR);
            formPanel.setBorder(UIUtils.createPanelBorder());
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.insets = new Insets(5, 5, 5, 5);
            gbc.fill = GridBagConstraints.HORIZONTAL;

            JLabel titleLabel = new JLabel("My Profile", SwingConstants.CENTER);
            titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
            titleLabel.setForeground(UIUtils.ACCENT_COLOR);
            gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 4;
            formPanel.add(titleLabel, gbc);

            gbc.gridwidth = 1;

            // Row 1: Name, Email
            gbc.gridx = 0; gbc.gridy = 1; formPanel.add(new JLabel("Full Name:"), gbc);
            gbc.gridx = 1; teacherProfileNameField = new JTextField(15); formPanel.add(teacherProfileNameField, gbc);
            gbc.gridx = 2; formPanel.add(new JLabel("Email:"), gbc);
            gbc.gridx = 3; teacherProfileEmailField = new JTextField(15); formPanel.add(teacherProfileEmailField, gbc);

            // Row 2: Phone, Address
            gbc.gridx = 0; gbc.gridy = 2; formPanel.add(new JLabel("Phone:"), gbc);
            gbc.gridx = 1; teacherProfilePhoneField = new JTextField(15); formPanel.add(teacherProfilePhoneField, gbc);
            gbc.gridx = 2; formPanel.add(new JLabel("Address:"), gbc);
            gbc.gridx = 3; teacherProfileAddressArea = new JTextArea(3, 15); teacherProfileAddressArea.setLineWrap(true); teacherProfileAddressArea.setWrapStyleWord(true);
            JScrollPane addressScrollPane = new JScrollPane(teacherProfileAddressArea);
            formPanel.add(addressScrollPane, gbc);

            // Row 3: Interests, Bio
            gbc.gridx = 0; gbc.gridy = 3; formPanel.add(new JLabel("Interests:"), gbc);
            gbc.gridx = 1; teacherProfileInterestsArea = new JTextArea(3, 15); teacherProfileInterestsArea.setLineWrap(true); teacherProfileInterestsArea.setWrapStyleWord(true);
            JScrollPane interestsScrollPane = new JScrollPane(teacherProfileInterestsArea);
            formPanel.add(interestsScrollPane, gbc);
            gbc.gridx = 2; formPanel.add(new JLabel("Bio:"), gbc);
            gbc.gridx = 3; teacherProfileBioArea = new JTextArea(3, 15); teacherProfileBioArea.setLineWrap(true); teacherProfileBioArea.setWrapStyleWord(true);
            JScrollPane bioScrollPane = new JScrollPane(teacherProfileBioArea);
            formPanel.add(bioScrollPane, gbc);

            // Row 4: Profile Picture
            gbc.gridx = 0; gbc.gridy = 4; formPanel.add(new JLabel("Profile Picture:"), gbc);
            gbc.gridx = 1;
            JPanel picPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
            uploadTeacherPictureButton = new JButton("Upload");
            UIUtils.applyButtonStyle(uploadTeacherPictureButton);
            uploadTeacherPictureButton.addActionListener(e -> uploadTeacherProfilePicture());
            picPanel.add(uploadTeacherPictureButton);
            viewTeacherPictureButton = new JButton("View");
            UIUtils.applyButtonStyle(viewTeacherPictureButton);
            viewTeacherPictureButton.addActionListener(e -> viewTeacherProfilePicture());
            picPanel.add(viewTeacherPictureButton);
            formPanel.add(picPanel, gbc);

            // Profile Picture Display Label
            gbc.gridx = 0; gbc.gridy = 5; gbc.gridwidth = 4;
            teacherProfilePictureLabel = new JLabel();
            teacherProfilePictureLabel.setHorizontalAlignment(SwingConstants.CENTER);
            teacherProfilePictureLabel.setPreferredSize(new Dimension(100, 100)); // Placeholder size
            teacherProfilePictureLabel.setBorder(BorderFactory.createLineBorder(UIUtils.BORDER_COLOR));
            formPanel.add(teacherProfilePictureLabel, gbc);
            gbc.gridwidth = 1; // Reset gridwidth

            // Row 5: Save Button
            JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
            saveTeacherProfileButton = new JButton("Save Profile");
            UIUtils.applyButtonStyle(saveTeacherProfileButton);
            saveTeacherProfileButton.addActionListener(e -> saveTeacherProfile());
            buttonPanel.add(saveTeacherProfileButton);

            gbc.gridx = 0; gbc.gridy = 6; gbc.gridwidth = 4;
            formPanel.add(buttonPanel, gbc);

            profilePanel.add(formPanel, BorderLayout.NORTH);

            sidebar.addMenuItem("My Profile", profilePanel);
            loadTeacherProfile();
        }

        private void loadTeacherProfile() {
            String sql = "SELECT u.full_name, u.username FROM users u WHERE u.id = ?";
            // NOTE: For teachers, profile data like phone, address, interests, bio, profile_picture_path
            // are currently stored in the 'students' table. This is a potential schema inconsistency
            // if teachers are not also considered 'students'. For a robust system, teachers should
            // have their own profile table or these fields should be in the 'users' table.
            // For now, I'll assume these fields are meant for the 'users' table or a dedicated 'teachers_profile' table.
            // Since the SQL schema updates only added these to `students`, I'll fetch from `users` for `full_name` and `username`
            // and leave the other fields as placeholders or skip them for teachers if they are not in `users` table.

            // Re-evaluating: The user's initial code snippet for `OTPAttendanceSystem.java` indicates that
            // `profile_picture_path`, `phone_number`, `address`, `interests`, `bio` were added to the `students` table.
            // If teachers are to have these, they should be added to the `users` table or a separate `teachers` table.
            // For simplicity and to avoid breaking existing logic, I will only load `full_name` and `username` for teachers' profiles.
            // If the user wants these fields for teachers, the database schema needs to be updated for the `users` table.

            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                pstmt.setInt(1, loggedInUser.getId());
                ResultSet rs = pstmt.executeQuery();
                if (rs.next()) {
                    teacherProfileNameField.setText(rs.getString("full_name"));
                    teacherProfileEmailField.setText(rs.getString("username") + "@example.com"); // Placeholder for email if not in users
                    teacherProfilePhoneField.setText(""); // Placeholder
                    teacherProfileAddressArea.setText(""); // Placeholder
                    teacherProfileInterestsArea.setText(""); // Placeholder
                    teacherProfileBioArea.setText(""); // Placeholder
                    teacherProfilePictureLabel.setIcon(null);
                    teacherProfilePictureLabel.setText("N/A for Teachers");
                    currentTeacherProfilePicturePath = null;
                }
            } catch (SQLException e) {
                parentFrame.showError("Error loading teacher profile: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private void saveTeacherProfile() {
            String fullName = teacherProfileNameField.getText().trim();
            // Email, phone, address, interests, bio, profile picture path are not directly editable for teachers
            // with the current schema, as they are in the 'students' table.
            // If these fields are desired for teachers, they need to be added to the 'users' table.

            if (fullName.isEmpty()) {
                parentFrame.showError("Full Name cannot be empty.");
                return;
            }

            String sql = "UPDATE users SET full_name = ? WHERE id = ?";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                pstmt.setString(1, fullName);
                pstmt.setInt(2, loggedInUser.getId());
                int affectedRows = pstmt.executeUpdate();
                if (affectedRows > 0) {
                    loggedInUser = new User(loggedInUser.getId(), loggedInUser.getUsername(), loggedInUser.getRole(), fullName, loggedInUser.isActive()); // Update loggedInUser
                    parentFrame.showSuccess("Profile updated successfully!");
                    // Refresh sidebar welcome message
                    sidebar.revalidate();
                    sidebar.repaint();
                } else {
                    parentFrame.showError("Failed to update profile.");
                }
            } catch (SQLException e) {
                parentFrame.showError("Error saving profile: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private void uploadTeacherProfilePicture() {
            parentFrame.showInfo("Profile picture upload is currently only supported for students based on the database schema. If you wish to add this for teachers, please update the 'users' table with a 'profile_picture_path' column.");
            // This method would be similar to AdminDashboard's uploadStudentProfilePicture
            // if 'profile_picture_path' was added to the 'users' table.
        }

        private void viewTeacherProfilePicture() {
            parentFrame.showInfo("No profile picture to view for teachers with current schema.");
        }


        private void setupTeacherMyCoursesTab() {
            JPanel myCoursesPanel = new JPanel(new BorderLayout(10, 10));
            myCoursesPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
            myCoursesPanel.setBackground(UIUtils.BACKGROUND_COLOR);

            JLabel titleLabel = new JLabel("My Courses", SwingConstants.CENTER);
            titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
            titleLabel.setForeground(UIUtils.ACCENT_COLOR);
            myCoursesPanel.add(titleLabel, BorderLayout.NORTH);

            String[] columnNames = {"Course ID", "Course Name", "Expected Latitude", "Expected Longitude", "Geofence Radius"};
            teacherCoursesTableModel = new DefaultTableModel(columnNames, 0) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
            teacherCoursesTable = new JTable(teacherCoursesTableModel);
            UIUtils.styleTable(teacherCoursesTable);

            JScrollPane scrollPane = new JScrollPane(teacherCoursesTable);
            scrollPane.setBorder(UIUtils.createPanelBorder());
            myCoursesPanel.add(scrollPane, BorderLayout.CENTER);

            sidebar.addMenuItem("My Courses", myCoursesPanel);
            loadTeacherCourses();
        }

        private void loadTeacherCourses() {
            teacherCoursesTableModel.setRowCount(0);
            // FIX: Ensure 'teacher_user_id' is used correctly in the WHERE clause
            String sql = "SELECT id, name, expected_latitude, expected_longitude, geofence_radius_meters FROM courses WHERE teacher_user_id = ? ORDER BY name ASC";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                pstmt.setInt(1, loggedInUser.getId());
                ResultSet rs = pstmt.executeQuery();
                while (rs.next()) {
                    Vector<Object> row = new Vector<>();
                    row.add(rs.getInt("id"));
                    row.add(rs.getString("name"));
                    row.add(rs.getObject("expected_latitude"));
                    row.add(rs.getObject("expected_longitude"));
                    row.add(rs.getObject("geofence_radius_meters"));
                    teacherCoursesTableModel.addRow(row);
                }
            } catch (SQLException e) {
                parentFrame.showError("Error loading your courses: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private void setupTeacherMarkAttendanceTab() {
            JPanel markAttendancePanel = new JPanel(new GridBagLayout());
            markAttendancePanel.setBorder(new EmptyBorder(10, 10, 10, 10));
            markAttendancePanel.setBackground(UIUtils.BACKGROUND_COLOR);

            GridBagConstraints gbc = new GridBagConstraints();
            gbc.insets = new Insets(10, 10, 10, 10);
            gbc.fill = GridBagConstraints.HORIZONTAL;

            JLabel titleLabel = new JLabel("Mark Student Attendance", SwingConstants.CENTER);
            titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
            titleLabel.setForeground(UIUtils.ACCENT_COLOR);
            gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
            markAttendancePanel.add(titleLabel, gbc);

            gbc.gridwidth = 1;

            gbc.gridx = 0; gbc.gridy = 1; markAttendancePanel.add(new JLabel("Select Course:"), gbc);
            gbc.gridx = 1; markAttendanceCourseComboBox = new JComboBox<>(); markAttendancePanel.add(markAttendanceCourseComboBox, gbc);

            gbc.gridx = 0; gbc.gridy = 2; markAttendancePanel.add(new JLabel("Enter OTP:"), gbc);
            gbc.gridx = 1; otpInputField = new JTextField(10); markAttendancePanel.add(otpInputField, gbc);

            gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 2;
            otpStatusLabel = new JLabel("OTP Status: Not Generated", SwingConstants.CENTER);
            otpStatusLabel.setFont(new Font("Arial", Font.ITALIC, 12));
            markAttendancePanel.add(otpStatusLabel, gbc);

            gbc.gridx = 0; gbc.gridy = 4; gbc.gridwidth = 2;
            geofenceStatusLabel = new JLabel("Geofence Status: Unknown", SwingConstants.CENTER);
            geofenceStatusLabel.setFont(new Font("Arial", Font.ITALIC, 12));
            markAttendancePanel.add(geofenceStatusLabel, gbc);

            gbc.gridx = 0; gbc.gridy = 5; gbc.gridwidth = 2;
            lastMarkedTimeLabel = new JLabel("Last Marked Attendance: N/A", SwingConstants.CENTER);
            lastMarkedTimeLabel.setFont(new Font("Arial", Font.ITALIC, 12));
            markAttendancePanel.add(lastMarkedTimeLabel, gbc);

            gbc.gridx = 0; gbc.gridy = 6; gbc.gridwidth = 2;
            markAttendanceButton = new JButton("Mark Attendance");
            UIUtils.applyButtonStyle(markAttendanceButton);
            markAttendanceButton.addActionListener(e -> markAttendance());
            markAttendancePanel.add(markAttendanceButton, gbc);

            sidebar.addMenuItem("Mark Attendance", markAttendancePanel);
            loadTeacherCoursesForAttendance();
            // Initial check for geofence and last marked time
            markAttendanceCourseComboBox.addItemListener(e -> {
                if (e.getStateChange() == ItemEvent.SELECTED) {
                    updateGeofenceStatus();
                    updateLastMarkedTime();
                }
            });
            updateGeofenceStatus(); // Initial call
            updateLastMarkedTime(); // Initial call
        }

        private void loadTeacherCoursesForAttendance() {
            markAttendanceCourseComboBox.removeAllItems();
            markAttendanceCourseComboBox.addItem("Select Course");
            // FIX: Ensure 'teacher_user_id' is used correctly in the WHERE clause
            String sql = "SELECT id, name FROM courses WHERE teacher_user_id = ? ORDER BY name ASC";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                pstmt.setInt(1, loggedInUser.getId());
                ResultSet rs = pstmt.executeQuery();
                while (rs.next()) {
                    markAttendanceCourseComboBox.addItem(rs.getString("name") + " (ID: " + rs.getInt("id") + ")");
                }
            } catch (SQLException e) {
                parentFrame.showError("Error loading courses for attendance: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private int getCourseIdFromAttendanceComboBox(String selectedItem) {
            if (selectedItem == null || selectedItem.equals("Select Course")) {
                return -1;
            }
            int startIndex = selectedItem.lastIndexOf("(ID: ") + 5;
            int endIndex = selectedItem.lastIndexOf(")");
            if (startIndex > 0 && endIndex > startIndex) {
                try {
                    return Integer.parseInt(selectedItem.substring(startIndex, endIndex));
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                    return -1;
                }
            }
            return -1;
        }

        private void updateGeofenceStatus() {
            int courseId = getCourseIdFromAttendanceComboBox((String) markAttendanceCourseComboBox.getSelectedItem());
            if (courseId == -1) {
                geofenceStatusLabel.setText("Geofence Status: Select a course");
                return;
            }

            // In a real application, this would use a location API to get current lat/lon
            // For this desktop app, we'll simulate or use fixed values for testing.
            // For now, let's just check if the course has geofence data.
            String sql = "SELECT expected_latitude, expected_longitude, geofence_radius_meters FROM courses WHERE id = ?";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                pstmt.setInt(1, courseId);
                ResultSet rs = pstmt.executeQuery();
                if (rs.next()) {
                    Double expectedLat = (Double) rs.getObject("expected_latitude");
                    Double expectedLon = (Double) rs.getObject("expected_longitude");
                    Integer radius = (Integer) rs.getObject("geofence_radius_meters");

                    if (expectedLat != null && expectedLon != null && radius != null) {
                        // Simulate current location (for testing, replace with actual GPS data)
                        double currentLat = 30.3753; // Example: Lahore
                        double currentLon = 69.3451; // Example: Lahore

                        // Calculate distance (Haversine formula for spherical Earth)
                        double distance = calculateHaversineDistance(expectedLat, expectedLon, currentLat, currentLon);

                        if (distance <= radius) {
                            geofenceStatusLabel.setText("Geofence Status: Inside (Distance: " + String.format("%.2f", distance) + "m)");
                            geofenceStatusLabel.setForeground(UIUtils.SUCCESS_COLOR);
                        } else {
                            geofenceStatusLabel.setText("Geofence Status: Outside (Distance: " + String.format("%.2f", distance) + "m, Radius: " + radius + "m)");
                            geofenceStatusLabel.setForeground(UIUtils.DANGER_COLOR);
                        }
                    } else {
                        geofenceStatusLabel.setText("Geofence Status: Not configured for this course.");
                        geofenceStatusLabel.setForeground(UIUtils.WARNING_COLOR);
                    }
                } else {
                    geofenceStatusLabel.setText("Geofence Status: Course not found.");
                    geofenceStatusLabel.setForeground(UIUtils.DANGER_COLOR);
                }
            } catch (SQLException e) {
                parentFrame.showError("Error checking geofence: " + e.getMessage());
                e.printStackTrace();
                geofenceStatusLabel.setText("Geofence Status: Error");
                geofenceStatusLabel.setForeground(UIUtils.DANGER_COLOR);
            }
        }

        /**
         * Calculates the distance between two points on Earth using the Haversine formula.
         * @param lat1 Latitude of point 1
         * @param lon1 Longitude of point 1
         * @param lat2 Latitude of point 2
         * @param lon2 Longitude of point 2
         * @return Distance in meters
         */
        private double calculateHaversineDistance(double lat1, double lon1, double lat2, double lon2) {
            final int R = 6371000; // Earth radius in meters
            double latDistance = Math.toRadians(lat2 - lat1);
            double lonDistance = Math.toRadians(lon2 - lon1);
            double a = Math.sin(latDistance / 2) * Math.sin(latDistance / 2)
                    + Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2))
                    * Math.sin(lonDistance / 2) * Math.sin(lonDistance / 2);
            double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
            return R * c; // Distance in meters
        }


        private void updateLastMarkedTime() {
            int courseId = getCourseIdFromAttendanceComboBox((String) markAttendanceCourseComboBox.getSelectedItem());
            if (courseId == -1) {
                lastMarkedTimeLabel.setText("Last Marked Attendance: N/A");
                return;
            }

            // In a real scenario for "Mark Student Attendance", this would show the last time
            // attendance was marked for the *selected student* in *this course*.
            // For simplicity, showing last marked time for *any* student in this course.
            String sql = "SELECT MAX(marked_at) as last_marked FROM attendance WHERE course_id = ?";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                pstmt.setInt(1, courseId);
                ResultSet rs = pstmt.executeQuery();
                if (rs.next() && rs.getTimestamp("last_marked") != null) {
                    lastMarkedTimeLabel.setText("Last Attendance Marked: " + rs.getTimestamp("last_marked").toString());
                } else {
                    lastMarkedTimeLabel.setText("Last Attendance Marked: Never");
                }
            } catch (SQLException e) {
                parentFrame.showError("Error getting last marked time: " + e.getMessage());
                e.printStackTrace();
            }
        }


        private void markAttendance() {
            String enteredOTP = otpInputField.getText().trim();
            int courseId = getCourseIdFromAttendanceComboBox((String) markAttendanceCourseComboBox.getSelectedItem());

            if (courseId == -1) {
                parentFrame.showError("Please select a course.");
                return;
            }
            if (enteredOTP.isEmpty()) {
                parentFrame.showError("Please enter the OTP.");
                return;
            }

            // Placeholder for student selection
            int studentIdToMark = -1; // This needs to come from UI (e.g., a JComboBox of students in this course)
            String studentRollToMark = JOptionPane.showInputDialog(this, "Enter student Roll Number to mark attendance:");
            if (studentRollToMark == null || studentRollToMark.isEmpty()) {
                parentFrame.showInfo("Attendance marking cancelled.");
                return;
            }

            // Get student ID from roll number
            studentIdToMark = getStudentIdByRollNo(studentRollToMark);
            if (studentIdToMark == -1) {
                parentFrame.showError("Student with Roll Number " + studentRollToMark + " not found.");
                return;
            }

            // Verify OTP (from adminDashboardInstance, which holds the current OTP)
            if (parentFrame.currentOTP == null || System.currentTimeMillis() > parentFrame.otpExpiryTime || !enteredOTP.equals(parentFrame.currentOTP)) {
                parentFrame.showError("Invalid or expired OTP. Please get a new OTP from the Admin.");
                return;
            }

            // Geofence check (simulated current location for the teacher, ideally student's location)
            // For a teacher marking attendance, the geofence check should ideally be done on the student's side.
            // If the teacher is marking, it's assumed the student is present (or on leave/absent).
            // For now, I'll use the teacher's (simulated) location.
            int defaultGeofenceRadius = parentFrame.getSystemSettingInt("default_geofence_radius", 100);
            Double expectedLat = null;
            Double expectedLon = null;
            Integer radius = null;
            String courseName = "";

            String courseGeofenceSql = "SELECT name, expected_latitude, expected_longitude, geofence_radius_meters FROM courses WHERE id = ?";
            try (PreparedStatement pstmt = connection.prepareStatement(courseGeofenceSql)) {
                pstmt.setInt(1, courseId);
                ResultSet rs = pstmt.executeQuery();
                if (rs.next()) {
                    courseName = rs.getString("name");
                    expectedLat = (Double) rs.getObject("expected_latitude");
                    expectedLon = (Double) rs.getObject("expected_longitude");
                    radius = (Integer) rs.getObject("geofence_radius_meters");
                }
            } catch (SQLException e) {
                parentFrame.showError("Error fetching course geofence data: " + e.getMessage());
                e.printStackTrace();
                return;
            }

            boolean withinGeofence = false;
            if (expectedLat != null && expectedLon != null && radius != null) {
                // Simulate current location (for testing, replace with actual GPS data for the student)
                double currentLat = 30.3753; // Example: Lahore
                double currentLon = 69.3451; // Example: Lahore
                double distance = calculateHaversineDistance(expectedLat, expectedLon, currentLat, currentLon);
                if (distance <= radius) {
                    withinGeofence = true;
                }
            } else {
                // If geofence not configured, assume it's not a requirement for this course
                withinGeofence = true;
                geofenceStatusLabel.setText("Geofence Status: Not configured for this course. Attendance allowed.");
                geofenceStatusLabel.setForeground(UIUtils.WARNING_COLOR);
            }

            if (!withinGeofence) {
                parentFrame.showError("You are outside the designated geofence for this course. Cannot mark attendance.");
                return;
            }

            // Mark attendance as Present
            String sql = "INSERT INTO attendance (student_id, course_id, date, status, marked_at, latitude, longitude) VALUES (?, ?, CURDATE(), ?, CURRENT_TIMESTAMP, ?, ?)";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                pstmt.setInt(1, studentIdToMark);
                pstmt.setInt(2, courseId);
                pstmt.setString(3, "Present");
                pstmt.setDouble(4, 30.3753); // Simulated Latitude
                pstmt.setDouble(5, 69.3451); // Simulated Longitude
                pstmt.executeUpdate();

                // Update last_marked_attendance_time in student_courses
                String updateLastMarkedSql = "UPDATE student_courses SET last_marked_attendance_time = CURRENT_TIMESTAMP WHERE student_id = ? AND course_id = ?";
                try (PreparedStatement updatePstmt = connection.prepareStatement(updateLastMarkedSql)) {
                    updatePstmt.setInt(1, studentIdToMark);
                    updatePstmt.setInt(2, courseId);
                    updatePstmt.executeUpdate();
                }

                parentFrame.showSuccess("Attendance marked as Present for " + studentRollToMark + " in " + courseName + "!");
                otpInputField.setText(""); // Clear OTP field
                updateLastMarkedTime(); // Refresh last marked time
            } catch (SQLIntegrityConstraintViolationException e) {
                parentFrame.showError("Attendance for " + studentRollToMark + " in " + courseName + " has already been marked today.");
                e.printStackTrace();
            } catch (SQLException e) {
                parentFrame.showError("Error marking attendance: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private int getStudentIdByRollNo(String rollNo) {
            int studentId = -1;
            String sql = "SELECT id FROM students WHERE roll_no = ?";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                pstmt.setString(1, rollNo);
                ResultSet rs = pstmt.executeQuery();
                if (rs.next()) {
                    studentId = rs.getInt("id");
                }
            } catch (SQLException e) {
                parentFrame.showError("Error finding student by roll number: " + e.getMessage());
                e.printStackTrace();
            }
            return studentId;
        }


        private void setupTeacherAttendanceReportTab() {
            JPanel reportPanel = new JPanel(new BorderLayout(10, 10));
            reportPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
            reportPanel.setBackground(UIUtils.BACKGROUND_COLOR);

            // --- Controls Panel ---
            JPanel controlsPanel = new JPanel(new GridBagLayout());
            controlsPanel.setBackground(UIUtils.PANEL_COLOR);
            controlsPanel.setBorder(UIUtils.createPanelBorder());
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.insets = new Insets(5, 5, 5, 5);
            gbc.fill = GridBagConstraints.HORIZONTAL;

            JLabel titleLabel = new JLabel("Attendance Reporting (My Courses)", SwingConstants.CENTER);
            titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
            titleLabel.setForeground(UIUtils.ACCENT_COLOR);
            gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 4;
            controlsPanel.add(titleLabel, gbc);

            gbc.gridwidth = 1;

            // Row 1: Date Range
            gbc.gridx = 0; gbc.gridy = 1; controlsPanel.add(new JLabel("Start Date (YYYY-MM-DD):"), gbc);
            gbc.gridx = 1; teacherReportStartDateField = new JTextField(10); controlsPanel.add(teacherReportStartDateField, gbc);
            gbc.gridx = 2; controlsPanel.add(new JLabel("End Date (YYYY-MM-DD):"), gbc);
            gbc.gridx = 3; teacherReportEndDateField = new JTextField(10); controlsPanel.add(teacherReportEndDateField, gbc);

            // Row 2: Filters
            gbc.gridx = 0; gbc.gridy = 2; controlsPanel.add(new JLabel("Filter by Course:"), gbc);
            gbc.gridx = 1; teacherReportCourseFilterComboBox = new JComboBox<>(); controlsPanel.add(teacherReportCourseFilterComboBox, gbc);
            gbc.gridx = 2; controlsPanel.add(new JLabel("Filter by Status:"), gbc);
            gbc.gridx = 3; teacherReportStatusFilterComboBox = new JComboBox<>(new String[]{"All", "Present", "Absent", "Leave"}); controlsPanel.add(teacherReportStatusFilterComboBox, gbc);

            // Row 3: Student Roll Filter
            gbc.gridx = 0; gbc.gridy = 3; controlsPanel.add(new JLabel("Filter by Student Roll:"), gbc);
            gbc.gridx = 1; teacherReportStudentRollFilterField = new JTextField(10); controlsPanel.add(teacherReportStudentRollFilterField, gbc);

            // Row 4: Buttons
            JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
            teacherGenerateSummaryButton = new JButton("Generate Report");
            UIUtils.applyButtonStyle(teacherGenerateSummaryButton);
            teacherGenerateSummaryButton.addActionListener(e -> generateTeacherAttendanceSummary());
            buttonPanel.add(teacherGenerateSummaryButton);

            teacherExportSummaryButton = new JButton("Export to CSV");
            UIUtils.applyButtonStyle(teacherExportSummaryButton);
            teacherExportSummaryButton.addActionListener(e -> exportTeacherAttendanceSummaryToCSV());
            buttonPanel.add(teacherExportSummaryButton);

            teacherSearchReportButton = new JButton("Search Report");
            UIUtils.applyButtonStyle(teacherSearchReportButton);
            teacherSearchReportButton.addActionListener(e -> applyTeacherAttendanceReportSearchFilter(teacherReportStudentRollFilterField.getText()));
            teacherReportStudentRollFilterField.addActionListener(e -> applyTeacherAttendanceReportSearchFilter(teacherReportStudentRollFilterField.getText()));
            buttonPanel.add(teacherSearchReportButton);

            gbc.gridx = 0; gbc.gridy = 4; gbc.gridwidth = 4;
            controlsPanel.add(buttonPanel, gbc);

            reportPanel.add(controlsPanel, BorderLayout.NORTH);

            // --- Table Panel ---
            String[] attendanceSummaryColumnNames = {"Student Roll", "Student Name", "Course", "Date", "Status", "Marked At"};
            teacherAttendanceSummaryTableModel = new DefaultTableModel(attendanceSummaryColumnNames, 0) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
            teacherAttendanceSummaryTable = new JTable(teacherAttendanceSummaryTableModel);
            UIUtils.styleTable(teacherAttendanceSummaryTable);
            teacherAttendanceReportSorter = new TableRowSorter<>(teacherAttendanceSummaryTableModel);
            teacherAttendanceSummaryTable.setRowSorter(teacherAttendanceReportSorter);

            JScrollPane attendanceTableScrollPane = new JScrollPane(teacherAttendanceSummaryTable);
            attendanceTableScrollPane.setBorder(UIUtils.createPanelBorder());
            reportPanel.add(attendanceTableScrollPane, BorderLayout.CENTER);

            sidebar.addMenuItem("Attendance Report", reportPanel);
            loadTeacherCoursesIntoReportComboBox();
            // Set default date range to last 30 days
            teacherReportEndDateField.setText(LocalDate.now().toString());
            teacherReportStartDateField.setText(LocalDate.now().minusDays(30).toString());
            generateTeacherAttendanceSummary(); // Load initial summary
        }

        private void loadTeacherCoursesIntoReportComboBox() {
            teacherReportCourseFilterComboBox.removeAllItems();
            teacherReportCourseFilterComboBox.addItem("All My Courses");
            // FIX: Ensure 'teacher_user_id' is used correctly in the WHERE clause
            String sql = "SELECT id, name FROM courses WHERE teacher_user_id = ? ORDER BY name ASC";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                pstmt.setInt(1, loggedInUser.getId());
                ResultSet rs = pstmt.executeQuery();
                while (rs.next()) {
                    teacherReportCourseFilterComboBox.addItem(rs.getString("name") + " (ID: " + rs.getInt("id") + ")");
                }
            } catch (SQLException e) {
                parentFrame.showError("Error loading courses for teacher report filter: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private int getCourseIdFromTeacherReportComboBox(String selectedItem) {
            if (selectedItem == null || selectedItem.equals("All My Courses")) {
                return -1;
            }
            int startIndex = selectedItem.lastIndexOf("(ID: ") + 5;
            int endIndex = selectedItem.lastIndexOf(")");
            if (startIndex > 0 && endIndex > startIndex) {
                try {
                    return Integer.parseInt(selectedItem.substring(startIndex, endIndex));
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                    return -1;
                }
            }
            return -1;
        }

        private void generateTeacherAttendanceSummary() {
            teacherAttendanceSummaryTableModel.setRowCount(0);
            LocalDate startDate;
            LocalDate endDate;
            try {
                startDate = LocalDate.parse(teacherReportStartDateField.getText());
                endDate = LocalDate.parse(teacherReportEndDateField.getText());
                if (startDate.isAfter(endDate)) {
                    parentFrame.showError("Start date cannot be after end date.");
                    return;
                }
            } catch (DateTimeParseException e) {
                parentFrame.showError("Invalid date format. Please use YYYY-MM-DD.");
                return;
            }

            int courseFilterId = getCourseIdFromTeacherReportComboBox((String) teacherReportCourseFilterComboBox.getSelectedItem());
            String statusFilter = (String) teacherReportStatusFilterComboBox.getSelectedItem();

            StringBuilder sqlBuilder = new StringBuilder();
            // FIX: Ensure s.roll_no is selected if it's the correct column for student roll number
            sqlBuilder.append("SELECT s.roll_no, s.name as student_name, c.name as course_name, a.date, a.status, a.marked_at ");
            sqlBuilder.append("FROM attendance a ");
            sqlBuilder.append("JOIN students s ON a.student_id = s.id ");
            sqlBuilder.append("JOIN courses c ON a.course_id = c.id ");
            // FIX: Filter by logged-in teacher's courses using c.teacher_user_id
            sqlBuilder.append("WHERE c.teacher_user_id = ? AND a.date BETWEEN ? AND ?");

            List<Object> params = new ArrayList<>();
            params.add(loggedInUser.getId());
            params.add(Date.valueOf(startDate));
            params.add(Date.valueOf(endDate));

            if (courseFilterId != -1) {
                sqlBuilder.append(" AND c.id = ?");
                params.add(courseFilterId);
            }
            if (!statusFilter.equals("All")) {
                sqlBuilder.append(" AND a.status = ?");
                params.add(statusFilter);
            }

            sqlBuilder.append(" ORDER BY a.date DESC, s.name ASC");

            try (PreparedStatement pstmt = connection.prepareStatement(sqlBuilder.toString())) {
                for (int i = 0; i < params.size(); i++) {
                    pstmt.setObject(i + 1, params.get(i));
                }

                ResultSet rs = pstmt.executeQuery();
                while (rs.next()) {
                    Vector<Object> row = new Vector<>();
                    row.add(rs.getString("roll_no"));
                    row.add(rs.getString("student_name"));
                    row.add(rs.getString("course_name"));
                    row.add(rs.getDate("date"));
                    row.add(rs.getString("status"));
                    row.add(rs.getTimestamp("marked_at"));
                    teacherAttendanceSummaryTableModel.addRow(row);
                }
            } catch (SQLException e) {
                parentFrame.showError("Error generating teacher attendance summary: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private void exportTeacherAttendanceSummaryToCSV() {
            if (teacherAttendanceSummaryTableModel.getRowCount() == 0) {
                parentFrame.showInfo("No data to export.");
                return;
            }

            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setDialogTitle("Export Teacher Attendance Summary to CSV");
            fileChooser.setSelectedFile(new File("teacher_attendance_summary.csv"));
            int userSelection = fileChooser.showSaveDialog(this);

            if (userSelection == JFileChooser.APPROVE_OPTION) {
                File fileToSave = fileChooser.getSelectedFile();
                if (!fileToSave.getName().toLowerCase().endsWith(".csv")) {
                    fileToSave = new File(fileToSave.getAbsolutePath() + ".csv");
                }

                try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileToSave))) {
                    // Write header
                    for (int i = 0; i < teacherAttendanceSummaryTableModel.getColumnCount(); i++) {
                        writer.write(teacherAttendanceSummaryTableModel.getColumnName(i));
                        if (i < teacherAttendanceSummaryTableModel.getColumnCount() - 1) {
                            writer.write(",");
                        }
                    }
                    writer.newLine();

                    // Write data rows
                    for (int i = 0; i < teacherAttendanceSummaryTableModel.getRowCount(); i++) {
                        for (int j = 0; j < teacherAttendanceSummaryTableModel.getColumnCount(); j++) {
                            Object value = teacherAttendanceSummaryTableModel.getValueAt(i, j);
                            writer.write(value != null ? escapeCSV(value.toString()) : "");
                            if (j < teacherAttendanceSummaryTableModel.getColumnCount() - 1) {
                                writer.write(",");
                            }
                        }
                        writer.newLine();
                    }
                    parentFrame.showSuccess("Teacher attendance summary exported to: " + fileToSave.getAbsolutePath());
                } catch (IOException e) {
                    parentFrame.showError("Error exporting CSV: " + e.getMessage());
                    e.printStackTrace();
                }
            }
        }

        private void applyTeacherAttendanceReportSearchFilter(String searchText) {
            if (searchText.trim().length() == 0) {
                teacherAttendanceReportSorter.setRowFilter(null); // Clear the filter if search text is empty
            } else {
                // Search across Student Roll (col 0) and Student Name (col 1)
                teacherAttendanceReportSorter.setRowFilter(RowFilter.regexFilter("(?i)" + searchText, 0, 1));
            }
        }

        private void setupTeacherManageAssignmentsTab() {
            JPanel assignmentsPanel = new JPanel(new BorderLayout(10, 10));
            assignmentsPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
            assignmentsPanel.setBackground(UIUtils.BACKGROUND_COLOR);

            // --- Form Panel ---
            JPanel formPanel = new JPanel(new GridBagLayout());
            formPanel.setBackground(UIUtils.PANEL_COLOR);
            formPanel.setBorder(UIUtils.createPanelBorder());
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.insets = new Insets(5, 5, 5, 5);
            gbc.fill = GridBagConstraints.HORIZONTAL;

            JLabel titleLabel = new JLabel("Manage Assignments", SwingConstants.CENTER);
            titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
            titleLabel.setForeground(UIUtils.ACCENT_COLOR);
            gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
            formPanel.add(titleLabel, gbc);

            gbc.gridwidth = 1;

            gbc.gridx = 0; gbc.gridy = 1; formPanel.add(new JLabel("Course:"), gbc);
            gbc.gridx = 1; assignmentCourseComboBox = new JComboBox<>(); formPanel.add(assignmentCourseComboBox, gbc);

            gbc.gridx = 0; gbc.gridy = 2; formPanel.add(new JLabel("Title:"), gbc);
            gbc.gridx = 1; assignmentTitleField = new JTextField(20); formPanel.add(assignmentTitleField, gbc);

            gbc.gridx = 0; gbc.gridy = 3; formPanel.add(new JLabel("Description:"), gbc);
            gbc.gridx = 1; assignmentDescriptionArea = new JTextArea(3, 20); assignmentDescriptionArea.setLineWrap(true); assignmentDescriptionArea.setWrapStyleWord(true);
            JScrollPane descScrollPane = new JScrollPane(assignmentDescriptionArea);
            formPanel.add(descScrollPane, gbc);

            gbc.gridx = 0; gbc.gridy = 4; formPanel.add(new JLabel("Due Date (YYYY-MM-DD):"), gbc);
            gbc.gridx = 1; assignmentDueDateField = new JTextField(10); formPanel.add(assignmentDueDateField, gbc);

            JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
            addAssignmentButton = new JButton("Add Assignment");
            UIUtils.applyButtonStyle(addAssignmentButton);
            addAssignmentButton.addActionListener(e -> addAssignment());
            buttonPanel.add(addAssignmentButton);

            updateAssignmentButton = new JButton("Update Assignment");
            UIUtils.applyButtonStyle(updateAssignmentButton);
            updateAssignmentButton.addActionListener(e -> updateAssignment());
            buttonPanel.add(updateAssignmentButton);

            deleteAssignmentButton = new JButton("Delete Assignment");
            UIUtils.applyButtonStyle(deleteAssignmentButton);
            deleteAssignmentButton.setBackground(UIUtils.DANGER_COLOR);
            deleteAssignmentButton.addActionListener(e -> deleteAssignment());
            buttonPanel.add(deleteAssignmentButton);

            gbc.gridx = 0; gbc.gridy = 5; gbc.gridwidth = 2;
            formPanel.add(buttonPanel, gbc);

            assignmentsPanel.add(formPanel, BorderLayout.NORTH);

            // --- Table Panel ---
            String[] assignmentColumnNames = {"ID", "Course", "Title", "Due Date"};
            assignmentsTableModel = new DefaultTableModel(assignmentColumnNames, 0) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
            assignmentsTable = new JTable(assignmentsTableModel);
            UIUtils.styleTable(assignmentsTable);

            assignmentsTable.getSelectionModel().addListSelectionListener(e -> {
                if (!e.getValueIsAdjusting() && assignmentsTable.getSelectedRow() != -1) {
                    displayAssignmentDetails(assignmentsTable.convertRowIndexToModel(assignmentsTable.getSelectedRow()));
                }
            });

            JScrollPane assignmentsTableScrollPane = new JScrollPane(assignmentsTable);
            assignmentsTableScrollPane.setBorder(UIUtils.createPanelBorder());
            assignmentsPanel.add(assignmentsTableScrollPane, BorderLayout.CENTER);

            sidebar.addMenuItem("Manage Assignments", assignmentsPanel);
            loadTeacherCoursesForAssignmentComboBox();
            loadAssignments();
        }

        private void loadTeacherCoursesForAssignmentComboBox() {
            assignmentCourseComboBox.removeAllItems();
            assignmentCourseComboBox.addItem("Select Course");
            // FIX: Ensure 'teacher_user_id' is used correctly in the WHERE clause
            String sql = "SELECT id, name FROM courses WHERE teacher_user_id = ? ORDER BY name ASC";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                pstmt.setInt(1, loggedInUser.getId());
                ResultSet rs = pstmt.executeQuery();
                while (rs.next()) {
                    assignmentCourseComboBox.addItem(rs.getString("name") + " (ID: " + rs.getInt("id") + ")");
                }
            } catch (SQLException e) {
                parentFrame.showError("Error loading courses for assignments: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private int getCourseIdFromAssignmentComboBox(String selectedItem) {
            if (selectedItem == null || selectedItem.equals("Select Course")) {
                return -1;
            }
            int startIndex = selectedItem.lastIndexOf("(ID: ") + 5;
            int endIndex = selectedItem.lastIndexOf(")");
            if (startIndex > 0 && endIndex > startIndex) {
                try {
                    return Integer.parseInt(selectedItem.substring(startIndex, endIndex));
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                    return -1;
                }
            }
            return -1;
        }

        private void loadAssignments() {
            assignmentsTableModel.setRowCount(0);
            // FIX: Ensure 'teacher_user_id' is used correctly in the WHERE clause
            String sql = "SELECT a.id, a.title, a.description, a.due_date, c.name as course_name, c.id as course_id " +
                         "FROM assignments a JOIN courses c ON a.course_id = c.id " +
                         "WHERE c.teacher_user_id = ? ORDER BY a.due_date DESC";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                pstmt.setInt(1, loggedInUser.getId());
                ResultSet rs = pstmt.executeQuery();
                while (rs.next()) {
                    Vector<Object> row = new Vector<>();
                    row.add(rs.getInt("id"));
                    row.add(rs.getString("course_name"));
                    row.add(rs.getString("title"));
                    row.add(rs.getDate("due_date"));
                    assignmentsTableModel.addRow(row);
                }
            } catch (SQLException e) {
                parentFrame.showError("Error loading assignments: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private void displayAssignmentDetails(int modelRowIndex) {
            int assignmentId = (int) assignmentsTableModel.getValueAt(modelRowIndex, 0);
            String courseName = (String) assignmentsTableModel.getValueAt(modelRowIndex, 1);
            String title = (String) assignmentsTableModel.getValueAt(modelRowIndex, 2);
            Date dueDate = (Date) assignmentsTableModel.getValueAt(modelRowIndex, 3);

            // Fetch description from DB as it's not in table model
            String description = "";
            int courseId = -1;
            String sql = "SELECT description, course_id FROM assignments WHERE id = ?";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                pstmt.setInt(1, assignmentId);
                ResultSet rs = pstmt.executeQuery();
                if (rs.next()) {
                    description = rs.getString("description");
                    courseId = rs.getInt("course_id");
                }
            } catch (SQLException e) {
                parentFrame.showError("Error fetching assignment description: " + e.getMessage());
                e.printStackTrace();
            }

            assignmentCourseComboBox.setSelectedItem(courseName + " (ID: " + courseId + ")");
            assignmentTitleField.setText(title);
            assignmentDescriptionArea.setText(description);
            assignmentDueDateField.setText(dueDate != null ? dueDate.toString() : "");
        }

        private void addAssignment() {
            int courseId = getCourseIdFromAssignmentComboBox((String) assignmentCourseComboBox.getSelectedItem());
            String title = assignmentTitleField.getText().trim();
            String description = assignmentDescriptionArea.getText().trim();
            String dueDateStr = assignmentDueDateField.getText().trim();

            if (courseId == -1 || title.isEmpty() || dueDateStr.isEmpty()) {
                parentFrame.showError("Course, Title, and Due Date are required.");
                return;
            }

            Date dueDate;
            try {
                dueDate = Date.valueOf(dueDateStr);
            } catch (IllegalArgumentException e) {
                parentFrame.showError("Invalid Due Date format. Please use YYYY-MM-DD.");
                return;
            }

            String sql = "INSERT INTO assignments (course_id, title, description, due_date) VALUES (?, ?, ?, ?)";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                pstmt.setInt(1, courseId);
                pstmt.setString(2, title);
                pstmt.setString(3, description.isEmpty() ? null : description);
                pstmt.setDate(4, dueDate);
                pstmt.executeUpdate();
                parentFrame.showSuccess("Assignment added successfully!");
                loadAssignments();
                clearAssignmentForm();
            } catch (SQLException e) {
                parentFrame.showError("Error adding assignment: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private void updateAssignment() {
            int selectedRow = assignmentsTable.getSelectedRow();
            if (selectedRow == -1) {
                parentFrame.showError("Please select an assignment to update.");
                return;
            }

            int modelRow = assignmentsTable.convertRowIndexToModel(selectedRow);
            int assignmentId = (int) assignmentsTableModel.getValueAt(modelRow, 0);

            int courseId = getCourseIdFromAssignmentComboBox((String) assignmentCourseComboBox.getSelectedItem());
            String title = assignmentTitleField.getText().trim();
            String description = assignmentDescriptionArea.getText().trim();
            String dueDateStr = assignmentDueDateField.getText().trim();

            if (courseId == -1 || title.isEmpty() || dueDateStr.isEmpty()) {
                parentFrame.showError("Course, Title, and Due Date are required.");
                return;
            }

            Date dueDate;
            try {
                dueDate = Date.valueOf(dueDateStr);
            } catch (IllegalArgumentException e) {
                parentFrame.showError("Invalid Due Date format. Please use YYYY-MM-DD.");
                return;
            }

            String sql = "UPDATE assignments SET course_id = ?, title = ?, description = ?, due_date = ? WHERE id = ?";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                pstmt.setInt(1, courseId);
                pstmt.setString(2, title);
                pstmt.setString(3, description.isEmpty() ? null : description);
                pstmt.setDate(4, dueDate);
                pstmt.setInt(5, assignmentId);
                int affectedRows = pstmt.executeUpdate();
                if (affectedRows > 0) {
                    parentFrame.showSuccess("Assignment updated successfully!");
                    loadAssignments();
                    clearAssignmentForm();
                } else {
                    parentFrame.showError("Failed to update assignment. Assignment not found.");
                }
            } catch (SQLException e) {
                parentFrame.showError("Error updating assignment: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private void deleteAssignment() {
            int selectedRow = assignmentsTable.getSelectedRow();
            if (selectedRow == -1) {
                parentFrame.showError("Please select an assignment to delete.");
                return;
            }

            int confirm = parentFrame.showConfirmDialogCustom(this, "Are you sure you want to delete this assignment? This will also delete associated grades.", "Confirm Deletion", JOptionPane.YES_NO_OPTION);
            if (confirm != JOptionPane.YES_OPTION) {
                return;
            }

            int modelRow = assignmentsTable.convertRowIndexToModel(selectedRow);
            int assignmentId = (int) assignmentsTableModel.getValueAt(modelRow, 0);

            try {
                String sql = "DELETE FROM assignments WHERE id = ?";
                try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                    pstmt.setInt(1, assignmentId);
                    int affectedRows = pstmt.executeUpdate();
                    if (affectedRows > 0) {
                        parentFrame.showSuccess("Assignment deleted successfully!");
                        loadAssignments();
                        clearAssignmentForm();
                    } else {
                        parentFrame.showError("Failed to delete assignment. Assignment not found.");
                    }
                }
            } catch (SQLException e) {
                parentFrame.showError("Error deleting assignment: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private void clearAssignmentForm() {
            assignmentCourseComboBox.setSelectedItem("Select Course");
            assignmentTitleField.setText("");
            assignmentDescriptionArea.setText("");
            assignmentDueDateField.setText("");
            assignmentsTable.clearSelection();
        }

        private void setupTeacherManageGradesTab() {
            JPanel gradesPanel = new JPanel(new BorderLayout(10, 10));
            gradesPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
            gradesPanel.setBackground(UIUtils.BACKGROUND_COLOR);

            // --- Form Panel ---
            JPanel formPanel = new JPanel(new GridBagLayout());
            formPanel.setBackground(UIUtils.PANEL_COLOR);
            formPanel.setBorder(UIUtils.createPanelBorder());
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.insets = new Insets(5, 5, 5, 5);
            gbc.fill = GridBagConstraints.HORIZONTAL;

            JLabel titleLabel = new JLabel("Manage Grades", SwingConstants.CENTER);
            titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
            titleLabel.setForeground(UIUtils.ACCENT_COLOR);
            gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
            formPanel.add(titleLabel, gbc);

            gbc.gridwidth = 1;

            gbc.gridx = 0; gbc.gridy = 1; formPanel.add(new JLabel("Course:"), gbc);
            gbc.gridx = 1; gradeCourseComboBox = new JComboBox<>(); formPanel.add(gradeCourseComboBox, gbc);

            gbc.gridx = 0; gbc.gridy = 2; formPanel.add(new JLabel("Assignment:"), gbc);
            gbc.gridx = 1; gradeAssignmentComboBox = new JComboBox<>(); formPanel.add(gradeAssignmentComboBox, gbc);

            gbc.gridx = 0; gbc.gridy = 3; formPanel.add(new JLabel("Student:"), gbc);
            gbc.gridx = 1; gradeStudentComboBox = new JComboBox<>(); formPanel.add(gradeStudentComboBox, gbc);

            gbc.gridx = 0; gbc.gridy = 4; formPanel.add(new JLabel("Grade (0-100):"), gbc);
            gbc.gridx = 1; gradeField = new JTextField(10); formPanel.add(gradeField, gbc);

            gbc.gridx = 0; gbc.gridy = 5; formPanel.add(new JLabel("Feedback:"), gbc);
            gbc.gridx = 1; gradeFeedbackArea = new JTextArea(3, 20); gradeFeedbackArea.setLineWrap(true); gradeFeedbackArea.setWrapStyleWord(true);
            JScrollPane feedbackScrollPane = new JScrollPane(gradeFeedbackArea);
            formPanel.add(feedbackScrollPane, gbc);

            JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
            addGradeButton = new JButton("Add Grade");
            UIUtils.applyButtonStyle(addGradeButton);
            addGradeButton.addActionListener(e -> addGrade());
            buttonPanel.add(addGradeButton);

            updateGradeButton = new JButton("Update Grade");
            UIUtils.applyButtonStyle(updateGradeButton);
            updateGradeButton.addActionListener(e -> updateGrade());
            buttonPanel.add(updateGradeButton);

            gbc.gridx = 0; gbc.gridy = 6; gbc.gridwidth = 2;
            formPanel.add(buttonPanel, gbc);

            gradesPanel.add(formPanel, BorderLayout.NORTH);

            // --- Table Panel ---
            String[] gradesColumnNames = {"ID", "Course", "Assignment", "Student Roll", "Student Name", "Grade", "Feedback", "Graded At"};
            gradesTableModel = new DefaultTableModel(gradesColumnNames, 0) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
            gradesTable = new JTable(gradesTableModel);
            UIUtils.styleTable(gradesTable);

            gradesTable.getSelectionModel().addListSelectionListener(e -> {
                if (!e.getValueIsAdjusting() && gradesTable.getSelectedRow() != -1) {
                    displayGradeDetails(gradesTable.convertRowIndexToModel(gradesTable.getSelectedRow()));
                }
            });

            JScrollPane gradesTableScrollPane = new JScrollPane(gradesTable);
            gradesTableScrollPane.setBorder(UIUtils.createPanelBorder());
            gradesPanel.add(gradesTableScrollPane, BorderLayout.CENTER);

            sidebar.addMenuItem("Manage Grades", gradesPanel);
            loadTeacherCoursesForGradeComboBox();
            gradeCourseComboBox.addItemListener(e -> {
                if (e.getStateChange() == ItemEvent.SELECTED) {
                    loadAssignmentsForGradeComboBox();
                    loadStudentsForGradeComboBox();
                }
            });
            gradeAssignmentComboBox.addItemListener(e -> {
                if (e.getStateChange() == ItemEvent.SELECTED) {
                    loadGrades(); // Reload grades when assignment changes
                }
            });
            loadGrades(); // Initial load
        }

        private void loadTeacherCoursesForGradeComboBox() {
            gradeCourseComboBox.removeAllItems();
            gradeCourseComboBox.addItem("Select Course");
            // FIX: Ensure 'teacher_user_id' is used correctly in the WHERE clause
            String sql = "SELECT id, name FROM courses WHERE teacher_user_id = ? ORDER BY name ASC";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                pstmt.setInt(1, loggedInUser.getId());
                ResultSet rs = pstmt.executeQuery();
                while (rs.next()) {
                    gradeCourseComboBox.addItem(rs.getString("name") + " (ID: " + rs.getInt("id") + ")");
                }
            } catch (SQLException e) {
                parentFrame.showError("Error loading courses for grades: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private int getCourseIdFromGradeComboBox(String selectedItem) {
            if (selectedItem == null || selectedItem.equals("Select Course")) {
                return -1;
                      }
            int startIndex = selectedItem.lastIndexOf("(ID: ") + 5;
            int endIndex = selectedItem.lastIndexOf(")");
            if (startIndex > 0 && endIndex > startIndex) {
                try {
                    return Integer.parseInt(selectedItem.substring(startIndex, endIndex));
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                    return -1;
                }
            }
            return -1;
        }

        private void loadAssignmentsForGradeComboBox() {
            gradeAssignmentComboBox.removeAllItems();
            gradeAssignmentComboBox.addItem("Select Assignment");
            int courseId = getCourseIdFromGradeComboBox((String) gradeCourseComboBox.getSelectedItem());
            if (courseId == -1) {
                return;
            }

            String sql = "SELECT id, title FROM assignments WHERE course_id = ? ORDER BY title ASC";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                pstmt.setInt(1, courseId);
                ResultSet rs = pstmt.executeQuery();
                while (rs.next()) {
                    gradeAssignmentComboBox.addItem(rs.getString("title") + " (ID: " + rs.getInt("id") + ")");
                }
            } catch (SQLException e) {
                parentFrame.showError("Error loading assignments for grades: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private int getAssignmentIdFromGradeComboBox(String selectedItem) {
            if (selectedItem == null || selectedItem.equals("Select Assignment")) {
                return -1;
            }
            int startIndex = selectedItem.lastIndexOf("(ID: ") + 5;
            int endIndex = selectedItem.lastIndexOf(")");
            if (startIndex > 0 && endIndex > startIndex) {
                try {
                    return Integer.parseInt(selectedItem.substring(startIndex, endIndex));
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                    return -1;
                }
            }
            return -1;
        }

        private void loadStudentsForGradeComboBox() {
            gradeStudentComboBox.removeAllItems();
            gradeStudentComboBox.addItem("Select Student");
            int courseId = getCourseIdFromGradeComboBox((String) gradeCourseComboBox.getSelectedItem());
            if (courseId == -1) {
                return;
            }

            // Load students enrolled in the selected course
            String sql = "SELECT s.id, s.name, s.roll_no FROM students s JOIN student_courses sc ON s.id = sc.student_id WHERE sc.course_id = ? ORDER BY s.name ASC";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                pstmt.setInt(1, courseId);
                ResultSet rs = pstmt.executeQuery();
                while (rs.next()) {
                    gradeStudentComboBox.addItem(rs.getString("name") + " (" + rs.getString("roll_no") + ") (ID: " + rs.getInt("id") + ")");
                }
            } catch (SQLException e) {
                parentFrame.showError("Error loading students for grades: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private int getStudentIdFromGradeComboBox(String selectedItem) {
            if (selectedItem == null || selectedItem.equals("Select Student")) {
                return -1;
            }
            int startIndex = selectedItem.lastIndexOf("(ID: ") + 5;
            int endIndex = selectedItem.lastIndexOf(")");
            if (startIndex > 0 && endIndex > startIndex) {
                try {
                    return Integer.parseInt(selectedItem.substring(startIndex, endIndex));
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                    return -1;
                }
            }
            return -1;
        }

        private void loadGrades() {
            gradesTableModel.setRowCount(0);
            int courseId = getCourseIdFromGradeComboBox((String) gradeCourseComboBox.getSelectedItem());
            int assignmentId = getAssignmentIdFromGradeComboBox((String) gradeAssignmentComboBox.getSelectedItem());

            StringBuilder sqlBuilder = new StringBuilder();
            sqlBuilder.append("SELECT g.id, c.name as course_name, a.title as assignment_title, s.roll_no, s.name as student_name, g.grade, g.feedback, g.graded_at ");
            sqlBuilder.append("FROM grades g ");
            sqlBuilder.append("JOIN assignments a ON g.assignment_id = a.id ");
            sqlBuilder.append("JOIN courses c ON a.course_id = c.id ");
            sqlBuilder.append("JOIN students s ON g.student_id = s.id ");
            sqlBuilder.append("WHERE c.teacher_user_id = ? "); // Filter by logged-in teacher's courses

            List<Object> params = new ArrayList<>();
            params.add(loggedInUser.getId());

            if (courseId != -1) {
                sqlBuilder.append(" AND c.id = ?");
                params.add(courseId);
            }
            if (assignmentId != -1) {
                sqlBuilder.append(" AND a.id = ?");
                params.add(assignmentId);
            }

            sqlBuilder.append(" ORDER BY c.name, a.title, s.name ASC");

            try (PreparedStatement pstmt = connection.prepareStatement(sqlBuilder.toString())) {
                for (int i = 0; i < params.size(); i++) {
                    pstmt.setObject(i + 1, params.get(i));
                }
                ResultSet rs = pstmt.executeQuery();
                while (rs.next()) {
                    Vector<Object> row = new Vector<>();
                    row.add(rs.getInt("id"));
                    row.add(rs.getString("course_name"));
                    row.add(rs.getString("assignment_title"));
                    row.add(rs.getString("roll_no"));
                    row.add(rs.getString("student_name"));
                    row.add(rs.getBigDecimal("grade"));
                    row.add(rs.getString("feedback"));
                    row.add(rs.getTimestamp("graded_at"));
                    gradesTableModel.addRow(row);
                }
            } catch (SQLException e) {
                parentFrame.showError("Error loading grades: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private void displayGradeDetails(int modelRowIndex) {
            int gradeId = (int) gradesTableModel.getValueAt(modelRowIndex, 0);

            // Fetch full details from DB as not all are in table model
            String sql = "SELECT g.assignment_id, g.student_id, g.grade, g.feedback, a.course_id, c.name as course_name, a.title as assignment_title, s.name as student_name, s.roll_no " +
                         "FROM grades g JOIN assignments a ON g.assignment_id = a.id JOIN courses c ON a.course_id = c.id JOIN students s ON g.student_id = s.id WHERE g.id = ?";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                pstmt.setInt(1, gradeId);
                ResultSet rs = pstmt.executeQuery();
                if (rs.next()) {
                    int courseId = rs.getInt("course_id");
                    int assignmentId = rs.getInt("assignment_id");
                    int studentId = rs.getInt("student_id");
                    BigDecimal grade = rs.getBigDecimal("grade");
                    String feedback = rs.getString("feedback");

                    // Set combo box selections
                    gradeCourseComboBox.setSelectedItem(rs.getString("course_name") + " (ID: " + courseId + ")");
                    // Need to ensure assignments and students are loaded for the selected course first
                    loadAssignmentsForGradeComboBox();
                    loadStudentsForGradeComboBox();
                    gradeAssignmentComboBox.setSelectedItem(rs.getString("assignment_title") + " (ID: " + assignmentId + ")");
                    gradeStudentComboBox.setSelectedItem(rs.getString("student_name") + " (" + rs.getString("roll_no") + ") (ID: " + studentId + ")");

                    gradeField.setText(grade != null ? grade.toPlainString() : "");
                    gradeFeedbackArea.setText(feedback != null ? feedback : "");
                }
            } catch (SQLException e) {
                parentFrame.showError("Error fetching grade details: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private void addGrade() {
            int assignmentId = getAssignmentIdFromGradeComboBox((String) gradeAssignmentComboBox.getSelectedItem());
            int studentId = getStudentIdFromGradeComboBox((String) gradeStudentComboBox.getSelectedItem());
            String gradeStr = gradeField.getText().trim();
            String feedback = gradeFeedbackArea.getText().trim();

            if (assignmentId == -1 || studentId == -1 || gradeStr.isEmpty()) {
                parentFrame.showError("Assignment, Student, and Grade are required.");
                return;
            }

            BigDecimal grade;
            try {
                grade = new BigDecimal(gradeStr);
                if (grade.compareTo(BigDecimal.ZERO) < 0 || grade.compareTo(new BigDecimal("100")) > 0) {
                    parentFrame.showError("Grade must be between 0 and 100.");
                    return;
                }
            } catch (NumberFormatException e) {
                parentFrame.showError("Invalid grade format. Please enter a number.");
                return;
            }

            String sql = "INSERT INTO grades (assignment_id, student_id, grade, feedback) VALUES (?, ?, ?, ?)";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                pstmt.setInt(1, assignmentId);
                pstmt.setInt(2, studentId);
                pstmt.setBigDecimal(3, grade);
                pstmt.setString(4, feedback.isEmpty() ? null : feedback);
                pstmt.executeUpdate();
                parentFrame.showSuccess("Grade added successfully!");
                loadGrades();
                clearGradeForm();
            } catch (SQLIntegrityConstraintViolationException e) {
                parentFrame.showError("A grade for this student on this assignment already exists. Use 'Update Grade' instead.");
                e.printStackTrace();
            } catch (SQLException e) {
                parentFrame.showError("Error adding grade: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private void updateGrade() {
            int selectedRow = gradesTable.getSelectedRow();
            if (selectedRow == -1) {
                parentFrame.showError("Please select a grade to update.");
                return;
            }

            int modelRow = gradesTable.convertRowIndexToModel(selectedRow);
            int gradeId = (int) gradesTableModel.getValueAt(modelRow, 0);

            int assignmentId = getAssignmentIdFromGradeComboBox((String) gradeAssignmentComboBox.getSelectedItem());
            int studentId = getStudentIdFromGradeComboBox((String) gradeStudentComboBox.getSelectedItem());
            String gradeStr = gradeField.getText().trim();
            String feedback = gradeFeedbackArea.getText().trim();

            if (assignmentId == -1 || studentId == -1 || gradeStr.isEmpty()) {
                parentFrame.showError("Assignment, Student, and Grade are required.");
                return;
            }

            BigDecimal grade;
            try {
                grade = new BigDecimal(gradeStr);
                if (grade.compareTo(BigDecimal.ZERO) < 0 || grade.compareTo(new BigDecimal("100")) > 0) {
                    parentFrame.showError("Grade must be between 0 and 100.");
                    return;
                }
            } catch (NumberFormatException e) {
                parentFrame.showError("Invalid grade format. Please enter a number.");
                return;
            }

            String sql = "UPDATE grades SET assignment_id = ?, student_id = ?, grade = ?, feedback = ? WHERE id = ?";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                pstmt.setInt(1, assignmentId);
                pstmt.setInt(2, studentId);
                pstmt.setBigDecimal(3, grade);
                pstmt.setString(4, feedback.isEmpty() ? null : feedback);
                pstmt.setInt(5, gradeId);
                int affectedRows = pstmt.executeUpdate();
                if (affectedRows > 0) {
                    parentFrame.showSuccess("Grade updated successfully!");
                    loadGrades();
                    clearGradeForm();
                } else {
                    parentFrame.showError("Failed to update grade. Grade not found.");
                }
            } catch (SQLIntegrityConstraintViolationException e) {
                parentFrame.showError("Cannot update to this combination of assignment and student as it already exists for another grade entry.");
                e.printStackTrace();
            } catch (SQLException e) {
                parentFrame.showError("Error updating grade: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private void clearGradeForm() {
            gradeCourseComboBox.setSelectedItem("Select Course");
            gradeAssignmentComboBox.setSelectedItem("Select Assignment");
            gradeStudentComboBox.setSelectedItem("Select Student");
            gradeField.setText("");
            gradeFeedbackArea.setText("");
            gradesTable.clearSelection();
        }

        private void setupTeacherUploadCourseMaterialsTab() {
            JPanel materialsPanel = new JPanel(new BorderLayout(10, 10));
            materialsPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
            materialsPanel.setBackground(UIUtils.BACKGROUND_COLOR);

            // --- Form Panel ---
            JPanel formPanel = new JPanel(new GridBagLayout());
            formPanel.setBackground(UIUtils.PANEL_COLOR);
            formPanel.setBorder(UIUtils.createPanelBorder());
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.insets = new Insets(5, 5, 5, 5);
            gbc.fill = GridBagConstraints.HORIZONTAL;

            JLabel titleLabel = new JLabel("Upload Course Materials", SwingConstants.CENTER);
            titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
            titleLabel.setForeground(UIUtils.ACCENT_COLOR);
            gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
            formPanel.add(titleLabel, gbc);

            gbc.gridwidth = 1;

            gbc.gridx = 0; gbc.gridy = 1; formPanel.add(new JLabel("Course:"), gbc);
            gbc.gridx = 1; materialCourseComboBox = new JComboBox<>(); formPanel.add(materialCourseComboBox, gbc);

            gbc.gridx = 0; gbc.gridy = 2; formPanel.add(new JLabel("Title:"), gbc);
            gbc.gridx = 1; materialTitleField = new JTextField(20); formPanel.add(materialTitleField, gbc);

            gbc.gridx = 0; gbc.gridy = 3; formPanel.add(new JLabel("File Path/Link:"), gbc);
            gbc.gridx = 1;
            JPanel filePanel = new JPanel(new BorderLayout());
            materialFilePathField = new JTextField(20);
            materialFilePathField.setEditable(false); // Path is set by browse button
            filePanel.add(materialFilePathField, BorderLayout.CENTER);
            browseMaterialButton = new JButton("Browse");
            UIUtils.applyButtonStyle(browseMaterialButton);
            browseMaterialButton.addActionListener(e -> browseForMaterialFile());
            filePanel.add(browseMaterialButton, BorderLayout.EAST);
            formPanel.add(filePanel, gbc);

            JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
            uploadMaterialButton = new JButton("Upload Material");
            UIUtils.applyButtonStyle(uploadMaterialButton);
            uploadMaterialButton.addActionListener(e -> uploadMaterial());
            buttonPanel.add(uploadMaterialButton);

            deleteMaterialButton = new JButton("Delete Material");
            UIUtils.applyButtonStyle(deleteMaterialButton);
            deleteMaterialButton.setBackground(UIUtils.DANGER_COLOR);
            deleteMaterialButton.addActionListener(e -> deleteMaterial());
            buttonPanel.add(deleteMaterialButton);

            viewMaterialButton = new JButton("View Material");
            UIUtils.applyButtonStyle(viewMaterialButton);
            viewMaterialButton.addActionListener(e -> viewMaterial());
            buttonPanel.add(viewMaterialButton);

            gbc.gridx = 0; gbc.gridy = 4; gbc.gridwidth = 2;
            formPanel.add(buttonPanel, gbc);

            materialsPanel.add(formPanel, BorderLayout.NORTH);

            // --- Table Panel ---
            String[] materialsColumnNames = {"ID", "Course", "Title", "File Path", "Upload Date"};
            courseMaterialsTableModel = new DefaultTableModel(materialsColumnNames, 0) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
            courseMaterialsTable = new JTable(courseMaterialsTableModel);
            UIUtils.styleTable(courseMaterialsTable);

            courseMaterialsTable.getSelectionModel().addListSelectionListener(e -> {
                if (!e.getValueIsAdjusting() && courseMaterialsTable.getSelectedRow() != -1) {
                    displayMaterialDetails(courseMaterialsTable.convertRowIndexToModel(courseMaterialsTable.getSelectedRow()));
                }
            });

            JScrollPane materialsTableScrollPane = new JScrollPane(courseMaterialsTable);
            materialsTableScrollPane.setBorder(UIUtils.createPanelBorder());
            materialsPanel.add(materialsTableScrollPane, BorderLayout.CENTER);

            sidebar.addMenuItem("Course Materials", materialsPanel);
            loadTeacherCoursesForMaterialComboBox();
            loadCourseMaterials();
        }

        private void loadTeacherCoursesForMaterialComboBox() {
            materialCourseComboBox.removeAllItems();
            materialCourseComboBox.addItem("Select Course");
            String sql = "SELECT id, name FROM courses WHERE teacher_user_id = ? ORDER BY name ASC";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                pstmt.setInt(1, loggedInUser.getId());
                ResultSet rs = pstmt.executeQuery();
                while (rs.next()) {
                    materialCourseComboBox.addItem(rs.getString("name") + " (ID: " + rs.getInt("id") + ")");
                }
            } catch (SQLException e) {
                parentFrame.showError("Error loading courses for materials: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private int getCourseIdFromMaterialComboBox(String selectedItem) {
            if (selectedItem == null || selectedItem.equals("Select Course")) {
                return -1;
            }
            int startIndex = selectedItem.lastIndexOf("(ID: ") + 5;
            int endIndex = selectedItem.lastIndexOf(")");
            if (startIndex > 0 && endIndex > startIndex) {
                try {
                    return Integer.parseInt(selectedItem.substring(startIndex, endIndex));
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                    return -1;
                }
            }
            return -1;
        }

        private void loadCourseMaterials() {
            courseMaterialsTableModel.setRowCount(0);
            String sql = "SELECT cm.id, cm.title, cm.file_path, cm.upload_date, c.name as course_name " +
                         "FROM course_materials cm JOIN courses c ON cm.course_id = c.id " +
                         "WHERE c.teacher_user_id = ? ORDER BY cm.upload_date DESC";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                pstmt.setInt(1, loggedInUser.getId());
                ResultSet rs = pstmt.executeQuery();
                while (rs.next()) {
                    Vector<Object> row = new Vector<>();
                    row.add(rs.getInt("id"));
                    row.add(rs.getString("course_name"));
                    row.add(rs.getString("title"));
                    row.add(rs.getString("file_path"));
                    row.add(rs.getTimestamp("upload_date"));
                    courseMaterialsTableModel.addRow(row);
                }
            } catch (SQLException e) {
                parentFrame.showError("Error loading course materials: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private void displayMaterialDetails(int modelRowIndex) {
            String courseName = (String) courseMaterialsTableModel.getValueAt(modelRowIndex, 1);
            String title = (String) courseMaterialsTableModel.getValueAt(modelRowIndex, 2);
            String filePath = (String) courseMaterialsTableModel.getValueAt(modelRowIndex, 3);

            // Find course ID to set combo box
            int courseId = -1;
            String sql = "SELECT id FROM courses WHERE name = ?";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                pstmt.setString(1, courseName);
                ResultSet rs = pstmt.executeQuery();
                if (rs.next()) {
                    courseId = rs.getInt("id");
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }

            if (courseId != -1) {
                materialCourseComboBox.setSelectedItem(courseName + " (ID: " + courseId + ")");
            } else {
                materialCourseComboBox.setSelectedItem("Select Course");
            }
            materialTitleField.setText(title);
            materialFilePathField.setText(filePath);
            selectedMaterialFile = null; // Clear selected file when displaying existing
        }

        private void browseForMaterialFile() {
            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setDialogTitle("Select Course Material File");
            int userSelection = fileChooser.showOpenDialog(this);

            if (userSelection == JFileChooser.APPROVE_OPTION) {
                selectedMaterialFile = fileChooser.getSelectedFile();
                materialFilePathField.setText(selectedMaterialFile.getAbsolutePath());
            }
        }

        private void uploadMaterial() {
            int courseId = getCourseIdFromMaterialComboBox((String) materialCourseComboBox.getSelectedItem());
            String title = materialTitleField.getText().trim();
            String filePath = materialFilePathField.getText().trim(); // This could be a local path or a URL

            if (courseId == -1 || title.isEmpty() || filePath.isEmpty()) {
                parentFrame.showError("Course, Title, and File Path/Link are required.");
                return;
            }

            String finalPathToStore = filePath; // Default to entered path/link

            // If a local file was selected via browse, copy it to our materials directory
            if (selectedMaterialFile != null && selectedMaterialFile.exists()) {
                try {
                    String fileName = System.currentTimeMillis() + "_" + selectedMaterialFile.getName();
                    File destinationFile = new File("course_materials_files", fileName);
                    Files.copy(selectedMaterialFile.toPath(), destinationFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
                    finalPathToStore = destinationFile.getAbsolutePath(); // Store the path to the copied file
                } catch (IOException ex) {
                    parentFrame.showError("Error copying file: " + ex.getMessage());
                    ex.printStackTrace();
                    return;
                }
            }

            String sql = "INSERT INTO course_materials (course_id, title, file_path) VALUES (?, ?, ?)";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                pstmt.setInt(1, courseId);
                pstmt.setString(2, title);
                pstmt.setString(3, finalPathToStore);
                pstmt.executeUpdate();
                parentFrame.showSuccess("Course material uploaded successfully!");
                loadCourseMaterials();
                clearMaterialForm();
            } catch (SQLException e) {
                parentFrame.showError("Error uploading material: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private void deleteMaterial() {
            int selectedRow = courseMaterialsTable.getSelectedRow();
            if (selectedRow == -1) {
                parentFrame.showError("Please select a material to delete.");
                return;
            }

            int confirm = parentFrame.showConfirmDialogCustom(this, "Are you sure you want to delete this material?", "Confirm Deletion", JOptionPane.YES_NO_OPTION);
            if (confirm != JOptionPane.YES_OPTION) {
                return;
            }

            int modelRow = courseMaterialsTable.convertRowIndexToModel(selectedRow);
            int materialId = (int) courseMaterialsTableModel.getValueAt(modelRow, 0);
            String filePath = (String) courseMaterialsTableModel.getValueAt(modelRow, 3);

            try {
                String sql = "DELETE FROM course_materials WHERE id = ?";
                try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                    pstmt.setInt(1, materialId);
                    int affectedRows = pstmt.executeUpdate();
                    if (affectedRows > 0) {
                        // Optionally delete the physical file if it's a local path
                        File materialFile = new File(filePath);
                        if (materialFile.exists() && materialFile.isFile() && materialFile.getParentFile().getName().equals("course_materials_files")) {
                            if (materialFile.delete()) {
                                System.out.println("Physical file deleted: " + filePath);
                            } else {
                                System.err.println("Failed to delete physical file: " + filePath);
                            }
                        }
                        parentFrame.showSuccess("Course material deleted successfully!");
                        loadCourseMaterials();
                        clearMaterialForm();
                    } else {
                        parentFrame.showError("Failed to delete material. Material not found.");
                    }
                }
            } catch (SQLException e) {
                parentFrame.showError("Error deleting material: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private void viewMaterial() {
            int selectedRow = courseMaterialsTable.getSelectedRow();
            if (selectedRow == -1) {
                parentFrame.showError("Please select a material to view.");
                return;
            }

            int modelRow = courseMaterialsTable.convertRowIndexToModel(selectedRow);
            String filePath = (String) courseMaterialsTableModel.getValueAt(modelRow, 3);

            if (filePath == null || filePath.isEmpty()) {
                parentFrame.showInfo("No file path or link available for this material.");
                return;
            }

            try {
                File file = new File(filePath);
                if (file.exists() && file.isFile()) {
                    // Open local file
                    Desktop.getDesktop().open(file);
                } else {
                    // Try to open as a URI (web link)
                    URI uri = new URI(filePath);
                    Desktop.getDesktop().browse(uri);
                }
            } catch (IOException | URISyntaxException e) {
                parentFrame.showError("Could not open material: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private void clearMaterialForm() {
            materialCourseComboBox.setSelectedItem("Select Course");
            materialTitleField.setText("");
            materialFilePathField.setText("");
            selectedMaterialFile = null;
            courseMaterialsTable.clearSelection();
        }

        private void setupTeacherClassScheduleTab() {
            JPanel schedulePanel = new JPanel(new BorderLayout(10, 10));
            schedulePanel.setBorder(new EmptyBorder(10, 10, 10, 10));
            schedulePanel.setBackground(UIUtils.BACKGROUND_COLOR);

            // --- Form Panel ---
            JPanel formPanel = new JPanel(new GridBagLayout());
            formPanel.setBackground(UIUtils.PANEL_COLOR);
            formPanel.setBorder(UIUtils.createPanelBorder());
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.insets = new Insets(5, 5, 5, 5);
            gbc.fill = GridBagConstraints.HORIZONTAL;

            JLabel titleLabel = new JLabel("Manage Class Schedules", SwingConstants.CENTER);
            titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
            titleLabel.setForeground(UIUtils.ACCENT_COLOR);
            gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
            formPanel.add(titleLabel, gbc);

            gbc.gridwidth = 1;

            gbc.gridx = 0; gbc.gridy = 1; formPanel.add(new JLabel("Course:"), gbc);
            gbc.gridx = 1; scheduleCourseComboBox = new JComboBox<>(); formPanel.add(scheduleCourseComboBox, gbc);

            gbc.gridx = 0; gbc.gridy = 2; formPanel.add(new JLabel("Day of Week:"), gbc);
            gbc.gridx = 1; scheduleDayOfWeekComboBox = new JComboBox<>(DayOfWeek.values()); formPanel.add(scheduleDayOfWeekComboBox, gbc);

            gbc.gridx = 0; gbc.gridy = 3; formPanel.add(new JLabel("Start Time (HH:MM):"), gbc);
            gbc.gridx = 1;
            SpinnerDateModel startTimeModel = new SpinnerDateModel();
            scheduleStartTimeSpinner = new JSpinner(startTimeModel);
            JSpinner.DateEditor startTimeEditor = new JSpinner.DateEditor(scheduleStartTimeSpinner, "HH:mm");
            scheduleStartTimeSpinner.setEditor(startTimeEditor);
            formPanel.add(scheduleStartTimeSpinner, gbc);

            gbc.gridx = 0; gbc.gridy = 4; formPanel.add(new JLabel("End Time (HH:MM):"), gbc);
            gbc.gridx = 1;
            SpinnerDateModel endTimeModel = new SpinnerDateModel();
            scheduleEndTimeSpinner = new JSpinner(endTimeModel);
            JSpinner.DateEditor endTimeEditor = new JSpinner.DateEditor(scheduleEndTimeSpinner, "HH:mm");
            scheduleEndTimeSpinner.setEditor(endTimeEditor);
            formPanel.add(scheduleEndTimeSpinner, gbc);

            JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
            addScheduleButton = new JButton("Add Schedule");
            UIUtils.applyButtonStyle(addScheduleButton);
            addScheduleButton.addActionListener(e -> addSchedule());
            buttonPanel.add(addScheduleButton);

            updateScheduleButton = new JButton("Update Schedule");
            UIUtils.applyButtonStyle(updateScheduleButton);
            updateScheduleButton.addActionListener(e -> updateSchedule());
            buttonPanel.add(updateScheduleButton);

            deleteScheduleButton = new JButton("Delete Schedule");
            UIUtils.applyButtonStyle(deleteScheduleButton);
            deleteScheduleButton.setBackground(UIUtils.DANGER_COLOR);
            deleteScheduleButton.addActionListener(e -> deleteSchedule());
            buttonPanel.add(deleteScheduleButton);

            gbc.gridx = 0; gbc.gridy = 5; gbc.gridwidth = 2;
            formPanel.add(buttonPanel, gbc);

            schedulePanel.add(formPanel, BorderLayout.NORTH);

            // --- Table Panel ---
            String[] scheduleColumnNames = {"ID", "Course", "Day", "Start Time", "End Time"};
            classScheduleTableModel = new DefaultTableModel(scheduleColumnNames, 0) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
            classScheduleTable = new JTable(classScheduleTableModel);
            UIUtils.styleTable(classScheduleTable);

            classScheduleTable.getSelectionModel().addListSelectionListener(e -> {
                if (!e.getValueIsAdjusting() && classScheduleTable.getSelectedRow() != -1) {
                    displayScheduleDetails(classScheduleTable.convertRowIndexToModel(classScheduleTable.getSelectedRow()));
                }
            });

            JScrollPane scheduleTableScrollPane = new JScrollPane(classScheduleTable);
            scheduleTableScrollPane.setBorder(UIUtils.createPanelBorder());
            schedulePanel.add(scheduleTableScrollPane, BorderLayout.CENTER);

            sidebar.addMenuItem("Class Schedule", schedulePanel);
            loadTeacherCoursesForScheduleComboBox();
            loadClassSchedules();
        }

        private void loadTeacherCoursesForScheduleComboBox() {
            scheduleCourseComboBox.removeAllItems();
            scheduleCourseComboBox.addItem("Select Course");
            String sql = "SELECT id, name FROM courses WHERE teacher_user_id = ? ORDER BY name ASC";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                pstmt.setInt(1, loggedInUser.getId());
                ResultSet rs = pstmt.executeQuery();
                while (rs.next()) {
                    scheduleCourseComboBox.addItem(rs.getString("name") + " (ID: " + rs.getInt("id") + ")");
                }
            } catch (SQLException e) {
                parentFrame.showError("Error loading courses for schedule: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private int getCourseIdFromScheduleComboBox(String selectedItem) {
            if (selectedItem == null || selectedItem.equals("Select Course")) {
                return -1;
            }
            int startIndex = selectedItem.lastIndexOf("(ID: ") + 5;
            int endIndex = selectedItem.lastIndexOf(")");
            if (startIndex > 0 && endIndex > startIndex) {
                try {
                    return Integer.parseInt(selectedItem.substring(startIndex, endIndex));
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                    return -1;
                }
            }
            return -1;
        }

        private void loadClassSchedules() {
            classScheduleTableModel.setRowCount(0);
            String sql = "SELECT cs.id, c.name as course_name, cs.day_of_week, cs.start_time, cs.end_time " +
                         "FROM class_schedules cs JOIN courses c ON cs.course_id = c.id " +
                         "WHERE c.teacher_user_id = ? ORDER BY c.name, FIELD(cs.day_of_week, 'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY', 'SUNDAY'), cs.start_time ASC";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                pstmt.setInt(1, loggedInUser.getId());
                ResultSet rs = pstmt.executeQuery();
                while (rs.next()) {
                    Vector<Object> row = new Vector<>();
                    row.add(rs.getInt("id"));
                    row.add(rs.getString("course_name"));
                    row.add(rs.getString("day_of_week"));
                    row.add(rs.getTime("start_time"));
                    row.add(rs.getTime("end_time"));
                    classScheduleTableModel.addRow(row);
                }
            } catch (SQLException e) {
                parentFrame.showError("Error loading class schedules: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private void displayScheduleDetails(int modelRowIndex) {
            String courseName = (String) classScheduleTableModel.getValueAt(modelRowIndex, 1);
            String dayOfWeek = (String) classScheduleTableModel.getValueAt(modelRowIndex, 2);
            Time startTime = (Time) classScheduleTableModel.getValueAt(modelRowIndex, 3);
            Time endTime = (Time) classScheduleTableModel.getValueAt(modelRowIndex, 4);

            // Find course ID to set combo box
            int courseId = -1;
            String sql = "SELECT id FROM courses WHERE name = ?";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                pstmt.setString(1, courseName);
                ResultSet rs = pstmt.executeQuery();
                if (rs.next()) {
                    courseId = rs.getInt("id");
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }

            if (courseId != -1) {
                scheduleCourseComboBox.setSelectedItem(courseName + " (ID: " + courseId + ")");
            } else {
                scheduleCourseComboBox.setSelectedItem("Select Course");
            }
            scheduleDayOfWeekComboBox.setSelectedItem(DayOfWeek.valueOf(dayOfWeek));
            scheduleStartTimeSpinner.setValue(new java.util.Date(startTime.getTime()));
            scheduleEndTimeSpinner.setValue(new java.util.Date(endTime.getTime()));
        }

        private void addSchedule() {
            int courseId = getCourseIdFromScheduleComboBox((String) scheduleCourseComboBox.getSelectedItem());
            DayOfWeek dayOfWeek = (DayOfWeek) scheduleDayOfWeekComboBox.getSelectedItem();
            java.util.Date startTimeDate = (java.util.Date) scheduleStartTimeSpinner.getValue();
            java.util.Date endTimeDate = (java.util.Date) scheduleEndTimeSpinner.getValue();

            if (courseId == -1 || dayOfWeek == null || startTimeDate == null || endTimeDate == null) {
                parentFrame.showError("All fields are required.");
                return;
            }

            LocalTime startTime = LocalTime.of(startTimeDate.getHours(), startTimeDate.getMinutes());
            LocalTime endTime = LocalTime.of(endTimeDate.getHours(), endTimeDate.getMinutes());

            if (endTime.isBefore(startTime) || endTime.equals(startTime)) {
                parentFrame.showError("End time must be after start time.");
                return;
            }

            String sql = "INSERT INTO class_schedules (course_id, day_of_week, start_time, end_time) VALUES (?, ?, ?, ?)";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                pstmt.setInt(1, courseId);
                pstmt.setString(2, dayOfWeek.toString());
                pstmt.setTime(3, Time.valueOf(startTime));
                pstmt.setTime(4, Time.valueOf(endTime));
                pstmt.executeUpdate();
                parentFrame.showSuccess("Class schedule added successfully!");
                loadClassSchedules();
                clearScheduleForm();
            } catch (SQLException e) {
                parentFrame.showError("Error adding schedule: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private void updateSchedule() {
            int selectedRow = classScheduleTable.getSelectedRow();
            if (selectedRow == -1) {
                parentFrame.showError("Please select a schedule to update.");
                return;
            }

            int modelRow = classScheduleTable.convertRowIndexToModel(selectedRow);
            int scheduleId = (int) classScheduleTableModel.getValueAt(modelRow, 0);

            int courseId = getCourseIdFromScheduleComboBox((String) scheduleCourseComboBox.getSelectedItem());
            DayOfWeek dayOfWeek = (DayOfWeek) scheduleDayOfWeekComboBox.getSelectedItem();
            java.util.Date startTimeDate = (java.util.Date) scheduleStartTimeSpinner.getValue();
            java.util.Date endTimeDate = (java.util.Date) scheduleEndTimeSpinner.getValue();

            if (courseId == -1 || dayOfWeek == null || startTimeDate == null || endTimeDate == null) {
                parentFrame.showError("All fields are required.");
                return;
            }

            LocalTime startTime = LocalTime.of(startTimeDate.getHours(), startTimeDate.getMinutes());
            LocalTime endTime = LocalTime.of(endTimeDate.getHours(), endTimeDate.getMinutes());

            if (endTime.isBefore(startTime) || endTime.equals(startTime)) {
                parentFrame.showError("End time must be after start time.");
                return;
            }

            String sql = "UPDATE class_schedules SET course_id = ?, day_of_week = ?, start_time = ?, end_time = ? WHERE id = ?";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                pstmt.setInt(1, courseId);
                pstmt.setString(2, dayOfWeek.toString());
                pstmt.setTime(3, Time.valueOf(startTime));
                pstmt.setTime(4, Time.valueOf(endTime));
                pstmt.setInt(5, scheduleId);
                int affectedRows = pstmt.executeUpdate();
                if (affectedRows > 0) {
                    parentFrame.showSuccess("Class schedule updated successfully!");
                    loadClassSchedules();
                    clearScheduleForm();
                } else {
                    parentFrame.showError("Failed to update schedule. Schedule not found.");
                }
            } catch (SQLException e) {
                parentFrame.showError("Error updating schedule: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private void deleteSchedule() {
            int selectedRow = classScheduleTable.getSelectedRow();
            if (selectedRow == -1) {
                parentFrame.showError("Please select a schedule to delete.");
                return;
            }

            int confirm = parentFrame.showConfirmDialogCustom(this, "Are you sure you want to delete this class schedule?", "Confirm Deletion", JOptionPane.YES_NO_OPTION);
            if (confirm != JOptionPane.YES_OPTION) {
                return;
            }

            int modelRow = classScheduleTable.convertRowIndexToModel(selectedRow);
            int scheduleId = (int) classScheduleTableModel.getValueAt(modelRow, 0);

            try {
                String sql = "DELETE FROM class_schedules WHERE id = ?";
                try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                    pstmt.setInt(1, scheduleId);
                    int affectedRows = pstmt.executeUpdate();
                    if (affectedRows > 0) {
                        parentFrame.showSuccess("Class schedule deleted successfully!");
                        loadClassSchedules();
                        clearScheduleForm();
                    } else {
                        parentFrame.showError("Failed to delete schedule. Schedule not found.");
                    }
                }
            } catch (SQLException e) {
                parentFrame.showError("Error deleting schedule: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private void clearScheduleForm() {
            scheduleCourseComboBox.setSelectedItem("Select Course");
            scheduleDayOfWeekComboBox.setSelectedItem(DayOfWeek.MONDAY);
            scheduleStartTimeSpinner.setValue(new java.util.Date()); // Reset to current time
            scheduleEndTimeSpinner.setValue(new java.util.Date()); // Reset to current time
            classScheduleTable.clearSelection();
        }

        private void setupTeacherViewAnnouncementsTab() {
            JPanel announcementsPanel = new JPanel(new BorderLayout(10, 10));
            announcementsPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
            announcementsPanel.setBackground(UIUtils.BACKGROUND_COLOR);

            JLabel titleLabel = new JLabel("My Announcements", SwingConstants.CENTER);
            titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
            titleLabel.setForeground(UIUtils.ACCENT_COLOR);
            announcementsPanel.add(titleLabel, BorderLayout.NORTH);

            String[] columnNames = {"ID", "Subject", "Sender", "Sent At", "Read Status"};
            teacherAnnouncementsTableModel = new DefaultTableModel(columnNames, 0) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
            teacherAnnouncementsTable = new JTable(teacherAnnouncementsTableModel);
            UIUtils.styleTable(teacherAnnouncementsTable);

            teacherAnnouncementsTable.getSelectionModel().addListSelectionListener(e -> {
                if (!e.getValueIsAdjusting() && teacherAnnouncementsTable.getSelectedRow() != -1) {
                    displayAnnouncementMessage(teacherAnnouncementsTable.convertRowIndexToModel(teacherAnnouncementsTable.getSelectedRow()));
                }
            });

            JScrollPane tableScrollPane = new JScrollPane(teacherAnnouncementsTable);
            tableScrollPane.setBorder(UIUtils.createPanelBorder());
            announcementsPanel.add(tableScrollPane, BorderLayout.CENTER);

            JPanel bottomPanel = new JPanel(new BorderLayout(5, 5));
            bottomPanel.setBackground(UIUtils.PANEL_COLOR);
            bottomPanel.setBorder(UIUtils.createPanelBorder());

            teacherAnnouncementMessageArea = new JTextArea(5, 30);
            teacherAnnouncementMessageArea.setEditable(false);
            teacherAnnouncementMessageArea.setLineWrap(true);
            teacherAnnouncementMessageArea.setWrapStyleWord(true);
            JScrollPane messageScrollPane = new JScrollPane(teacherAnnouncementMessageArea);
            bottomPanel.add(messageScrollPane, BorderLayout.CENTER);

            markAnnouncementReadButton = new JButton("Mark as Read");
            UIUtils.applyButtonStyle(markAnnouncementReadButton);
            markAnnouncementReadButton.addActionListener(e -> markAnnouncementAsRead());
            JPanel buttonWrapper = new JPanel(new FlowLayout(FlowLayout.RIGHT));
            buttonWrapper.setBackground(UIUtils.PANEL_COLOR);
            buttonWrapper.add(markAnnouncementReadButton);
            bottomPanel.add(buttonWrapper, BorderLayout.SOUTH);

            announcementsPanel.add(bottomPanel, BorderLayout.SOUTH);

            sidebar.addMenuItem("View Announcements", announcementsPanel);
            loadTeacherAnnouncements();
        }

        private void loadTeacherAnnouncements() {
            teacherAnnouncementsTableModel.setRowCount(0);
            String sql = "SELECT a.id, a.subject, u.full_name as sender_name, a.sent_at, ua.is_read, a.message " +
                         "FROM announcements a " +
                         "JOIN user_announcements ua ON a.id = ua.announcement_id " +
                         "JOIN users u ON a.sender_user_id = u.id " +
                         "WHERE ua.recipient_user_id = ? " +
                         "ORDER BY a.sent_at DESC";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                pstmt.setInt(1, loggedInUser.getId());
                ResultSet rs = pstmt.executeQuery();
                while (rs.next()) {
                    Vector<Object> row = new Vector<>();
                    row.add(rs.getInt("id"));
                    row.add(rs.getString("subject"));
                    row.add(rs.getString("sender_name"));
                    row.add(rs.getTimestamp("sent_at"));
                    row.add(rs.getBoolean("is_read") ? "Read" : "Unread");
                    teacherAnnouncementsTableModel.addRow(row);
                }
            } catch (SQLException e) {
                parentFrame.showError("Error loading announcements: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private void displayAnnouncementMessage(int modelRowIndex) {
            int announcementId = (int) teacherAnnouncementsTableModel.getValueAt(modelRowIndex, 0);
            String message = "";
            String sql = "SELECT a.message FROM announcements a JOIN user_announcements ua ON a.id = ua.announcement_id WHERE a.id = ? AND ua.recipient_user_id = ?";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                pstmt.setInt(1, announcementId);
                pstmt.setInt(2, loggedInUser.getId());
                ResultSet rs = pstmt.executeQuery();
                if (rs.next()) {
                    message = rs.getString("message");
                }
            } catch (SQLException e) {
                parentFrame.showError("Error fetching announcement message: " + e.getMessage());
                e.printStackTrace();
            }
            teacherAnnouncementMessageArea.setText(message);

            // Enable/disable mark as read button
            String readStatus = (String) teacherAnnouncementsTableModel.getValueAt(modelRowIndex, 4);
            markAnnouncementReadButton.setEnabled(readStatus.equals("Unread"));
        }

        private void markAnnouncementAsRead() {
            int selectedRow = teacherAnnouncementsTable.getSelectedRow();
            if (selectedRow == -1) {
                parentFrame.showError("Please select an announcement to mark as read.");
                return;
            }

            int modelRow = teacherAnnouncementsTable.convertRowIndexToModel(selectedRow);
            int announcementId = (int) teacherAnnouncementsTableModel.getValueAt(modelRow, 0);

            String sql = "UPDATE user_announcements SET is_read = TRUE WHERE announcement_id = ? AND recipient_user_id = ?";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                pstmt.setInt(1, announcementId);
                pstmt.setInt(2, loggedInUser.getId());
                int affectedRows = pstmt.executeUpdate();
                if (affectedRows > 0) {
                    parentFrame.showSuccess("Announcement marked as read.");
                    loadTeacherAnnouncements(); // Refresh table
                    teacherAnnouncementMessageArea.setText(""); // Clear message area
                    markAnnouncementReadButton.setEnabled(false); // Disable button
                } else {
                    parentFrame.showError("Failed to mark announcement as read.");
                }
            } catch (SQLException e) {
                parentFrame.showError("Error marking announcement as read: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private void setupTeacherLeaveRequestsTab() {
            JPanel leavePanel = new JPanel(new BorderLayout(10, 10));
            leavePanel.setBorder(new EmptyBorder(10, 10, 10, 10));
            leavePanel.setBackground(UIUtils.BACKGROUND_COLOR);

            JLabel titleLabel = new JLabel("Student Leave Requests (My Courses)", SwingConstants.CENTER);
            titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
            titleLabel.setForeground(UIUtils.ACCENT_COLOR);
            leavePanel.add(titleLabel, BorderLayout.NORTH);

            String[] columnNames = {"Request ID", "Student Name", "Course", "Start Date", "End Date", "Reason", "Status", "Requested On"};
            teacherLeaveRequestsTableModel = new DefaultTableModel(columnNames, 0) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
            teacherLeaveRequestsTable = new JTable(teacherLeaveRequestsTableModel);
            UIUtils.styleTable(teacherLeaveRequestsTable);

            JScrollPane scrollPane = new JScrollPane(teacherLeaveRequestsTable);
            scrollPane.setBorder(UIUtils.createPanelBorder());
            leavePanel.add(scrollPane, BorderLayout.CENTER);

            JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
            teacherApproveLeaveButton = new JButton("Approve Leave");
            UIUtils.applyButtonStyle(teacherApproveLeaveButton);
            teacherApproveLeaveButton.addActionListener(e -> updateTeacherLeaveRequestStatus("approved"));
            buttonPanel.add(teacherApproveLeaveButton);

            teacherRejectLeaveButton = new JButton("Reject Leave");
            UIUtils.applyButtonStyle(teacherRejectLeaveButton);
            teacherRejectLeaveButton.setBackground(UIUtils.DANGER_COLOR);
            teacherRejectLeaveButton.addActionListener(e -> updateTeacherLeaveRequestStatus("rejected"));
            buttonPanel.add(teacherRejectLeaveButton);

            leavePanel.add(buttonPanel, BorderLayout.SOUTH);

            sidebar.addMenuItem("Leave Requests", leavePanel);
            loadTeacherLeaveRequests();
        }

        private void loadTeacherLeaveRequests() {
            teacherLeaveRequestsTableModel.setRowCount(0);
            // Select leave requests for students in courses taught by the logged-in teacher
            String sql = "SELECT lr.id, s.name as student_name, c.name as course_name, lr.start_date, lr.end_date, lr.reason, lr.status, lr.request_date " +
                         "FROM leave_requests lr " +
                         "JOIN students s ON lr.student_id = s.id " +
                         "LEFT JOIN courses c ON lr.course_id = c.id " + // LEFT JOIN as course_id can be NULL
                         "WHERE c.teacher_user_id = ? OR lr.course_id IS NULL " + // Include general leaves and leaves for teacher's courses
                         "ORDER BY lr.request_date DESC";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                pstmt.setInt(1, loggedInUser.getId());
                ResultSet rs = pstmt.executeQuery();
                while (rs.next()) {
                    Vector<Object> row = new Vector<>();
                    row.add(rs.getInt("id"));
                    row.add(rs.getString("student_name"));
                    row.add(rs.getString("course_name") != null ? rs.getString("course_name") : "General Leave");
                    row.add(rs.getDate("start_date"));
                    row.add(rs.getDate("end_date"));
                    row.add(rs.getString("reason"));
                    row.add(rs.getString("status"));
                    row.add(rs.getTimestamp("request_date"));
                    teacherLeaveRequestsTableModel.addRow(row);
                }
            } catch (SQLException e) {
                parentFrame.showError("Error loading teacher leave requests: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private void updateTeacherLeaveRequestStatus(String status) {
            int selectedRow = teacherLeaveRequestsTable.getSelectedRow();
            if (selectedRow == -1) {
                parentFrame.showError("Please select a leave request.");
                return;
            }

            int modelRow = teacherLeaveRequestsTable.convertRowIndexToModel(selectedRow);
            int requestId = (int) teacherLeaveRequestsTableModel.getValueAt(modelRow, 0);
            String currentStatus = (String) teacherLeaveRequestsTableModel.getValueAt(modelRow, 6);

            if (!currentStatus.equals("pending")) {
                parentFrame.showInfo("This request has already been " + currentStatus + ".");
                return;
            }

            int confirm = parentFrame.showConfirmDialogCustom(this, "Are you sure you want to " + status + " this leave request?", "Confirm Action", JOptionPane.YES_NO_OPTION);
            if (confirm != JOptionPane.YES_OPTION) {
                return;
            }

            try {
                String sql = "UPDATE leave_requests SET status = ?, approved_by_user_id = ?, approval_date = CURRENT_TIMESTAMP WHERE id = ?";
                try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                    pstmt.setString(1, status);
                    pstmt.setInt(2, loggedInUser.getId());
                    pstmt.setInt(3, requestId);
                    int affectedRows = pstmt.executeUpdate();
                    if (affectedRows > 0) {
                        parentFrame.showSuccess("Leave request " + status + " successfully!");
                        loadTeacherLeaveRequests();
                    } else {
                        parentFrame.showError("Failed to update leave request. Request not found.");
                    }
                }
            } catch (SQLException e) {
                parentFrame.showError("Error updating leave request: " + e.getMessage());
                e.printStackTrace();
            }
        }
    }


    // Student Dashboard
    // Student Dashboard
    class StudentDashboard extends JPanel {
        private OTPAttendanceSystem parentFrame;
        private CollapsibleSidebar sidebar;

        // Profile Tab
        private JLabel studentProfilePictureLabel;
        private String currentStudentProfilePicturePath;
        private JTextField studentProfileNameField, studentProfileRollField, studentProfileFatherNameField, studentProfileEmailField, studentProfilePhoneField;
        private JTextArea studentProfileAddressArea, studentProfileInterestsArea, studentProfileBioArea;
        private JButton uploadStudentPictureButton, viewStudentPictureButton, saveStudentProfileButton;

        // My Courses Tab
        private DefaultTableModel studentMyCoursesTableModel;
        private JTable studentMyCoursesTable;
        private JButton requestEnrollmentButton;

        // Mark Attendance Tab
        private JComboBox<String> studentMarkAttendanceCourseComboBox;
        private JTextField studentOtpInputField;
        private JLabel studentGeofenceStatusLabel;
        private JLabel studentLastMarkedTimeLabel;
        private JButton studentMarkAttendanceButton;

        // My Attendance Report Tab
        private DefaultTableModel studentAttendanceReportTableModel;
        private JTable studentAttendanceReportTable;
        private JTextField studentReportStartDateField, studentReportEndDateField;
        private JComboBox<String> studentReportCourseFilterComboBox;
        private JComboBox<String> studentReportStatusFilterComboBox;
        private JButton studentGenerateReportButton, studentExportReportButton;
        private JLabel studentOverallTotalClassesLabel, studentOverallPresentCountLabel, studentOverallAbsentCountLabel, studentOverallLeaveCountLabel, studentOverallAttendancePercentageLabel;
        private BarChartPanel studentOverallAttendanceChartPanel;

        // View Assignments Tab
        private DefaultTableModel studentAssignmentsTableModel;
        private JTable studentAssignmentsTable;
        private JComboBox<String> studentAssignmentCourseFilterComboBox;

        // View Grades Tab
        private DefaultTableModel studentGradesTableModel;
        private JTable studentGradesTable;
        private JComboBox<String> studentGradeCourseFilterComboBox;
        private JComboBox<String> studentGradeAssignmentFilterComboBox;

        // View Course Materials Tab
        private DefaultTableModel studentCourseMaterialsTableModel;
        private JTable studentCourseMaterialsTable;
        private JComboBox<String> studentMaterialCourseFilterComboBox;
        private JButton studentViewMaterialButton;

        // View Class Schedule Tab
        private DefaultTableModel studentClassScheduleTableModel;
        private JTable studentClassScheduleTable;
        private JComboBox<String> studentScheduleCourseFilterComboBox;

        // Submit Leave Request Tab
        private JComboBox<String> leaveRequestCourseComboBox;
        private JTextField leaveRequestStartDateField, leaveRequestEndDateField;
        private JTextArea leaveReasonArea;
        private JButton submitLeaveRequestButton;
        private DefaultTableModel myLeaveRequestsTableModel;
        private JTable myLeaveRequestsTable;

        // View Announcements Tab
        private DefaultTableModel studentAnnouncementsTableModel;
        private JTable studentAnnouncementsTable;
        private JTextArea studentAnnouncementMessageArea;
        private JButton studentMarkAnnouncementReadButton;

        // Submit Feedback Tab
        private JComboBox<String> feedbackCourseComboBox;
        private JSpinner feedbackRatingSpinner;
        private JTextArea feedbackCommentsArea;
        private JButton submitFeedbackButton;
        private DefaultTableModel myFeedbackTableModel;
        private JTable myFeedbackTable;


        public StudentDashboard(OTPAttendanceSystem parent) {
            this.parentFrame = parent;
            setLayout(new BorderLayout());
            setBackground(UIUtils.BACKGROUND_COLOR);

            String welcomeMsg = "Welcome, " + loggedInUser.getFullName() + " (Student)";
            sidebar = new CollapsibleSidebar(welcomeMsg, () -> parentFrame.showLoginPanel());
            add(sidebar, BorderLayout.CENTER);

            setupStudentProfileTab();
            setupStudentMyCoursesTab();
            setupStudentMarkAttendanceTab();
            setupStudentAttendanceReportTab();
            setupStudentViewAssignmentsTab();
            setupStudentViewGradesTab();
            setupStudentViewCourseMaterialsTab();
            setupStudentViewClassScheduleTab();
            setupStudentSubmitLeaveRequestTab();
            setupStudentViewAnnouncementsTab();
            setupStudentSubmitFeedbackTab();

            sidebar.selectMenuItem("My Profile");
        }

        private void setupStudentProfileTab() {
            JPanel profilePanel = new JPanel(new BorderLayout(10, 10));
            profilePanel.setBorder(new EmptyBorder(10, 10, 10, 10));
            profilePanel.setBackground(UIUtils.BACKGROUND_COLOR);

            // --- Form Panel ---
            JPanel formPanel = new JPanel(new GridBagLayout());
            formPanel.setBackground(UIUtils.PANEL_COLOR);
            formPanel.setBorder(UIUtils.createPanelBorder());
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.insets = new Insets(5, 5, 5, 5);
            gbc.fill = GridBagConstraints.HORIZONTAL;

            JLabel titleLabel = new JLabel("My Profile", SwingConstants.CENTER);
            titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
            titleLabel.setForeground(UIUtils.ACCENT_COLOR);
            gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 4;
            formPanel.add(titleLabel, gbc);

            gbc.gridwidth = 1;

            // Row 1: Name, Roll
            gbc.gridx = 0; gbc.gridy = 1; formPanel.add(new JLabel("Name:"), gbc);
            gbc.gridx = 1; studentProfileNameField = new JTextField(15); formPanel.add(studentProfileNameField, gbc);
            gbc.gridx = 2; formPanel.add(new JLabel("Roll No:"), gbc);
            gbc.gridx = 3; studentProfileRollField = new JTextField(15); studentProfileRollField.setEditable(false); formPanel.add(studentProfileRollField, gbc);

            // Row 2: Father Name, Email
            gbc.gridx = 0; gbc.gridy = 2; formPanel.add(new JLabel("Father Name:"), gbc);
            gbc.gridx = 1; studentProfileFatherNameField = new JTextField(15); formPanel.add(studentProfileFatherNameField, gbc);
            gbc.gridx = 2; formPanel.add(new JLabel("Email:"), gbc);
            gbc.gridx = 3; studentProfileEmailField = new JTextField(15); formPanel.add(studentProfileEmailField, gbc);

            // Row 3: Phone, Address
            gbc.gridx = 0; gbc.gridy = 3; formPanel.add(new JLabel("Phone:"), gbc);
            gbc.gridx = 1; studentProfilePhoneField = new JTextField(15); formPanel.add(studentProfilePhoneField, gbc);
            gbc.gridx = 2; formPanel.add(new JLabel("Address:"), gbc);
            gbc.gridx = 3; studentProfileAddressArea = new JTextArea(3, 15); studentProfileAddressArea.setLineWrap(true); studentProfileAddressArea.setWrapStyleWord(true);
            JScrollPane addressScrollPane = new JScrollPane(studentProfileAddressArea);
            formPanel.add(addressScrollPane, gbc);

            // Row 4: Interests, Bio
            gbc.gridx = 0; gbc.gridy = 4; formPanel.add(new JLabel("Interests:"), gbc);
            gbc.gridx = 1; studentProfileInterestsArea = new JTextArea(3, 15); studentProfileInterestsArea.setLineWrap(true); studentProfileInterestsArea.setWrapStyleWord(true);
            JScrollPane interestsScrollPane = new JScrollPane(studentProfileInterestsArea);
            formPanel.add(interestsScrollPane, gbc);
            gbc.gridx = 2; formPanel.add(new JLabel("Bio:"), gbc);
            gbc.gridx = 3; studentProfileBioArea = new JTextArea(3, 15); studentProfileBioArea.setLineWrap(true); studentProfileBioArea.setWrapStyleWord(true);
            JScrollPane bioScrollPane = new JScrollPane(studentProfileBioArea);
            formPanel.add(bioScrollPane, gbc);

            // Row 5: Profile Picture
            gbc.gridx = 0; gbc.gridy = 5; formPanel.add(new JLabel("Profile Picture:"), gbc);
            gbc.gridx = 1;
            JPanel picPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
            uploadStudentPictureButton = new JButton("Upload");
            UIUtils.applyButtonStyle(uploadStudentPictureButton);
            uploadStudentPictureButton.addActionListener(e -> uploadStudentProfilePictureStudent());
            picPanel.add(uploadStudentPictureButton);
            viewStudentPictureButton = new JButton("View");
            UIUtils.applyButtonStyle(viewStudentPictureButton);
            viewStudentPictureButton.addActionListener(e -> viewStudentProfilePictureStudent());
            picPanel.add(viewStudentPictureButton);
            formPanel.add(picPanel, gbc);

            // Profile Picture Display Label
            gbc.gridx = 0; gbc.gridy = 6; gbc.gridwidth = 4;
            studentProfilePictureLabel = new JLabel();
            studentProfilePictureLabel.setHorizontalAlignment(SwingConstants.CENTER);
            studentProfilePictureLabel.setPreferredSize(new Dimension(100, 100)); // Placeholder size
            studentProfilePictureLabel.setBorder(BorderFactory.createLineBorder(UIUtils.BORDER_COLOR));
            formPanel.add(studentProfilePictureLabel, gbc);
            gbc.gridwidth = 1; // Reset gridwidth

            // Row 6: Save Button
            JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
            saveStudentProfileButton = new JButton("Save Profile");
            UIUtils.applyButtonStyle(saveStudentProfileButton);
            saveStudentProfileButton.addActionListener(e -> saveStudentProfile());
            buttonPanel.add(saveStudentProfileButton);

            gbc.gridx = 0; gbc.gridy = 7; gbc.gridwidth = 4;
            formPanel.add(buttonPanel, gbc);

            profilePanel.add(formPanel, BorderLayout.NORTH);

            sidebar.addMenuItem("My Profile", profilePanel);
            loadStudentProfile();
        }

        private void loadStudentProfile() {
            String sql = "SELECT s.name, s.roll_no, s.father_name, s.email, s.phone_number, s.address, s.interests, s.bio, s.profile_picture_path " +
                         "FROM students s JOIN users u ON s.user_id = u.id WHERE u.id = ?";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                pstmt.setInt(1, loggedInUser.getId());
                ResultSet rs = pstmt.executeQuery();
                if (rs.next()) {
                    studentProfileNameField.setText(rs.getString("name"));
                    studentProfileRollField.setText(rs.getString("roll_no"));
                    studentProfileFatherNameField.setText(rs.getString("father_name"));
                    studentProfileEmailField.setText(rs.getString("email"));
                    studentProfilePhoneField.setText(rs.getString("phone_number"));
                    studentProfileAddressArea.setText(rs.getString("address"));
                    studentProfileInterestsArea.setText(rs.getString("interests"));
                    studentProfileBioArea.setText(rs.getString("bio"));
                    currentStudentProfilePicturePath = rs.getString("profile_picture_path");
                    if (currentStudentProfilePicturePath != null && !currentStudentProfilePicturePath.isEmpty()) {
                        try {
                            BufferedImage img = ImageIO.read(new File(currentStudentProfilePicturePath));
                            if (img != null) {
                                Image scaledImg = img.getScaledInstance(studentProfilePictureLabel.getWidth(), studentProfilePictureLabel.getHeight(), Image.SCALE_SMOOTH);
                                studentProfilePictureLabel.setIcon(new ImageIcon(scaledImg));
                            } else {
                                studentProfilePictureLabel.setIcon(null);
                                studentProfilePictureLabel.setText("No Image");
                            }
                        } catch (IOException e) {
                            studentProfilePictureLabel.setIcon(null);
                            studentProfilePictureLabel.setText("Error loading image");
                            e.printStackTrace();
                        }
                    } else {
                        studentProfilePictureLabel.setIcon(null);
                        studentProfilePictureLabel.setText("No Picture");
                    }
                }
            } catch (SQLException e) {
                parentFrame.showError("Error loading student profile: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private void saveStudentProfile() {
            String name = studentProfileNameField.getText().trim();
            String fatherName = studentProfileFatherNameField.getText().trim();
            String email = studentProfileEmailField.getText().trim();
            String phone = studentProfilePhoneField.getText().trim();
            String address = studentProfileAddressArea.getText().trim();
            String interests = studentProfileInterestsArea.getText().trim();
            String bio = studentProfileBioArea.getText().trim();

            if (name.isEmpty() || fatherName.isEmpty() || email.isEmpty()) {
                parentFrame.showError("Name, Father Name, and Email are required.");
                return;
            }
            if (!parentFrame.isValidEmail(email)) {
                parentFrame.showError("Invalid email format.");
                return;
            }

            String sql = "UPDATE students SET name = ?, father_name = ?, email = ?, phone_number = ?, address = ?, interests = ?, bio = ?, profile_picture_path = ? WHERE user_id = ?";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                pstmt.setString(1, name);
                pstmt.setString(2, fatherName);
                pstmt.setString(3, email);
                pstmt.setString(4, phone.isEmpty() ? null : phone);
                pstmt.setString(5, address.isEmpty() ? null : address);
                pstmt.setString(6, interests.isEmpty() ? null : interests);
                pstmt.setString(7, bio.isEmpty() ? null : bio);
                pstmt.setString(8, currentStudentProfilePicturePath);
                pstmt.setInt(9, loggedInUser.getId());
                int affectedRows = pstmt.executeUpdate();
                if (affectedRows > 0) {
                    parentFrame.showSuccess("Profile updated successfully!");
                    // Update loggedInUser's full name if it changed
                    loggedInUser = new User(loggedInUser.getId(), loggedInUser.getUsername(), loggedInUser.getRole(), name, loggedInUser.isActive());
                    sidebar.revalidate();
                    sidebar.repaint();
                } else {
                    parentFrame.showError("Failed to update profile.");
                }
            } catch (SQLException e) {
                parentFrame.showError("Error saving profile: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private void uploadStudentProfilePictureStudent() {
            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setDialogTitle("Select Profile Picture");
            fileChooser.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter("Image Files", "jpg", "jpeg", "png", "gif"));
            int userSelection = fileChooser.showOpenDialog(this);

            if (userSelection == JFileChooser.APPROVE_OPTION) {
                File sourceFile = fileChooser.getSelectedFile();
                try {
                    String fileName = System.currentTimeMillis() + "_" + sourceFile.getName();
                    File destinationFile = new File("student_images", fileName);
                    Files.copy(sourceFile.toPath(), destinationFile.toPath(), StandardCopyOption.REPLACE_EXISTING);

                    currentStudentProfilePicturePath = destinationFile.getAbsolutePath();
                    BufferedImage img = ImageIO.read(destinationFile);
                    if (img != null) {
                        Image scaledImg = img.getScaledInstance(studentProfilePictureLabel.getWidth(), studentProfilePictureLabel.getHeight(), Image.SCALE_SMOOTH);
                        studentProfilePictureLabel.setIcon(new ImageIcon(scaledImg));
                    }
                    parentFrame.showInfo("Profile picture uploaded successfully. Remember to click 'Save Profile' to save the path to the database.");
                } catch (IOException ex) {
                    parentFrame.showError("Error uploading image: " + ex.getMessage());
                    ex.printStackTrace();
                }
            }
        }

        private void viewStudentProfilePictureStudent() {
            if (currentStudentProfilePicturePath != null && !currentStudentProfilePicturePath.isEmpty()) {
                File imageFile = new File(currentStudentProfilePicturePath);
                if (imageFile.exists()) {
                    try {
                        Desktop.getDesktop().open(imageFile);
                    } catch (IOException e) {
                        parentFrame.showError("Could not open image file: " + e.getMessage());
                        e.printStackTrace();
                    }
                } else {
                    parentFrame.showError("Profile picture file not found at: " + currentStudentProfilePicturePath);
                }
            } else {
                parentFrame.showInfo("No profile picture selected or uploaded for this student.");
            }
        }

        private void setupStudentMyCoursesTab() {
            JPanel myCoursesPanel = new JPanel(new BorderLayout(10, 10));
            myCoursesPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
            myCoursesPanel.setBackground(UIUtils.BACKGROUND_COLOR);

            JLabel titleLabel = new JLabel("My Enrolled Courses", SwingConstants.CENTER);
            titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
            titleLabel.setForeground(UIUtils.ACCENT_COLOR);
            myCoursesPanel.add(titleLabel, BorderLayout.NORTH);

            String[] columnNames = {"Course ID", "Course Name", "Teacher", "Enrollment Date"};
            studentMyCoursesTableModel = new DefaultTableModel(columnNames, 0) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
            studentMyCoursesTable = new JTable(studentMyCoursesTableModel);
            UIUtils.styleTable(studentMyCoursesTable);

            JScrollPane scrollPane = new JScrollPane(studentMyCoursesTable);
            scrollPane.setBorder(UIUtils.createPanelBorder());
            myCoursesPanel.add(scrollPane, BorderLayout.CENTER);

            requestEnrollmentButton = new JButton("Request Enrollment in New Course");
            UIUtils.applyButtonStyle(requestEnrollmentButton);
            requestEnrollmentButton.addActionListener(e -> showEnrollmentRequestDialog());
            JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
            buttonPanel.add(requestEnrollmentButton);
            myCoursesPanel.add(buttonPanel, BorderLayout.SOUTH);

            sidebar.addMenuItem("My Courses", myCoursesPanel);
            loadStudentMyCourses();
        }

        private void loadStudentMyCourses() {
            studentMyCoursesTableModel.setRowCount(0);
            int studentId = getStudentIdByUserId(loggedInUser.getId());
            if (studentId == -1) {
                parentFrame.showError("Student ID not found for logged-in user.");
                return;
            }

            String sql = "SELECT sc.course_id, c.name as course_name, u.full_name as teacher_name, sc.enrollment_date " +
                         "FROM student_courses sc JOIN courses c ON sc.course_id = c.id " +
                         "LEFT JOIN users u ON c.teacher_user_id = u.id " +
                         "WHERE sc.student_id = ? ORDER BY c.name ASC";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                pstmt.setInt(1, studentId);
                ResultSet rs = pstmt.executeQuery();
                while (rs.next()) {
                    Vector<Object> row = new Vector<>();
                    row.add(rs.getInt("course_id"));
                    row.add(rs.getString("course_name"));
                    row.add(rs.getString("teacher_name") != null ? rs.getString("teacher_name") : "Unassigned");
                    row.add(rs.getTimestamp("enrollment_date"));
                    studentMyCoursesTableModel.addRow(row);
                }
            } catch (SQLException e) {
                parentFrame.showError("Error loading your courses: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private int getStudentIdByUserId(int userId) {
            int studentId = -1;
            String sql = "SELECT id FROM students WHERE user_id = ?";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                pstmt.setInt(1, userId);
                ResultSet rs = pstmt.executeQuery();
                if (rs.next()) {
                    studentId = rs.getInt("id");
                }
            } catch (SQLException e) {
                parentFrame.showError("Error retrieving student ID: " + e.getMessage());
                e.printStackTrace();
            }
            return studentId;
        }

        private void showEnrollmentRequestDialog() {
            JDialog dialog = new JDialog(parentFrame, "Request Enrollment", true);
            dialog.setLayout(new BorderLayout(10, 10));
            dialog.setBackground(UIUtils.PANEL_COLOR);
            dialog.setResizable(false);

            JPanel formPanel = new JPanel(new GridBagLayout());
            formPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.insets = new Insets(5, 5, 5, 5);
            gbc.fill = GridBagConstraints.HORIZONTAL;

            JLabel courseLabel = new JLabel("Select Course:");
            gbc.gridx = 0; gbc.gridy = 0; formPanel.add(courseLabel, gbc);

            JComboBox<String> availableCoursesComboBox = new JComboBox<>();
            loadAvailableCoursesForEnrollment(availableCoursesComboBox);
            gbc.gridx = 1; formPanel.add(availableCoursesComboBox, gbc);

            dialog.add(formPanel, BorderLayout.CENTER);

            JButton submitButton = new JButton("Submit Request");
            UIUtils.applyButtonStyle(submitButton);
            submitButton.addActionListener(e -> {
                int selectedCourseId = getCourseIdFromEnrollmentComboBox((String) availableCoursesComboBox.getSelectedItem());
                if (selectedCourseId == -1) {
                    parentFrame.showError("Please select a course.");
                    return;
                }
                submitEnrollmentRequest(selectedCourseId);
                dialog.dispose();
            });

            JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
            buttonPanel.add(submitButton);
            dialog.add(buttonPanel, BorderLayout.SOUTH);

            dialog.pack();
            dialog.setLocationRelativeTo(parentFrame);
            dialog.setVisible(true);
        }

        private void loadAvailableCoursesForEnrollment(JComboBox<String> comboBox) {
            comboBox.removeAllItems();
            comboBox.addItem("Select Course");
            int studentId = getStudentIdByUserId(loggedInUser.getId());
            if (studentId == -1) return;

            String sql = "SELECT id, name FROM courses WHERE id NOT IN (SELECT course_id FROM student_courses WHERE student_id = ?) ORDER BY name ASC";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                pstmt.setInt(1, studentId);
                ResultSet rs = pstmt.executeQuery();
                while (rs.next()) {
                    comboBox.addItem(rs.getString("name") + " (ID: " + rs.getInt("id") + ")");
                }
            } catch (SQLException e) {
                parentFrame.showError("Error loading available courses: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private int getCourseIdFromEnrollmentComboBox(String selectedItem) {
            if (selectedItem == null || selectedItem.equals("Select Course")) {
                return -1;
            }
            int startIndex = selectedItem.lastIndexOf("(ID: ") + 5;
            int endIndex = selectedItem.lastIndexOf(")");
            if (startIndex > 0 && endIndex > startIndex) {
                try {
                    return Integer.parseInt(selectedItem.substring(startIndex, endIndex));
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                    return -1;
                }
            }
            return -1;
        }

        private void submitEnrollmentRequest(int courseId) {
            int studentId = getStudentIdByUserId(loggedInUser.getId());
            if (studentId == -1) {
                parentFrame.showError("Student ID not found.");
                return;
            }

            String sql = "INSERT INTO course_enrollment_requests (student_id, course_id, status) VALUES (?, ?, 'pending')";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                pstmt.setInt(1, studentId);
                pstmt.setInt(2, courseId);
                pstmt.executeUpdate();
                parentFrame.showSuccess("Enrollment request submitted successfully! Awaiting approval.");
            } catch (SQLIntegrityConstraintViolationException e) {
                parentFrame.showError("You have already submitted an enrollment request for this course or are already enrolled.");
                e.printStackTrace();
            } catch (SQLException e) {
                parentFrame.showError("Error submitting enrollment request: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private void setupStudentMarkAttendanceTab() {
            JPanel markAttendancePanel = new JPanel(new GridBagLayout());
            markAttendancePanel.setBorder(new EmptyBorder(10, 10, 10, 10));
            markAttendancePanel.setBackground(UIUtils.BACKGROUND_COLOR);

            GridBagConstraints gbc = new GridBagConstraints();
            gbc.insets = new Insets(10, 10, 10, 10);
            gbc.fill = GridBagConstraints.HORIZONTAL;

            JLabel titleLabel = new JLabel("Mark My Attendance", SwingConstants.CENTER);
            titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
            titleLabel.setForeground(UIUtils.ACCENT_COLOR);
            gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
            markAttendancePanel.add(titleLabel, gbc);

            gbc.gridwidth = 1;

            gbc.gridx = 0; gbc.gridy = 1; markAttendancePanel.add(new JLabel("Select Course:"), gbc);
            gbc.gridx = 1; studentMarkAttendanceCourseComboBox = new JComboBox<>(); markAttendancePanel.add(studentMarkAttendanceCourseComboBox, gbc);

            gbc.gridx = 0; gbc.gridy = 2; markAttendancePanel.add(new JLabel("Enter OTP:"), gbc);
            gbc.gridx = 1; studentOtpInputField = new JTextField(10); markAttendancePanel.add(studentOtpInputField, gbc);

            gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 2;
            studentGeofenceStatusLabel = new JLabel("Geofence Status: Unknown", SwingConstants.CENTER);
            studentGeofenceStatusLabel.setFont(new Font("Arial", Font.ITALIC, 12));
            markAttendancePanel.add(studentGeofenceStatusLabel, gbc);

            gbc.gridx = 0; gbc.gridy = 4; gbc.gridwidth = 2;
            studentLastMarkedTimeLabel = new JLabel("Last Marked Attendance: N/A", SwingConstants.CENTER);
            studentLastMarkedTimeLabel.setFont(new Font("Arial", Font.ITALIC, 12));
            markAttendancePanel.add(studentLastMarkedTimeLabel, gbc);

            gbc.gridx = 0; gbc.gridy = 5; gbc.gridwidth = 2;
            studentMarkAttendanceButton = new JButton("Mark Attendance");
            UIUtils.applyButtonStyle(studentMarkAttendanceButton);
            studentMarkAttendanceButton.addActionListener(e -> studentMarkAttendance());
            markAttendancePanel.add(studentMarkAttendanceButton, gbc);

            sidebar.addMenuItem("Mark Attendance", markAttendancePanel);
            loadStudentCoursesForMarkAttendance();
            studentMarkAttendanceCourseComboBox.addItemListener(e -> {
                if (e.getStateChange() == ItemEvent.SELECTED) {
                    updateStudentGeofenceStatus();
                    updateStudentLastMarkedTime();
                }
            });
            updateStudentGeofenceStatus(); // Initial call
            updateStudentLastMarkedTime(); // Initial call
        }

        private void loadStudentCoursesForMarkAttendance() {
            studentMarkAttendanceCourseComboBox.removeAllItems();
            studentMarkAttendanceCourseComboBox.addItem("Select Course");
            int studentId = getStudentIdByUserId(loggedInUser.getId());
            if (studentId == -1) return;

            String sql = "SELECT c.id, c.name FROM courses c JOIN student_courses sc ON c.id = sc.course_id WHERE sc.student_id = ? ORDER BY c.name ASC";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                pstmt.setInt(1, studentId);
                ResultSet rs = pstmt.executeQuery();
                while (rs.next()) {
                    studentMarkAttendanceCourseComboBox.addItem(rs.getString("name") + " (ID: " + rs.getInt("id") + ")");
                }
            } catch (SQLException e) {
                parentFrame.showError("Error loading courses for attendance: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private int getCourseIdFromStudentAttendanceComboBox(String selectedItem) {
            if (selectedItem == null || selectedItem.equals("Select Course")) {
                return -1;
            }
            int startIndex = selectedItem.lastIndexOf("(ID: ") + 5;
            int endIndex = selectedItem.lastIndexOf(")");
            if (startIndex > 0 && endIndex > startIndex) {
                try {
                    return Integer.parseInt(selectedItem.substring(startIndex, endIndex));
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                    return -1;
                }
            }
            return -1;
        }

        private void updateStudentGeofenceStatus() {
            int courseId = getCourseIdFromStudentAttendanceComboBox((String) studentMarkAttendanceCourseComboBox.getSelectedItem());
            if (courseId == -1) {
                studentGeofenceStatusLabel.setText("Geofence Status: Select a course");
                return;
            }

            String sql = "SELECT expected_latitude, expected_longitude, geofence_radius_meters FROM courses WHERE id = ?";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                pstmt.setInt(1, courseId);
                ResultSet rs = pstmt.executeQuery();
                if (rs.next()) {
                    Double expectedLat = (Double) rs.getObject("expected_latitude");
                    Double expectedLon = (Double) rs.getObject("expected_longitude");
                    Integer radius = (Integer) rs.getObject("geofence_radius_meters");

                    if (expectedLat != null && expectedLon != null && radius != null) {
                        // Simulate current location for student (replace with actual GPS data)
                        double currentLat = 30.3753; // Example: Lahore
                        double currentLon = 69.3451; // Example: Lahore

                        double distance = calculateHaversineDistance(expectedLat, expectedLon, currentLat, currentLon);

                        if (distance <= radius) {
                            studentGeofenceStatusLabel.setText("Geofence Status: Inside (Distance: " + String.format("%.2f", distance) + "m)");
                            studentGeofenceStatusLabel.setForeground(UIUtils.SUCCESS_COLOR);
                        } else {
                            studentGeofenceStatusLabel.setText("Geofence Status: Outside (Distance: " + String.format("%.2f", distance) + "m, Radius: " + radius + "m)");
                            studentGeofenceStatusLabel.setForeground(UIUtils.DANGER_COLOR);
                        }
                    } else {
                        studentGeofenceStatusLabel.setText("Geofence Status: Not configured for this course.");
                        studentGeofenceStatusLabel.setForeground(UIUtils.WARNING_COLOR);
                    }
                } else {
                    studentGeofenceStatusLabel.setText("Geofence Status: Course not found.");
                    studentGeofenceStatusLabel.setForeground(UIUtils.DANGER_COLOR);
                }
            } catch (SQLException e) {
                parentFrame.showError("Error checking geofence: " + e.getMessage());
                e.printStackTrace();
                studentGeofenceStatusLabel.setText("Geofence Status: Error");
                studentGeofenceStatusLabel.setForeground(UIUtils.DANGER_COLOR);
            }
        }

        private void updateStudentLastMarkedTime() {
            int courseId = getCourseIdFromStudentAttendanceComboBox((String) studentMarkAttendanceCourseComboBox.getSelectedItem());
            int studentId = getStudentIdByUserId(loggedInUser.getId());
            if (courseId == -1 || studentId == -1) {
                studentLastMarkedTimeLabel.setText("Last Marked Attendance: N/A");
                return;
            }

            String sql = "SELECT last_marked_attendance_time FROM student_courses WHERE student_id = ? AND course_id = ?";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                pstmt.setInt(1, studentId);
                pstmt.setInt(2, courseId);
                ResultSet rs = pstmt.executeQuery();
                if (rs.next() && rs.getTimestamp("last_marked_attendance_time") != null) {
                    studentLastMarkedTimeLabel.setText("Last Marked Attendance: " + rs.getTimestamp("last_marked_attendance_time").toString());
                } else {
                    studentLastMarkedTimeLabel.setText("Last Marked Attendance: Never");
                }
            } catch (SQLException e) {
                parentFrame.showError("Error getting last marked time: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private void studentMarkAttendance() {
            String enteredOTP = studentOtpInputField.getText().trim();
            int courseId = getCourseIdFromStudentAttendanceComboBox((String) studentMarkAttendanceCourseComboBox.getSelectedItem());
            int studentId = getStudentIdByUserId(loggedInUser.getId());

            if (courseId == -1) {
                parentFrame.showError("Please select a course.");
                return;
            }
            if (enteredOTP.isEmpty()) {
                parentFrame.showError("Please enter the OTP.");
                return;
            }
            if (studentId == -1) {
                parentFrame.showError("Student ID not found for logged-in user.");
                return;
            }

            // Verify OTP (from parentFrame's currentOTP, which is set by Admin)
            if (parentFrame.currentOTP == null || System.currentTimeMillis() > parentFrame.otpExpiryTime || !enteredOTP.equals(parentFrame.currentOTP)) {
                parentFrame.showError("Invalid or expired OTP. Please get a new OTP from your teacher/admin.");
                return;
            }

            // Geofence check
            Double expectedLat = null;
            Double expectedLon = null;
            Integer radius = null;
            String courseName = "";

            String courseGeofenceSql = "SELECT name, expected_latitude, expected_longitude, geofence_radius_meters FROM courses WHERE id = ?";
            try (PreparedStatement pstmt = connection.prepareStatement(courseGeofenceSql)) {
                pstmt.setInt(1, courseId);
                ResultSet rs = pstmt.executeQuery();
                if (rs.next()) {
                    courseName = rs.getString("name");
                    expectedLat = (Double) rs.getObject("expected_latitude");
                    expectedLon = (Double) rs.getObject("expected_longitude");
                    radius = (Integer) rs.getObject("geofence_radius_meters");
                }
            } catch (SQLException e) {
                parentFrame.showError("Error fetching course geofence data: " + e.getMessage());
                e.printStackTrace();
                return;
            }

            boolean withinGeofence = false;
            if (expectedLat != null && expectedLon != null && radius != null) {
                // Simulate current location for student (replace with actual GPS data)
                double currentLat = 30.3753; // Example: Lahore
                double currentLon = 69.3451; // Example: Lahore
                double distance = calculateHaversineDistance(expectedLat, expectedLon, currentLat, currentLon);
                if (distance <= radius) {
                    withinGeofence = true;
                }
            } else {
                // If geofence not configured, assume it's not a requirement for this course
                withinGeofence = true;
                studentGeofenceStatusLabel.setText("Geofence Status: Not configured for this course. Attendance allowed.");
                studentGeofenceStatusLabel.setForeground(UIUtils.WARNING_COLOR);
            }

            if (!withinGeofence) {
                parentFrame.showError("You are outside the designated geofence for this course. Cannot mark attendance.");
                return;
            }

            // Mark attendance as Present
            String sql = "INSERT INTO attendance (student_id, course_id, date, status, marked_at, latitude, longitude) VALUES (?, ?, CURDATE(), ?, CURRENT_TIMESTAMP, ?, ?)";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                pstmt.setInt(1, studentId);
                pstmt.setInt(2, courseId);
                pstmt.setString(3, "Present");
                pstmt.setDouble(4, 30.3753); // Simulated Latitude
                pstmt.setDouble(5, 69.3451); // Simulated Longitude
                pstmt.executeUpdate();

                // Update last_marked_attendance_time in student_courses
                String updateLastMarkedSql = "UPDATE student_courses SET last_marked_attendance_time = CURRENT_TIMESTAMP WHERE student_id = ? AND course_id = ?";
                try (PreparedStatement updatePstmt = connection.prepareStatement(updateLastMarkedSql)) {
                    updatePstmt.setInt(1, studentId);
                    updatePstmt.setInt(2, courseId);
                    updatePstmt.executeUpdate();
                }

                parentFrame.showSuccess("Attendance marked as Present for " + courseName + "!");
                studentOtpInputField.setText(""); // Clear OTP field
                updateStudentLastMarkedTime(); // Refresh last marked time
            } catch (SQLIntegrityConstraintViolationException e) {
                parentFrame.showError("Attendance for " + courseName + " has already been marked today.");
                e.printStackTrace();
            } catch (SQLException e) {
                parentFrame.showError("Error marking attendance: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private double calculateHaversineDistance(double lat1, double lon1, double lat2, double lon2) {
            final int R = 6371000; // Earth radius in meters
            double latDistance = Math.toRadians(lat2 - lat1);
            double lonDistance = Math.toRadians(lon2 - lon1);
            double a = Math.sin(latDistance / 2) * Math.sin(latDistance / 2)
                    + Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2))
                    * Math.sin(lonDistance / 2) * Math.sin(lonDistance / 2);
            double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
            return R * c; // Distance in meters
        }

        private void setupStudentAttendanceReportTab() {
            JPanel reportPanel = new JPanel(new BorderLayout(10, 10));
            reportPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
            reportPanel.setBackground(UIUtils.BACKGROUND_COLOR);

            // --- Controls Panel ---
            JPanel controlsPanel = new JPanel(new GridBagLayout());
            controlsPanel.setBackground(UIUtils.PANEL_COLOR);
            controlsPanel.setBorder(UIUtils.createPanelBorder());
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.insets = new Insets(5, 5, 5, 5);
            gbc.fill = GridBagConstraints.HORIZONTAL;

            JLabel titleLabel = new JLabel("My Attendance Report", SwingConstants.CENTER);
            titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
            titleLabel.setForeground(UIUtils.ACCENT_COLOR);
            gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 4;
            controlsPanel.add(titleLabel, gbc);

            gbc.gridwidth = 1;

            // Row 1: Date Range
            gbc.gridx = 0; gbc.gridy = 1; controlsPanel.add(new JLabel("Start Date (YYYY-MM-DD):"), gbc);
            gbc.gridx = 1; studentReportStartDateField = new JTextField(10); controlsPanel.add(studentReportStartDateField, gbc);
            gbc.gridx = 2; controlsPanel.add(new JLabel("End Date (YYYY-MM-DD):"), gbc);
            gbc.gridx = 3; studentReportEndDateField = new JTextField(10); controlsPanel.add(studentReportEndDateField, gbc);

            // Row 2: Filters
            gbc.gridx = 0; gbc.gridy = 2; controlsPanel.add(new JLabel("Filter by Course:"), gbc);
            gbc.gridx = 1; studentReportCourseFilterComboBox = new JComboBox<>(); controlsPanel.add(studentReportCourseFilterComboBox, gbc);
            gbc.gridx = 2; controlsPanel.add(new JLabel("Filter by Status:"), gbc);
            gbc.gridx = 3; studentReportStatusFilterComboBox = new JComboBox<>(new String[]{"All", "Present", "Absent", "Leave"}); controlsPanel.add(studentReportStatusFilterComboBox, gbc);

            // Row 3: Buttons
            JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
            studentGenerateReportButton = new JButton("Generate Report");
            UIUtils.applyButtonStyle(studentGenerateReportButton);
            studentGenerateReportButton.addActionListener(e -> generateStudentAttendanceReport());
            buttonPanel.add(studentGenerateReportButton);

            studentExportReportButton = new JButton("Export to CSV");
            UIUtils.applyButtonStyle(studentExportReportButton);
            studentExportReportButton.addActionListener(e -> exportStudentAttendanceReportToCSV());
            buttonPanel.add(studentExportReportButton);

            gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 4;
            controlsPanel.add(buttonPanel, gbc);

            reportPanel.add(controlsPanel, BorderLayout.NORTH);

            // --- Overall Summary Panel ---
            JPanel overallSummaryPanel = new JPanel(new GridLayout(1, 2, 10, 10));
            overallSummaryPanel.setBorder(UIUtils.createPanelBorder());
            overallSummaryPanel.setBackground(UIUtils.PANEL_COLOR);

            JPanel statsPanel = new JPanel(new GridLayout(5, 1, 5, 5));
            statsPanel.setBackground(UIUtils.PANEL_COLOR);
            studentOverallTotalClassesLabel = new JLabel("Total Classes: 0");
            studentOverallPresentCountLabel = new JLabel("Present: 0");
            studentOverallAbsentCountLabel = new JLabel("Absent: 0");
            studentOverallLeaveCountLabel = new JLabel("Leave: 0");
            studentOverallAttendancePercentageLabel = new JLabel("Overall Attendance: 0.00%");
            statsPanel.add(studentOverallTotalClassesLabel);
            statsPanel.add(studentOverallPresentCountLabel);
            statsPanel.add(studentOverallAbsentCountLabel);
            statsPanel.add(studentOverallLeaveCountLabel);
            statsPanel.add(studentOverallAttendancePercentageLabel);
            overallSummaryPanel.add(statsPanel);

            studentOverallAttendanceChartPanel = new BarChartPanel();
            overallSummaryPanel.add(studentOverallAttendanceChartPanel);

            reportPanel.add(overallSummaryPanel, BorderLayout.SOUTH);

            // --- Table Panel ---
            String[] attendanceReportColumnNames = {"Course", "Date", "Status", "Marked At"};
            studentAttendanceReportTableModel = new DefaultTableModel(attendanceReportColumnNames, 0) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
            studentAttendanceReportTable = new JTable(studentAttendanceReportTableModel);
            UIUtils.styleTable(studentAttendanceReportTable);

            JScrollPane attendanceTableScrollPane = new JScrollPane(studentAttendanceReportTable);
            attendanceTableScrollPane.setBorder(UIUtils.createPanelBorder());
            reportPanel.add(attendanceTableScrollPane, BorderLayout.CENTER);

            sidebar.addMenuItem("Attendance Report", reportPanel);
            loadStudentCoursesForReportComboBox();
            studentReportEndDateField.setText(LocalDate.now().toString());
            studentReportStartDateField.setText(LocalDate.now().minusDays(30).toString());
            generateStudentAttendanceReport(); // Initial load
        }

        private void loadStudentCoursesForReportComboBox() {
            studentReportCourseFilterComboBox.removeAllItems();
            studentReportCourseFilterComboBox.addItem("All My Courses");
            int studentId = getStudentIdByUserId(loggedInUser.getId());
            if (studentId == -1) return;

            String sql = "SELECT c.id, c.name FROM courses c JOIN student_courses sc ON c.id = sc.course_id WHERE sc.student_id = ? ORDER BY c.name ASC";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                pstmt.setInt(1, studentId);
                ResultSet rs = pstmt.executeQuery();
                while (rs.next()) {
                    studentReportCourseFilterComboBox.addItem(rs.getString("name") + " (ID: " + rs.getInt("id") + ")");
                }
            } catch (SQLException e) {
                parentFrame.showError("Error loading courses for report filter: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private int getCourseIdFromStudentReportComboBox(String selectedItem) {
            if (selectedItem == null || selectedItem.equals("All My Courses")) {
                return -1;
            }
            int startIndex = selectedItem.lastIndexOf("(ID: ") + 5;
            int endIndex = selectedItem.lastIndexOf(")");
            if (startIndex > 0 && endIndex > startIndex) {
                try {
                    return Integer.parseInt(selectedItem.substring(startIndex, endIndex));
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                    return -1;
                }
            }
            return -1;
        }

        private void generateStudentAttendanceReport() {
            studentAttendanceReportTableModel.setRowCount(0);
            LocalDate startDate;
            LocalDate endDate;
            try {
                startDate = LocalDate.parse(studentReportStartDateField.getText());
                endDate = LocalDate.parse(studentReportEndDateField.getText());
                if (startDate.isAfter(endDate)) {
                    parentFrame.showError("Start date cannot be after end date.");
                    return;
                }
            } catch (DateTimeParseException e) {
                parentFrame.showError("Invalid date format. Please use YYYY-MM-DD.");
                return;
            }

            int studentId = getStudentIdByUserId(loggedInUser.getId());
            if (studentId == -1) {
                parentFrame.showError("Student ID not found for logged-in user.");
                return;
            }

            int courseFilterId = getCourseIdFromStudentReportComboBox((String) studentReportCourseFilterComboBox.getSelectedItem());
            String statusFilter = (String) studentReportStatusFilterComboBox.getSelectedItem();

            StringBuilder sqlBuilder = new StringBuilder();
            sqlBuilder.append("SELECT c.name as course_name, a.date, a.status, a.marked_at ");
            sqlBuilder.append("FROM attendance a ");
            sqlBuilder.append("JOIN courses c ON a.course_id = c.id ");
            sqlBuilder.append("WHERE a.student_id = ? AND a.date BETWEEN ? AND ?");

            List<Object> params = new ArrayList<>();
            params.add(studentId);
            params.add(Date.valueOf(startDate));
            params.add(Date.valueOf(endDate));

            if (courseFilterId != -1) {
                sqlBuilder.append(" AND c.id = ?");
                params.add(courseFilterId);
            }
            if (!statusFilter.equals("All")) {
                sqlBuilder.append(" AND a.status = ?");
                params.add(statusFilter);
            }

            sqlBuilder.append(" ORDER BY a.date DESC, c.name ASC");

            int totalPresent = 0;
            int totalAbsent = 0;
            int totalLeave = 0;
            int totalRecords = 0;

            try (PreparedStatement pstmt = connection.prepareStatement(sqlBuilder.toString())) {
                for (int i = 0; i < params.size(); i++) {
                    pstmt.setObject(i + 1, params.get(i));
                }

                ResultSet rs = pstmt.executeQuery();
                while (rs.next()) {
                    Vector<Object> row = new Vector<>();
                    row.add(rs.getString("course_name"));
                    row.add(rs.getDate("date"));
                    String status = rs.getString("status");
                    row.add(status);
                    row.add(rs.getTimestamp("marked_at"));
                    studentAttendanceReportTableModel.addRow(row);

                    totalRecords++;
                    if ("Present".equals(status)) {
                        totalPresent++;
                    } else if ("Absent".equals(status)) {
                        totalAbsent++;
                    } else if ("Leave".equals(status)) {
                        totalLeave++;
                    }
                }

                studentOverallTotalClassesLabel.setText("Total Records: " + totalRecords);
                studentOverallPresentCountLabel.setText("Present: " + totalPresent);
                studentOverallAbsentCountLabel.setText("Absent: " + totalAbsent);
                studentOverallLeaveCountLabel.setText("Leave: " + totalLeave);

                double overallPercentage = (totalRecords > 0) ? ((double) totalPresent / totalRecords) * 100 : 0.0;
                studentOverallAttendancePercentageLabel.setText("Overall Attendance: " + new DecimalFormat("0.00").format(overallPercentage) + "%");

                studentOverallAttendanceChartPanel.updateChartData(totalPresent, totalAbsent, totalLeave);

            } catch (SQLException e) {
                parentFrame.showError("Error generating student attendance report: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private void exportStudentAttendanceReportToCSV() {
            if (studentAttendanceReportTableModel.getRowCount() == 0) {
                parentFrame.showInfo("No data to export.");
                return;
            }

            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setDialogTitle("Export My Attendance Report to CSV");
            fileChooser.setSelectedFile(new File("my_attendance_report.csv"));
            int userSelection = fileChooser.showSaveDialog(this);

            if (userSelection == JFileChooser.APPROVE_OPTION) {
                File fileToSave = fileChooser.getSelectedFile();
                if (!fileToSave.getName().toLowerCase().endsWith(".csv")) {
                    fileToSave = new File(fileToSave.getAbsolutePath() + ".csv");
                }

                try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileToSave))) {
                    // Write header
                    for (int i = 0; i < studentAttendanceReportTableModel.getColumnCount(); i++) {
                        writer.write(studentAttendanceReportTableModel.getColumnName(i));
                        if (i < studentAttendanceReportTableModel.getColumnCount() - 1) {
                            writer.write(",");
                        }
                    }
                    writer.newLine();

                    // Write data rows
                    for (int i = 0; i < studentAttendanceReportTableModel.getRowCount(); i++) {
                        for (int j = 0; j < studentAttendanceReportTableModel.getColumnCount(); j++) {
                            Object value = studentAttendanceReportTableModel.getValueAt(i, j);
                            writer.write(value != null ? escapeCSV(value.toString()) : "");
                            if (j < studentAttendanceReportTableModel.getColumnCount() - 1) {
                                writer.write(",");
                            }
                        }
                        writer.newLine();
                    }
                    parentFrame.showSuccess("My attendance report exported to: " + fileToSave.getAbsolutePath());
                } catch (IOException e) {
                    parentFrame.showError("Error exporting CSV: " + e.getMessage());
                    e.printStackTrace();
                }
            }
        }

        private String escapeCSV(String value) {
            if (value.contains(",") || value.contains("\"") || value.contains("\n")) {
                return "\"" + value.replace("\"", "\"\"") + "\"";
            }
            return value;
        }

        private void setupStudentViewAssignmentsTab() {
            JPanel assignmentsPanel = new JPanel(new BorderLayout(10, 10));
            assignmentsPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
            assignmentsPanel.setBackground(UIUtils.BACKGROUND_COLOR);

            // --- Controls Panel ---
            JPanel controlsPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
            controlsPanel.setBackground(UIUtils.PANEL_COLOR);
            controlsPanel.setBorder(UIUtils.createPanelBorder());

            JLabel titleLabel = new JLabel("My Assignments", SwingConstants.CENTER);
            titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
            titleLabel.setForeground(UIUtils.ACCENT_COLOR);
            JPanel titleWrapper = new JPanel(new BorderLayout());
            titleWrapper.setBackground(UIUtils.PANEL_COLOR);
            titleWrapper.add(titleLabel, BorderLayout.CENTER);
            assignmentsPanel.add(titleWrapper, BorderLayout.NORTH);

            controlsPanel.add(new JLabel("Filter by Course:"));
            studentAssignmentCourseFilterComboBox = new JComboBox<>();
            studentAssignmentCourseFilterComboBox.addItemListener(e -> {
                if (e.getStateChange() == ItemEvent.SELECTED) {
                    loadStudentAssignments();
                }
            });
            controlsPanel.add(studentAssignmentCourseFilterComboBox);
            assignmentsPanel.add(controlsPanel, BorderLayout.SOUTH);

            // --- Table Panel ---
            String[] assignmentColumnNames = {"ID", "Course", "Title", "Description", "Due Date"};
            studentAssignmentsTableModel = new DefaultTableModel(assignmentColumnNames, 0) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
            studentAssignmentsTable = new JTable(studentAssignmentsTableModel);
            UIUtils.styleTable(studentAssignmentsTable);

            JScrollPane assignmentsTableScrollPane = new JScrollPane(studentAssignmentsTable);
            assignmentsTableScrollPane.setBorder(UIUtils.createPanelBorder());
            assignmentsPanel.add(assignmentsTableScrollPane, BorderLayout.CENTER);

            sidebar.addMenuItem("Assignments", assignmentsPanel);
            loadStudentCoursesForAssignmentFilter();
            loadStudentAssignments(); // Initial load
        }

        private void loadStudentCoursesForAssignmentFilter() {
            studentAssignmentCourseFilterComboBox.removeAllItems();
            studentAssignmentCourseFilterComboBox.addItem("All My Courses");
            int studentId = getStudentIdByUserId(loggedInUser.getId());
            if (studentId == -1) return;

            String sql = "SELECT c.id, c.name FROM courses c JOIN student_courses sc ON c.id = sc.course_id WHERE sc.student_id = ? ORDER BY c.name ASC";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                pstmt.setInt(1, studentId);
                ResultSet rs = pstmt.executeQuery();
                while (rs.next()) {
                    studentAssignmentCourseFilterComboBox.addItem(rs.getString("name") + " (ID: " + rs.getInt("id") + ")");
                }
            } catch (SQLException e) {
                parentFrame.showError("Error loading courses for assignment filter: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private int getCourseIdFromStudentAssignmentFilter(String selectedItem) {
            if (selectedItem == null || selectedItem.equals("All My Courses")) {
                return -1;
            }
            int startIndex = selectedItem.lastIndexOf("(ID: ") + 5;
            int endIndex = selectedItem.lastIndexOf(")");
            if (startIndex > 0 && endIndex > startIndex) {
                try {
                    return Integer.parseInt(selectedItem.substring(startIndex, endIndex));
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                    return -1;
                }
            }
            return -1;
        }

        private void loadStudentAssignments() {
            studentAssignmentsTableModel.setRowCount(0);
            int studentId = getStudentIdByUserId(loggedInUser.getId());
            if (studentId == -1) return;

            int courseFilterId = getCourseIdFromStudentAssignmentFilter((String) studentAssignmentCourseFilterComboBox.getSelectedItem());

            StringBuilder sqlBuilder = new StringBuilder();
            sqlBuilder.append("SELECT a.id, c.name as course_name, a.title, a.description, a.due_date ");
            sqlBuilder.append("FROM assignments a JOIN courses c ON a.course_id = c.id ");
            sqlBuilder.append("JOIN student_courses sc ON c.id = sc.course_id ");
            sqlBuilder.append("WHERE sc.student_id = ?");

            List<Object> params = new ArrayList<>();
            params.add(studentId);

            if (courseFilterId != -1) {
                sqlBuilder.append(" AND c.id = ?");
                params.add(courseFilterId);
            }

            sqlBuilder.append(" ORDER BY a.due_date ASC");

            try (PreparedStatement pstmt = connection.prepareStatement(sqlBuilder.toString())) {
                for (int i = 0; i < params.size(); i++) {
                    pstmt.setObject(i + 1, params.get(i));
                }

                ResultSet rs = pstmt.executeQuery();
                while (rs.next()) {
                    Vector<Object> row = new Vector<>();
                    row.add(rs.getInt("id"));
                    row.add(rs.getString("course_name"));
                    row.add(rs.getString("title"));
                    row.add(rs.getString("description"));
                    row.add(rs.getDate("due_date"));
                    studentAssignmentsTableModel.addRow(row);
                }
            } catch (SQLException e) {
                parentFrame.showError("Error loading student assignments: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private void setupStudentViewGradesTab() {
            JPanel gradesPanel = new JPanel(new BorderLayout(10, 10));
            gradesPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
            gradesPanel.setBackground(UIUtils.BACKGROUND_COLOR);

            // --- Controls Panel ---
            JPanel controlsPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
            controlsPanel.setBackground(UIUtils.PANEL_COLOR);
            controlsPanel.setBorder(UIUtils.createPanelBorder());

            JLabel titleLabel = new JLabel("My Grades", SwingConstants.CENTER);
            titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
            titleLabel.setForeground(UIUtils.ACCENT_COLOR);
            JPanel titleWrapper = new JPanel(new BorderLayout());
            titleWrapper.setBackground(UIUtils.PANEL_COLOR);
            titleWrapper.add(titleLabel, BorderLayout.CENTER);
            gradesPanel.add(titleWrapper, BorderLayout.NORTH);

            controlsPanel.add(new JLabel("Filter by Course:"));
            studentGradeCourseFilterComboBox = new JComboBox<>();
            studentGradeCourseFilterComboBox.addItemListener(e -> {
                if (e.getStateChange() == ItemEvent.SELECTED) {
                    loadStudentAssignmentsForGradeFilter(getCourseIdFromStudentGradeCourseFilter((String) studentGradeCourseFilterComboBox.getSelectedItem()));
                    loadStudentGrades();
                }
            });
            controlsPanel.add(studentGradeCourseFilterComboBox);

            controlsPanel.add(new JLabel("Filter by Assignment:"));
            studentGradeAssignmentFilterComboBox = new JComboBox<>();
            studentGradeAssignmentFilterComboBox.addItemListener(e -> {
                if (e.getStateChange() == ItemEvent.SELECTED) {
                    loadStudentGrades();
                }
            });
            controlsPanel.add(studentGradeAssignmentFilterComboBox);
            gradesPanel.add(controlsPanel, BorderLayout.SOUTH);

            // --- Table Panel ---
            String[] gradeColumnNames = {"ID", "Course", "Assignment", "Grade", "Feedback", "Graded At"};
            studentGradesTableModel = new DefaultTableModel(gradeColumnNames, 0) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
            studentGradesTable = new JTable(studentGradesTableModel);
            UIUtils.styleTable(studentGradesTable);

            JScrollPane gradesTableScrollPane = new JScrollPane(studentGradesTable);
            gradesTableScrollPane.setBorder(UIUtils.createPanelBorder());
            gradesPanel.add(gradesTableScrollPane, BorderLayout.CENTER);

            sidebar.addMenuItem("Grades", gradesPanel);
            loadStudentCoursesForGradeFilter();
            loadStudentGrades(); // Initial load
        }

        private void loadStudentCoursesForGradeFilter() {
            studentGradeCourseFilterComboBox.removeAllItems();
            studentGradeCourseFilterComboBox.addItem("All My Courses");
            int studentId = getStudentIdByUserId(loggedInUser.getId());
            if (studentId == -1) return;

            String sql = "SELECT c.id, c.name FROM courses c JOIN student_courses sc ON c.id = sc.course_id WHERE sc.student_id = ? ORDER BY c.name ASC";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                pstmt.setInt(1, studentId);
                ResultSet rs = pstmt.executeQuery();
                while (rs.next()) {
                    studentGradeCourseFilterComboBox.addItem(rs.getString("name") + " (ID: " + rs.getInt("id") + ")");
                }
            } catch (SQLException e) {
                parentFrame.showError("Error loading courses for grade filter: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private int getCourseIdFromStudentGradeCourseFilter(String selectedItem) {
            if (selectedItem == null || selectedItem.equals("All My Courses")) {
                return -1;
            }
            int startIndex = selectedItem.lastIndexOf("(ID: ") + 5;
            int endIndex = selectedItem.lastIndexOf(")");
            if (startIndex > 0 && endIndex > startIndex) {
                try {
                    return Integer.parseInt(selectedItem.substring(startIndex, endIndex));
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                    return -1;
                }
            }
            return -1;
        }

        private void loadStudentAssignmentsForGradeFilter(int courseId) {
            studentGradeAssignmentFilterComboBox.removeAllItems();
            studentGradeAssignmentFilterComboBox.addItem("All Assignments");
            if (courseId == -1) return;

            String sql = "SELECT id, title FROM assignments WHERE course_id = ? ORDER BY title ASC";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                pstmt.setInt(1, courseId);
                ResultSet rs = pstmt.executeQuery();
                while (rs.next()) {
                    studentGradeAssignmentFilterComboBox.addItem(rs.getString("title") + " (ID: " + rs.getInt("id") + ")");
                }
            } catch (SQLException e) {
                parentFrame.showError("Error loading assignments for grade filter: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private int getAssignmentIdFromStudentGradeAssignmentFilter(String selectedItem) {
            if (selectedItem == null || selectedItem.equals("All Assignments")) {
                return -1;
            }
            int startIndex = selectedItem.lastIndexOf("(ID: ") + 5;
            int endIndex = selectedItem.lastIndexOf(")");
            if (startIndex > 0 && endIndex > startIndex) {
                try {
                    return Integer.parseInt(selectedItem.substring(startIndex, endIndex));
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                    return -1;
                }
            }
            return -1;
        }

        private void loadStudentGrades() {
            studentGradesTableModel.setRowCount(0);
            int studentId = getStudentIdByUserId(loggedInUser.getId());
            if (studentId == -1) return;

            int courseFilterId = getCourseIdFromStudentGradeCourseFilter((String) studentGradeCourseFilterComboBox.getSelectedItem());
            int assignmentFilterId = getAssignmentIdFromStudentGradeAssignmentFilter((String) studentGradeAssignmentFilterComboBox.getSelectedItem());

            StringBuilder sqlBuilder = new StringBuilder();
            sqlBuilder.append("SELECT g.id, c.name as course_name, a.title as assignment_title, g.grade, g.feedback, g.graded_at ");
            sqlBuilder.append("FROM grades g JOIN assignments a ON g.assignment_id = a.id ");
            sqlBuilder.append("JOIN courses c ON a.course_id = c.id ");
            sqlBuilder.append("WHERE g.student_id = ?");

            List<Object> params = new ArrayList<>();
            params.add(studentId);

            if (courseFilterId != -1) {
                sqlBuilder.append(" AND c.id = ?");
                params.add(courseFilterId);
            }
            if (assignmentFilterId != -1) {
                sqlBuilder.append(" AND a.id = ?");
                params.add(assignmentFilterId);
            }

            sqlBuilder.append(" ORDER BY g.graded_at DESC");

            try (PreparedStatement pstmt = connection.prepareStatement(sqlBuilder.toString())) {
                for (int i = 0; i < params.size(); i++) {
                    pstmt.setObject(i + 1, params.get(i));
                }

                ResultSet rs = pstmt.executeQuery();
                while (rs.next()) {
                    Vector<Object> row = new Vector<>();
                    row.add(rs.getInt("id"));
                    row.add(rs.getString("course_name"));
                    row.add(rs.getString("assignment_title"));
                    row.add(rs.getBigDecimal("grade"));
                    row.add(rs.getString("feedback"));
                    row.add(rs.getTimestamp("graded_at"));
                    studentGradesTableModel.addRow(row);
                }
            } catch (SQLException e) {
                parentFrame.showError("Error loading student grades: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private void setupStudentViewCourseMaterialsTab() {
            JPanel materialsPanel = new JPanel(new BorderLayout(10, 10));
            materialsPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
            materialsPanel.setBackground(UIUtils.BACKGROUND_COLOR);

            // --- Controls Panel ---
            JPanel controlsPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
            controlsPanel.setBackground(UIUtils.PANEL_COLOR);
            controlsPanel.setBorder(UIUtils.createPanelBorder());

            JLabel titleLabel = new JLabel("Course Materials", SwingConstants.CENTER);
            titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
            titleLabel.setForeground(UIUtils.ACCENT_COLOR);
            JPanel titleWrapper = new JPanel(new BorderLayout());
            titleWrapper.setBackground(UIUtils.PANEL_COLOR);
            titleWrapper.add(titleLabel, BorderLayout.CENTER);
            materialsPanel.add(titleWrapper, BorderLayout.NORTH);

            controlsPanel.add(new JLabel("Filter by Course:"));
            studentMaterialCourseFilterComboBox = new JComboBox<>();
            studentMaterialCourseFilterComboBox.addItemListener(e -> {
                if (e.getStateChange() == ItemEvent.SELECTED) {
                    loadStudentCourseMaterials();
                }
            });
            controlsPanel.add(studentMaterialCourseFilterComboBox);

            studentViewMaterialButton = new JButton("View Selected Material");
            UIUtils.applyButtonStyle(studentViewMaterialButton);
            studentViewMaterialButton.addActionListener(e -> studentViewCourseMaterial());
            controlsPanel.add(studentViewMaterialButton);
            materialsPanel.add(controlsPanel, BorderLayout.SOUTH);

            // --- Table Panel ---
            String[] materialColumnNames = {"ID", "Course", "Title", "File Path/Link", "Upload Date"};
            studentCourseMaterialsTableModel = new DefaultTableModel(materialColumnNames, 0) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
            studentCourseMaterialsTable = new JTable(studentCourseMaterialsTableModel);
            UIUtils.styleTable(studentCourseMaterialsTable);

            JScrollPane materialsTableScrollPane = new JScrollPane(studentCourseMaterialsTable);
            materialsTableScrollPane.setBorder(UIUtils.createPanelBorder());
            materialsPanel.add(materialsTableScrollPane, BorderLayout.CENTER);

            sidebar.addMenuItem("Course Materials", materialsPanel);
            loadStudentCoursesForMaterialFilter();
            loadStudentCourseMaterials(); // Initial load
        }

        private void loadStudentCoursesForMaterialFilter() {
            studentMaterialCourseFilterComboBox.removeAllItems();
            studentMaterialCourseFilterComboBox.addItem("All My Courses");
            int studentId = getStudentIdByUserId(loggedInUser.getId());
            if (studentId == -1) return;

            String sql = "SELECT c.id, c.name FROM courses c JOIN student_courses sc ON c.id = sc.course_id WHERE sc.student_id = ? ORDER BY c.name ASC";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                pstmt.setInt(1, studentId);
                ResultSet rs = pstmt.executeQuery();
                while (rs.next()) {
                    studentMaterialCourseFilterComboBox.addItem(rs.getString("name") + " (ID: " + rs.getInt("id") + ")");
                }
            } catch (SQLException e) {
                parentFrame.showError("Error loading courses for material filter: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private int getCourseIdFromStudentMaterialFilter(String selectedItem) {
            if (selectedItem == null || selectedItem.equals("All My Courses")) {
                return -1;
            }
            int startIndex = selectedItem.lastIndexOf("(ID: ") + 5;
            int endIndex = selectedItem.lastIndexOf(")");
            if (startIndex > 0 && endIndex > startIndex) {
                try {
                    return Integer.parseInt(selectedItem.substring(startIndex, endIndex));
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                    return -1;
                }
            }
            return -1;
        }

        private void loadStudentCourseMaterials() {
            studentCourseMaterialsTableModel.setRowCount(0);
            int studentId = getStudentIdByUserId(loggedInUser.getId());
            if (studentId == -1) return;

            int courseFilterId = getCourseIdFromStudentMaterialFilter((String) studentMaterialCourseFilterComboBox.getSelectedItem());

            StringBuilder sqlBuilder = new StringBuilder();
            sqlBuilder.append("SELECT cm.id, c.name as course_name, cm.title, cm.file_path, cm.upload_date ");
            sqlBuilder.append("FROM course_materials cm JOIN courses c ON cm.course_id = c.id ");
            sqlBuilder.append("JOIN student_courses sc ON c.id = sc.course_id ");
            sqlBuilder.append("WHERE sc.student_id = ?");

            List<Object> params = new ArrayList<>();
            params.add(studentId);

            if (courseFilterId != -1) {
                sqlBuilder.append(" AND c.id = ?");
                params.add(courseFilterId);
            }

            sqlBuilder.append(" ORDER BY cm.upload_date DESC");

            try (PreparedStatement pstmt = connection.prepareStatement(sqlBuilder.toString())) {
                for (int i = 0; i < params.size(); i++) {
                    pstmt.setObject(i + 1, params.get(i));
                }

                ResultSet rs = pstmt.executeQuery();
                while (rs.next()) {
                    Vector<Object> row = new Vector<>();
                    row.add(rs.getInt("id"));
                    row.add(rs.getString("course_name"));
                    row.add(rs.getString("title"));
                    row.add(rs.getString("file_path"));
                    row.add(rs.getTimestamp("upload_date"));
                    studentCourseMaterialsTableModel.addRow(row);
                }
            } catch (SQLException e) {
                parentFrame.showError("Error loading student course materials: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private void studentViewCourseMaterial() {
            int selectedRow = studentCourseMaterialsTable.getSelectedRow();
            if (selectedRow == -1) {
                parentFrame.showError("Please select a course material to view.");
                return;
            }

            int modelRow = studentCourseMaterialsTable.convertRowIndexToModel(selectedRow);
            String filePath = (String) studentCourseMaterialsTableModel.getValueAt(modelRow, 3);

            if (filePath == null || filePath.isEmpty()) {
                parentFrame.showInfo("No file path or link available for this material.");
                return;
            }

            try {
                if (filePath.startsWith("http://") || filePath.startsWith("https://") || filePath.startsWith("ftp://")) {
                    Desktop.getDesktop().browse(new URI(filePath));
                } else {
                    File fileToOpen = new File(filePath);
                    if (fileToOpen.exists() && fileToOpen.isFile()) {
                        Desktop.getDesktop().open(fileToOpen);
                    } else {
                        parentFrame.showError("File not found at: " + filePath);
                    }
                }
            } catch (IOException | URISyntaxException e) {
                parentFrame.showError("Error opening material: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private void setupStudentViewClassScheduleTab() {
            JPanel schedulePanel = new JPanel(new BorderLayout(10, 10));
            schedulePanel.setBorder(new EmptyBorder(10, 10, 10, 10));
            schedulePanel.setBackground(UIUtils.BACKGROUND_COLOR);

            // --- Controls Panel ---
            JPanel controlsPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
            controlsPanel.setBackground(UIUtils.PANEL_COLOR);
            controlsPanel.setBorder(UIUtils.createPanelBorder());

            JLabel titleLabel = new JLabel("My Class Schedule", SwingConstants.CENTER);
            titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
            titleLabel.setForeground(UIUtils.ACCENT_COLOR);
            JPanel titleWrapper = new JPanel(new BorderLayout());
            titleWrapper.setBackground(UIUtils.PANEL_COLOR);
            titleWrapper.add(titleLabel, BorderLayout.CENTER);
            schedulePanel.add(titleWrapper, BorderLayout.NORTH);

            controlsPanel.add(new JLabel("Filter by Course:"));
            studentScheduleCourseFilterComboBox = new JComboBox<>();
            studentScheduleCourseFilterComboBox.addItemListener(e -> {
                if (e.getStateChange() == ItemEvent.SELECTED) {
                    loadStudentClassSchedules();
                }
            });
            controlsPanel.add(studentScheduleCourseFilterComboBox);
            schedulePanel.add(controlsPanel, BorderLayout.SOUTH);

            // --- Table Panel ---
            String[] scheduleColumnNames = {"ID", "Course", "Day of Week", "Start Time", "End Time"};
            studentClassScheduleTableModel = new DefaultTableModel(scheduleColumnNames, 0) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
            studentClassScheduleTable = new JTable(studentClassScheduleTableModel);
            UIUtils.styleTable(studentClassScheduleTable);

            JScrollPane scheduleTableScrollPane = new JScrollPane(studentClassScheduleTable);
            scheduleTableScrollPane.setBorder(UIUtils.createPanelBorder());
            schedulePanel.add(scheduleTableScrollPane, BorderLayout.CENTER);

            sidebar.addMenuItem("Class Schedule", schedulePanel);
            loadStudentCoursesForScheduleFilter();
            loadStudentClassSchedules(); // Initial load
        }

        private void loadStudentCoursesForScheduleFilter() {
            studentScheduleCourseFilterComboBox.removeAllItems();
            studentScheduleCourseFilterComboBox.addItem("All My Courses");
            int studentId = getStudentIdByUserId(loggedInUser.getId());
            if (studentId == -1) return;

            String sql = "SELECT c.id, c.name FROM courses c JOIN student_courses sc ON c.id = sc.course_id WHERE sc.student_id = ? ORDER BY c.name ASC";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                pstmt.setInt(1, studentId);
                ResultSet rs = pstmt.executeQuery();
                while (rs.next()) {
                    studentScheduleCourseFilterComboBox.addItem(rs.getString("name") + " (ID: " + rs.getInt("id") + ")");
                }
            } catch (SQLException e) {
                parentFrame.showError("Error loading courses for schedule filter: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private int getCourseIdFromStudentScheduleFilter(String selectedItem) {
            if (selectedItem == null || selectedItem.equals("All My Courses")) {
                return -1;
            }
            int startIndex = selectedItem.lastIndexOf("(ID: ") + 5;
            int endIndex = selectedItem.lastIndexOf(")");
            if (startIndex > 0 && endIndex > startIndex) {
                try {
                    return Integer.parseInt(selectedItem.substring(startIndex, endIndex));
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                    return -1;
                }
            }
            return -1;
        }

        private void loadStudentClassSchedules() {
            studentClassScheduleTableModel.setRowCount(0);
            int studentId = getStudentIdByUserId(loggedInUser.getId());
            if (studentId == -1) return;

            int courseFilterId = getCourseIdFromStudentScheduleFilter((String) studentScheduleCourseFilterComboBox.getSelectedItem());

            StringBuilder sqlBuilder = new StringBuilder();
            sqlBuilder.append("SELECT cs.id, c.name as course_name, cs.day_of_week, cs.start_time, cs.end_time ");
            sqlBuilder.append("FROM class_schedules cs JOIN courses c ON cs.course_id = c.id ");
            sqlBuilder.append("JOIN student_courses sc ON c.id = sc.course_id ");
            sqlBuilder.append("WHERE sc.student_id = ?");

            List<Object> params = new ArrayList<>();
            params.add(studentId);

            if (courseFilterId != -1) {
                sqlBuilder.append(" AND c.id = ?");
                params.add(courseFilterId);
            }

            sqlBuilder.append(" ORDER BY FIELD(cs.day_of_week, 'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY', 'SUNDAY'), cs.start_time ASC");

            try (PreparedStatement pstmt = connection.prepareStatement(sqlBuilder.toString())) {
                for (int i = 0; i < params.size(); i++) {
                    pstmt.setObject(i + 1, params.get(i));
                }

                ResultSet rs = pstmt.executeQuery();
                while (rs.next()) {
                    Vector<Object> row = new Vector<>();
                    row.add(rs.getInt("id"));
                    row.add(rs.getString("course_name"));
                    row.add(rs.getString("day_of_week"));
                    row.add(rs.getTime("start_time"));
                    row.add(rs.getTime("end_time"));
                    studentClassScheduleTableModel.addRow(row);
                }
            } catch (SQLException e) {
                parentFrame.showError("Error loading student class schedules: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private void setupStudentSubmitLeaveRequestTab() {
            JPanel leaveRequestPanel = new JPanel(new BorderLayout(10, 10));
            leaveRequestPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
            leaveRequestPanel.setBackground(UIUtils.BACKGROUND_COLOR);

            // --- Form Panel ---
            JPanel formPanel = new JPanel(new GridBagLayout());
            formPanel.setBackground(UIUtils.PANEL_COLOR);
            formPanel.setBorder(UIUtils.createPanelBorder());
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.insets = new Insets(5, 5, 5, 5);
            gbc.fill = GridBagConstraints.HORIZONTAL;

            JLabel titleLabel = new JLabel("Submit Leave Request", SwingConstants.CENTER);
            titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
            titleLabel.setForeground(UIUtils.ACCENT_COLOR);
            gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
            formPanel.add(titleLabel, gbc);

            gbc.gridwidth = 1;

            gbc.gridx = 0; gbc.gridy = 1; formPanel.add(new JLabel("Course (Optional):"), gbc);
            gbc.gridx = 1; leaveRequestCourseComboBox = new JComboBox<>(); formPanel.add(leaveRequestCourseComboBox, gbc);

            gbc.gridx = 0; gbc.gridy = 2; formPanel.add(new JLabel("Start Date (YYYY-MM-DD):"), gbc);
            gbc.gridx = 1; leaveRequestStartDateField = new JTextField(10); formPanel.add(leaveRequestStartDateField, gbc);

            gbc.gridx = 0; gbc.gridy = 3; formPanel.add(new JLabel("End Date (YYYY-MM-DD):"), gbc);
            gbc.gridx = 1; leaveRequestEndDateField = new JTextField(10); formPanel.add(leaveRequestEndDateField, gbc);

            gbc.gridx = 0; gbc.gridy = 4; formPanel.add(new JLabel("Reason:"), gbc);
            gbc.gridx = 1; leaveReasonArea = new JTextArea(3, 20); leaveReasonArea.setLineWrap(true); leaveReasonArea.setWrapStyleWord(true);
            JScrollPane reasonScrollPane = new JScrollPane(leaveReasonArea);
            formPanel.add(reasonScrollPane, gbc);

            JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
            submitLeaveRequestButton = new JButton("Submit Request");
            UIUtils.applyButtonStyle(submitLeaveRequestButton);
            submitLeaveRequestButton.addActionListener(e -> submitLeaveRequest());
            buttonPanel.add(submitLeaveRequestButton);

            gbc.gridx = 0; gbc.gridy = 5; gbc.gridwidth = 2;
            formPanel.add(buttonPanel, gbc);

            leaveRequestPanel.add(formPanel, BorderLayout.NORTH);

            // --- My Leave Requests Table ---
            JLabel myRequestsTitle = new JLabel("My Submitted Leave Requests", SwingConstants.CENTER);
            myRequestsTitle.setFont(new Font("Arial", Font.BOLD, 16));
            myRequestsTitle.setBorder(new EmptyBorder(10, 0, 5, 0));
            leaveRequestPanel.add(myRequestsTitle, BorderLayout.CENTER); // Temporarily add to center to push table down

            String[] myLeaveRequestsColumnNames = {"Request ID", "Course", "Start Date", "End Date", "Reason", "Status"};
            myLeaveRequestsTableModel = new DefaultTableModel(myLeaveRequestsColumnNames, 0) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
            myLeaveRequestsTable = new JTable(myLeaveRequestsTableModel);
            UIUtils.styleTable(myLeaveRequestsTable);

            JScrollPane myRequestsScrollPane = new JScrollPane(myLeaveRequestsTable);
            myRequestsScrollPane.setBorder(UIUtils.createPanelBorder());
            leaveRequestPanel.add(myRequestsScrollPane, BorderLayout.SOUTH); // Add to south

            sidebar.addMenuItem("Leave Request", leaveRequestPanel);
            loadStudentCoursesForLeaveRequest();
            loadMyLeaveRequests(); // Initial load
        }

        private void loadStudentCoursesForLeaveRequest() {
            leaveRequestCourseComboBox.removeAllItems();
            leaveRequestCourseComboBox.addItem("General Leave (Not Course Specific)");
            int studentId = getStudentIdByUserId(loggedInUser.getId());
            if (studentId == -1) return;

            String sql = "SELECT c.id, c.name FROM courses c JOIN student_courses sc ON c.id = sc.course_id WHERE sc.student_id = ? ORDER BY c.name ASC";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                pstmt.setInt(1, studentId);
                ResultSet rs = pstmt.executeQuery();
                while (rs.next()) {
                    leaveRequestCourseComboBox.addItem(rs.getString("name") + " (ID: " + rs.getInt("id") + ")");
                }
            } catch (SQLException e) {
                parentFrame.showError("Error loading courses for leave request: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private int getCourseIdFromLeaveRequestComboBox(String selectedItem) {
            if (selectedItem == null || selectedItem.equals("General Leave (Not Course Specific)")) {
                return -1;
            }
            int startIndex = selectedItem.lastIndexOf("(ID: ") + 5;
            int endIndex = selectedItem.lastIndexOf(")");
            if (startIndex > 0 && endIndex > startIndex) {
                try {
                    return Integer.parseInt(selectedItem.substring(startIndex, endIndex));
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                    return -1;
                }
            }
            return -1;
        }

        private void submitLeaveRequest() {
            int studentId = getStudentIdByUserId(loggedInUser.getId());
            if (studentId == -1) {
                parentFrame.showError("Student ID not found.");
                return;
            }

            int courseId = getCourseIdFromLeaveRequestComboBox((String) leaveRequestCourseComboBox.getSelectedItem());
            String startDateStr = leaveRequestStartDateField.getText().trim();
            String endDateStr = leaveRequestEndDateField.getText().trim();
            String reason = leaveReasonArea.getText().trim();

            if (startDateStr.isEmpty() || endDateStr.isEmpty() || reason.isEmpty()) {
                parentFrame.showError("Start Date, End Date, and Reason are required.");
                return;
            }

            LocalDate startDate, endDate;
            try {
                startDate = LocalDate.parse(startDateStr);
                endDate = LocalDate.parse(endDateStr);
                if (startDate.isAfter(endDate)) {
                    parentFrame.showError("Start date cannot be after end date.");
                    return;
                }
            } catch (DateTimeParseException e) {
                parentFrame.showError("Invalid date format. Please use YYYY-MM-DD.");
                return;
            }

            String sql = "INSERT INTO leave_requests (student_id, course_id, request_date, start_date, end_date, reason, status) VALUES (?, ?, CURDATE(), ?, ?, ?, 'pending')";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                pstmt.setInt(1, studentId);
                if (courseId != -1) {
                    pstmt.setInt(2, courseId);
                } else {
                    pstmt.setNull(2, Types.INTEGER);
                }
                pstmt.setDate(3, Date.valueOf(startDate));
                pstmt.setDate(4, Date.valueOf(endDate));
                pstmt.setString(5, reason);
                pstmt.executeUpdate();
                parentFrame.showSuccess("Leave request submitted successfully! Awaiting approval.");
                loadMyLeaveRequests();
                clearLeaveRequestForm();
            } catch (SQLException e) {
                parentFrame.showError("Error submitting leave request: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private void loadMyLeaveRequests() {
            myLeaveRequestsTableModel.setRowCount(0);
            int studentId = getStudentIdByUserId(loggedInUser.getId());
            if (studentId == -1) return;

            String sql = "SELECT lr.id, c.name as course_name, lr.start_date, lr.end_date, lr.reason, lr.status " +
                         "FROM leave_requests lr LEFT JOIN courses c ON lr.course_id = c.id " +
                         "WHERE lr.student_id = ? ORDER BY lr.request_date DESC";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                pstmt.setInt(1, studentId);
                ResultSet rs = pstmt.executeQuery();
                while (rs.next()) {
                    Vector<Object> row = new Vector<>();
                    row.add(rs.getInt("id"));
                    row.add(rs.getString("course_name") != null ? rs.getString("course_name") : "General Leave");
                    row.add(rs.getDate("start_date"));
                    row.add(rs.getDate("end_date"));
                    row.add(rs.getString("reason"));
                    row.add(rs.getString("status"));
                    myLeaveRequestsTableModel.addRow(row);
                }
            } catch (SQLException e) {
                parentFrame.showError("Error loading your leave requests: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private void clearLeaveRequestForm() {
            leaveRequestCourseComboBox.setSelectedItem("General Leave (Not Course Specific)");
            leaveRequestStartDateField.setText("");
            leaveRequestEndDateField.setText("");
            leaveReasonArea.setText("");
        }

        private void setupStudentViewAnnouncementsTab() {
            JPanel announcementsPanel = new JPanel(new BorderLayout(10, 10));
            announcementsPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
            announcementsPanel.setBackground(UIUtils.BACKGROUND_COLOR);

            JLabel titleLabel = new JLabel("My Announcements", SwingConstants.CENTER);
            titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
            titleLabel.setForeground(UIUtils.ACCENT_COLOR);
            announcementsPanel.add(titleLabel, BorderLayout.NORTH);

            String[] columnNames = {"ID", "Subject", "Sender", "Sent At", "Read Status"};
            studentAnnouncementsTableModel = new DefaultTableModel(columnNames, 0) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
            studentAnnouncementsTable = new JTable(studentAnnouncementsTableModel);
            UIUtils.styleTable(studentAnnouncementsTable);

            studentAnnouncementsTable.getSelectionModel().addListSelectionListener(e -> {
                if (!e.getValueIsAdjusting() && studentAnnouncementsTable.getSelectedRow() != -1) {
                    displayStudentAnnouncementMessage(studentAnnouncementsTable.convertRowIndexToModel(studentAnnouncementsTable.getSelectedRow()));
                }
            });

            JScrollPane tableScrollPane = new JScrollPane(studentAnnouncementsTable);
            tableScrollPane.setBorder(UIUtils.createPanelBorder());
            announcementsPanel.add(tableScrollPane, BorderLayout.CENTER);

            JPanel bottomPanel = new JPanel(new BorderLayout(5, 5));
            bottomPanel.setBackground(UIUtils.PANEL_COLOR);
            bottomPanel.setBorder(UIUtils.createPanelBorder());

            studentAnnouncementMessageArea = new JTextArea(5, 30);
            studentAnnouncementMessageArea.setEditable(false);
            studentAnnouncementMessageArea.setLineWrap(true);
            studentAnnouncementMessageArea.setWrapStyleWord(true);
            JScrollPane messageScrollPane = new JScrollPane(studentAnnouncementMessageArea);
            bottomPanel.add(messageScrollPane, BorderLayout.CENTER);

            studentMarkAnnouncementReadButton = new JButton("Mark as Read");
            UIUtils.applyButtonStyle(studentMarkAnnouncementReadButton);
            studentMarkAnnouncementReadButton.addActionListener(e -> studentMarkAnnouncementAsRead());
            JPanel buttonWrapper = new JPanel(new FlowLayout(FlowLayout.RIGHT));
            buttonWrapper.setBackground(UIUtils.PANEL_COLOR);
            buttonWrapper.add(studentMarkAnnouncementReadButton);
            bottomPanel.add(buttonWrapper, BorderLayout.SOUTH);

            announcementsPanel.add(bottomPanel, BorderLayout.SOUTH);

            sidebar.addMenuItem("Announcements", announcementsPanel);
            loadStudentAnnouncements();
        }

        private void loadStudentAnnouncements() {
            studentAnnouncementsTableModel.setRowCount(0);
            String sql = "SELECT ua.id as user_announcement_id, a.id as announcement_id, a.subject, u.full_name as sender_name, a.sent_at, ua.is_read " +
                         "FROM user_announcements ua JOIN announcements a ON ua.announcement_id = a.id " +
                         "JOIN users u ON a.sender_user_id = u.id " +
                         "WHERE ua.recipient_user_id = ? ORDER BY a.sent_at DESC";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                pstmt.setInt(1, loggedInUser.getId());
                ResultSet rs = pstmt.executeQuery();
                while (rs.next()) {
                    Vector<Object> row = new Vector<>();
                    row.add(rs.getInt("announcement_id"));
                    row.add(rs.getString("subject"));
                    row.add(rs.getString("sender_name"));
                    row.add(rs.getTimestamp("sent_at"));
                    row.add(rs.getBoolean("is_read") ? "Read" : "Unread");
                    studentAnnouncementsTableModel.addRow(row);
                }
            } catch (SQLException e) {
                parentFrame.showError("Error loading announcements: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private void displayStudentAnnouncementMessage(int modelRowIndex) {
            int announcementId = (int) studentAnnouncementsTableModel.getValueAt(modelRowIndex, 0);
            boolean isRead = studentAnnouncementsTableModel.getValueAt(modelRowIndex, 4).equals("Read");

            String sql = "SELECT message FROM announcements WHERE id = ?";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                pstmt.setInt(1, announcementId);
                ResultSet rs = pstmt.executeQuery();
                if (rs.next()) {
                    studentAnnouncementMessageArea.setText(rs.getString("message"));
                }
            } catch (SQLException e) {
                parentFrame.showError("Error fetching announcement message: " + e.getMessage());
                e.printStackTrace();
            }

            studentMarkAnnouncementReadButton.setEnabled(!isRead);
        }

        private void studentMarkAnnouncementAsRead() {
            int selectedRow = studentAnnouncementsTable.getSelectedRow();
            if (selectedRow == -1) {
                parentFrame.showError("Please select an announcement to mark as read.");
                return;
            }

            int modelRow = studentAnnouncementsTable.convertRowIndexToModel(selectedRow);
            int announcementId = (int) studentAnnouncementsTableModel.getValueAt(modelRow, 0);

            String sql = "UPDATE user_announcements SET is_read = TRUE WHERE announcement_id = ? AND recipient_user_id = ?";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                pstmt.setInt(1, announcementId);
                pstmt.setInt(2, loggedInUser.getId());
                int affectedRows = pstmt.executeUpdate();
                if (affectedRows > 0) {
                    parentFrame.showSuccess("Announcement marked as read.");
                    loadStudentAnnouncements(); // Refresh table
                    studentAnnouncementMessageArea.setText(""); // Clear message area
                    studentMarkAnnouncementReadButton.setEnabled(false);
                } else {
                    parentFrame.showError("Failed to mark announcement as read.");
                }
            } catch (SQLException e) {
                parentFrame.showError("Error marking announcement as read: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private void setupStudentSubmitFeedbackTab() {
            JPanel feedbackPanel = new JPanel(new BorderLayout(10, 10));
            feedbackPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
            feedbackPanel.setBackground(UIUtils.BACKGROUND_COLOR);

            // --- Form Panel ---
            JPanel formPanel = new JPanel(new GridBagLayout());
            formPanel.setBackground(UIUtils.PANEL_COLOR);
            formPanel.setBorder(UIUtils.createPanelBorder());
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.insets = new Insets(5, 5, 5, 5);
            gbc.fill = GridBagConstraints.HORIZONTAL;

            JLabel titleLabel = new JLabel("Submit Course Feedback", SwingConstants.CENTER);
            titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
            titleLabel.setForeground(UIUtils.ACCENT_COLOR);
            gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
            formPanel.add(titleLabel, gbc);

            gbc.gridwidth = 1;

            gbc.gridx = 0; gbc.gridy = 1; formPanel.add(new JLabel("Course:"), gbc);
            gbc.gridx = 1; feedbackCourseComboBox = new JComboBox<>(); formPanel.add(feedbackCourseComboBox, gbc);

            gbc.gridx = 0; gbc.gridy = 2; formPanel.add(new JLabel("Rating (1-5):"), gbc);
            gbc.gridx = 1; feedbackRatingSpinner = new JSpinner(new SpinnerNumberModel(3, 1, 5, 1)); formPanel.add(feedbackRatingSpinner, gbc);

            gbc.gridx = 0; gbc.gridy = 3; formPanel.add(new JLabel("Comments:"), gbc);
            gbc.gridx = 1; feedbackCommentsArea = new JTextArea(5, 20); feedbackCommentsArea.setLineWrap(true); feedbackCommentsArea.setWrapStyleWord(true);
            JScrollPane commentsScrollPane = new JScrollPane(feedbackCommentsArea);
            formPanel.add(commentsScrollPane, gbc);

            JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
            submitFeedbackButton = new JButton("Submit Feedback");
            UIUtils.applyButtonStyle(submitFeedbackButton);
            submitFeedbackButton.addActionListener(e -> submitFeedback());
            buttonPanel.add(submitFeedbackButton);

            gbc.gridx = 0; gbc.gridy = 4; gbc.gridwidth = 2;
            formPanel.add(buttonPanel, gbc);

            feedbackPanel.add(formPanel, BorderLayout.NORTH);

            // --- My Feedback Table ---
            JLabel myFeedbackTitle = new JLabel("My Submitted Feedback", SwingConstants.CENTER);
            myFeedbackTitle.setFont(new Font("Arial", Font.BOLD, 16));
            myFeedbackTitle.setBorder(new EmptyBorder(10, 0, 5, 0));
            feedbackPanel.add(myFeedbackTitle, BorderLayout.CENTER); // Temporarily add to center to push table down

            String[] myFeedbackColumnNames = {"ID", "Course", "Rating", "Comments", "Submitted At"};
            myFeedbackTableModel = new DefaultTableModel(myFeedbackColumnNames, 0) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
            myFeedbackTable = new JTable(myFeedbackTableModel);
            UIUtils.styleTable(myFeedbackTable);

            JScrollPane myFeedbackScrollPane = new JScrollPane(myFeedbackTable);
            myFeedbackScrollPane.setBorder(UIUtils.createPanelBorder());
            feedbackPanel.add(myFeedbackScrollPane, BorderLayout.SOUTH); // Add to south

            sidebar.addMenuItem("Feedback", feedbackPanel);
            loadStudentCoursesForFeedback();
            loadMyFeedback(); // Initial load
        }

        private void loadStudentCoursesForFeedback() {
            feedbackCourseComboBox.removeAllItems();
            feedbackCourseComboBox.addItem("Select Course");
            int studentId = getStudentIdByUserId(loggedInUser.getId());
            if (studentId == -1) return;

            String sql = "SELECT c.id, c.name FROM courses c JOIN student_courses sc ON c.id = sc.course_id WHERE sc.student_id = ? ORDER BY c.name ASC";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                pstmt.setInt(1, studentId);
                ResultSet rs = pstmt.executeQuery();
                while (rs.next()) {
                    feedbackCourseComboBox.addItem(rs.getString("name") + " (ID: " + rs.getInt("id") + ")");
                }
            } catch (SQLException e) {
                parentFrame.showError("Error loading courses for feedback: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private int getCourseIdFromFeedbackComboBox(String selectedItem) {
            if (selectedItem == null || selectedItem.equals("Select Course")) {
                return -1;
            }
            int startIndex = selectedItem.lastIndexOf("(ID: ") + 5;
            int endIndex = selectedItem.lastIndexOf(")");
            if (startIndex > 0 && endIndex > startIndex) {
                try {
                    return Integer.parseInt(selectedItem.substring(startIndex, endIndex));
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                    return -1;
                }
            }
            return -1;
        }

        private void submitFeedback() {
            int studentId = getStudentIdByUserId(loggedInUser.getId());
            if (studentId == -1) {
                parentFrame.showError("Student ID not found.");
                return;
            }

            int courseId = getCourseIdFromFeedbackComboBox((String) feedbackCourseComboBox.getSelectedItem());
            int rating = (int) feedbackRatingSpinner.getValue();
            String comments = feedbackCommentsArea.getText().trim();

            if (courseId == -1) {
                parentFrame.showError("Please select a course.");
                return;
            }

            String sql = "INSERT INTO feedback (student_id, course_id, rating, comments) VALUES (?, ?, ?, ?)";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                pstmt.setInt(1, studentId);
                pstmt.setInt(2, courseId);
                pstmt.setInt(3, rating);
                pstmt.setString(4, comments.isEmpty() ? null : comments);
                pstmt.executeUpdate();
                parentFrame.showSuccess("Feedback submitted successfully!");
                loadMyFeedback();
                clearFeedbackForm();
            } catch (SQLIntegrityConstraintViolationException e) {
                parentFrame.showError("You have already submitted feedback for this course.");
                e.printStackTrace();
            } catch (SQLException e) {
                parentFrame.showError("Error submitting feedback: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private void loadMyFeedback() {
            myFeedbackTableModel.setRowCount(0);
            int studentId = getStudentIdByUserId(loggedInUser.getId());
            if (studentId == -1) return;

            String sql = "SELECT f.id, c.name as course_name, f.rating, f.comments, f.submitted_at " +
                         "FROM feedback f JOIN courses c ON f.course_id = c.id " +
                         "WHERE f.student_id = ? ORDER BY f.submitted_at DESC";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                pstmt.setInt(1, studentId);
                ResultSet rs = pstmt.executeQuery();
                while (rs.next()) {
                    Vector<Object> row = new Vector<>();
                    row.add(rs.getInt("id"));
                    row.add(rs.getString("course_name"));
                    row.add(rs.getInt("rating"));
                    row.add(rs.getString("comments"));
                    row.add(rs.getTimestamp("submitted_at"));
                    myFeedbackTableModel.addRow(row);
                }
            } catch (SQLException e) {
                parentFrame.showError("Error loading your feedback: " + e.getMessage());
                e.printStackTrace();
            }
        }

        private void clearFeedbackForm() {
            feedbackCourseComboBox.setSelectedItem("Select Course");
            feedbackRatingSpinner.setValue(3);
            feedbackCommentsArea.setText("");
        }
    }
}


            